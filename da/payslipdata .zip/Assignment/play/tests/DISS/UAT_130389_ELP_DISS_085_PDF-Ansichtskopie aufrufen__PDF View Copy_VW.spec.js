const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');
const { complaintAttachments } = require('../../support/pageObjects/DISSPageObjects/complaintAttachmentsPage');
const { volkswagenFileUploader } = require('../../support/pageObjects/DISSPageObjects/volkswagenFileUploaderPage');

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const pdf = require('pdf-parse');


test('UAT_130389_ELP_DISS_085_PDF-Ansichtskopie aufrufen__PDF View Copy', async () => {
    // adjust global timeout for this test case only as it takes more than 100000 ms in config file
    test.test.setTimeout(210000)

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);

    /* prerpare userDataDir */
    // userDataDir is custom Data Dir. used to create chromium with custome preferences
    const userDataDir = path.join(__dirname, "/../../resources", `${data.testCase[51].test_id}_user_data`);
    if (fs.existsSync(userDataDir)) {
        // Delete the folder if it exists
        fs.rmdirSync(userDataDir, { recursive: true });
    }
    // Ensure the user data directory exists
    fs.mkdirSync(path.join(userDataDir, "Default"), { recursive: true });

    // Define the path for the Preferences file
    const preferencesPath = path.join(userDataDir, "Default", 'Preferences');

    // Default preferences needed
    const defaultPreferences = {
        "plugins": {
            "always_open_pdf_externally": true // Set to always open PDF externally
        },
        "profile": {
            "content_settings": {
                "pattern_pairs": {}
            }
        }
    };

    // Write the default preferences to the Preferences file
    fs.writeFileSync(preferencesPath, JSON.stringify(defaultPreferences));
    const context = await chromium.launchPersistentContext(userDataDir)

    const page = await context.pages()[0]


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[51].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[51].context)
    await navigation.goToApplication(page, data.testCase[51].elsaApp, data.testCase[51].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await elsaProPage.waitForTimeout(3000);
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[51].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[51].link)

    // enter order number in search for it
    await direktInformationssystemService.enterOrderNumberAndClickSearch(elsaProPage, data.testCase[51].TestConfigurations[0].orderNumber)
    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);

    // press Beanstandungen zu Auftrag auflisten button after
    await direktInformationssystemService.clickOnListOfComplaints(elsaProPage)
    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    await elsaProPage.waitForLoadState("load")
    await elsaProPage.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[51].TestConfigurations[0].customerComplaint)

    // select yes in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

    // select no in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[51].labelNamesArray, data.testCase[51].infomediaArray)

    // select the label
    await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[51].labelNamesArray2, data.testCase[51].infomediaArray2)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup);

    // click "OK" in Popup
    await direktInformationssystemService.clickOkInPopup(elsaProPage)

    // Static wait for 5 seconds (5000 milliseconds)
    await elsaProPage.waitForTimeout(5000);

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[51].codierenText)

    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[51].HSTTitle)

    //search document by name
    await HandbuchServiceTechnikPage.openDocumentByName(elsaProPage, data.testCase[51].documentNumber)
    // Static wait for 5 seconds (5000 milliseconds)
    await elsaProPage.waitForTimeout(5000);
    //this method click on "HST nach DISS übernehmen"/"Copy HST to DISS" (📋) button after open the document
    await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage)

    // Static wait for 5 seconds (5000 milliseconds)
    await elsaProPage.waitForTimeout(5000);

    //click on next proceed button
    await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    //click on "Optionale Angaben erfassen" / "Enter optional information" button to made the question in step 10 visible
    await direktInformationssystemService.clickEnterOptionalInformationButton(elsaProPage)
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    //click on "ja" in the radio buttons in Ist die Beanstandung behoben? / Has the complaint been resolved?
    await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, "ja")

    //select type of repair selected as Reparatur mit Teiletausch
    await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "keine")
    //Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);

    //click on yes/ja in pop up
    await direktInformationssystemService.selectOptionInHaveYouWorkedAccordingToTPIPopup(elsaProPage, "TPIReparaturJ")

    //clicks"Auswahl übernehmen"/"Apply selection" button
    await direktInformationssystemService.clickApplySelectionInHaveYouWorkedAccordingToTPIPopup(elsaProPage)
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    await direktInformationssystemService.clearAndEnterAdditionalInformation(elsaProPage, "Test")

    //enter Nummer des schadensbehebenden Originalteils/Number of the original part to repair the damage
    await direktInformationssystemService.enterNumberinNummerDesSchadensbehebenden(elsaProPage, data.testCase[51].schadensbehebendenTextsArray)

    const [attachmentManagementPage] = await Promise.all([
        context.waitForEvent('page'),
        // click on Opens the attachment management view for this complaint
        await direktInformationssystemService.clickOnAttachmentManagement(elsaProPage)
    ]);

    const [volkswagenFileUploaderPage] = await Promise.all([
        context.waitForEvent('page'),
        // click on the Open Upload Manager
        await complaintAttachments.clickOnOpenUploadManager(attachmentManagementPage)
    ]);

    await volkswagenFileUploader.selectReadAndAcceptMediaHubTermsOfUseCheckBox(volkswagenFileUploaderPage)
    const imagePath = path.join(__dirname, "/../../resources", `${data.testCase[51].test_id}.jpg`)
    // Start waiting for file chooser before clicking
    const fileChooserPromise = volkswagenFileUploaderPage.waitForEvent('filechooser');
    // click on upload file symbol
    await volkswagenFileUploader.clickOnUploadFile(volkswagenFileUploaderPage)
    const fileChooser = await fileChooserPromise;
    await fileChooser.setFiles(imagePath);
    await volkswagenFileUploader.clickNextUpload(volkswagenFileUploaderPage)
    await elsaProPage.waitForTimeout(3000);
    await volkswagenFileUploader.clickFinalizeUpload(volkswagenFileUploaderPage)
    await elsaProPage.waitForTimeout(3000);
    await complaintAttachments.clickCloseAttachmentManagement(attachmentManagementPage)
    await elsaProPage.waitForTimeout(3000);
    //click on finish btn 
    await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)
    //click on feedback btn in popup
    await direktInformationssystemService.clickonOKoption(elsaProPage)
    await elsaProPage.waitForTimeout(3000);
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')
    const BA_ID = await direktInformationssystemService.getValueFromBeanstandungsdatenTable(elsaProPage, "BA-ID:")
    const artderReparatur = await direktInformationssystemService.getValueFromBeanstandungsdatenTable(elsaProPage, "Art der Reparatur:")

    const pdfPath = userDataDir + `/${data.testCase[51].test_id}.pdf`
    const downloadPromise = page.waitForEvent('download');
    await direktInformationssystemService.clickOnOpenPDFViewCopyWithAttachments(elsaProPage)
    const download = await downloadPromise;
    // Wait for the download process to complete and save the downloaded file somewhere.
    await download.saveAs(pdfPath);

    // read PDF file
    let dataBuffer = await fs.readFileSync(pdfPath);
    // Parse the PDF using pdf-parse
    let pdfData = await pdf(dataBuffer);
    // Get the text content from the PDF
    let pdfText = pdfData.text;

    const imageFileNameInPDF = (await pdfText.match(new RegExp("(?<=Dateiname)(.*)(?=.jpeg)")))[0]
    const dataToValidateInPDF = [
        `Auftragsnummer:${data.testCase[51].TestConfigurations[0].orderNumber}`,
        `Fahrgestellnummer:${data.testCase[51].TestConfigurations[0].VIN}`,
        `BA-ID${BA_ID}`,
        `Wie lautet die Beanstandung des Kunden?\\r\\n|\\r|\\n${data.testCase[51].TestConfigurations[0].customerComplaint}`,
        `Waren Sie wegen dieser\\r\\n|\\r|\\nBeanstandung bereits in der\\r\\n|\\r|\\nWerkstatt?\\r\\n|\\r|\\nnein`,
        `Ist das Auto ein Liegenbleiber?nein\\r\\n|\\r|\\n`,
        `Kundencodierung:${data.testCase[51].codierenText}\\r\\n|\\r|\\n`,
        `Art der Reparatur:${artderReparatur}\\r\\n|\\r|\\n`,
        `HST Vorgangs-Nr.:${data.testCase[51].documentNumber}\\r\\n|\\r|\\n`,
        `Titel${data.testCase[51].test_id}\\r\\n|\\r|\\n`,
        `Dateiname${imageFileNameInPDF}.jpeg\\r\\n|\\r|\\n`,
        `${imageFileNameInPDF}.jpeg\\r\\n|\\r|\\n`,
        `Inhaltstypimage/jpeg\\r\\n|\\r|\\n`,
    ]
    for (let i = 0; i < dataToValidateInPDF.length; i++) {
        expect(new RegExp(dataToValidateInPDF[i]).test(pdfText)).toBeTruthy();
    }

    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)
});