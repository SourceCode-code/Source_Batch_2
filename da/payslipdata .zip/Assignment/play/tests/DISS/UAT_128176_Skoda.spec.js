const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');

const fs = require('fs');
const path = require('path');

test('UAT_128176_ELP_DISS_011_Übernahme der KVPS - Händlerportalwerte prüfen_Acquisition of KVPS - Check Merchant Portal Values_Skoda', async () => {
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[58].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[58].TestConfigurations[4].context)
    await navigation.goToApplication(page, data.testCase[58].elsaApp, data.testCase[58].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[58].TestConfigurations[4].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[58].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    //table[@class="OrderData"]//td[@class="RLabel"][text()="Betriebsnummer:"]/following-sibling::td[1]
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[58].customerComplaint)

    //click on save btn
    await direktInformationssystemService.clickonSaveBtn(elsaProPage)
    await elsaProPage.waitForTimeout(2000);
    // this is because the page is auto refresh after click on the button
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    // get today's date 
    const date = await direktInformationssystemService.getTodayDate()
    const betriebsnummer = (await data.testCase[58].TestConfigurations[4].context.match(new RegExp("(?<=DEU)(\\d+)")))[0]
    await direktInformationssystemService.verifyValueFromAuftragsdatenTable(elsaProPage, "Auftragsnummer:", data.testCase[58].Auftragsnummer)
    await direktInformationssystemService.verifyValueFromAuftragsdatenTable(elsaProPage, "Auftragsdatum:", date)
    await direktInformationssystemService.verifyValueFromAuftragsdatenTable(elsaProPage, "Fahrgestellnummer:", data.testCase[58].TestConfigurations[4].VIN)
    await direktInformationssystemService.verifyValueFromAuftragsdatenTable(elsaProPage, "Importeurs-/VZ-Nummer:", data.testCase[58].TestConfigurations[4].VZNummer)
    await direktInformationssystemService.verifyValueFromAuftragsdatenTable(elsaProPage, "Betriebsnummer:", betriebsnummer)


    // click on "System & User Information" button
    await direktInformationssystemService.clickOnSystemAndUserInformationButton(elsaProPage)
    await elsaProPage.waitForTimeout(5000)
    const SystemAndUserInformation = await (context.pages())[await (context.pages()).length - 1];
    await direktInformationssystemService.verifyValueInSystemAndUserInformationPage(SystemAndUserInformation, "Betriebsnummer:", betriebsnummer)
    await direktInformationssystemService.verifyValueInSystemAndUserInformationPage(SystemAndUserInformation, "OU-ID:", data.testCase[58].TestConfigurations[4].OUID)
    await direktInformationssystemService.verifyValueInSystemAndUserInformationPage(SystemAndUserInformation, "Build-Version:", data.testCase[58].BuildNumber)
    await SystemAndUserInformation.close()
    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)
    // Close the browser
    await browser.close();
});