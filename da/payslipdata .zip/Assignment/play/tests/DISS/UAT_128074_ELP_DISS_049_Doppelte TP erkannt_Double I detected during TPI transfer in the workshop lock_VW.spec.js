const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');

const fs = require('fs');
const path = require('path');

test('UAT_128074_ELP_DISS_049_Doppelte TP erkannt_Double I detected during TPI transfer in the workshop lock_VW', async () => {
    // adjust global timeout for this test case only as it takes more than 100000 ms in config file
    test.test.setTimeout(150000)
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);

    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[42].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[42].context)
    await navigation.goToApplication(page, data.testCase[42].elsaApp, data.testCase[42].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[42].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[42].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[42].TestConfigurations[0].customerComplaint_1)

    // select yes in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "ja")
    // Static wait for 2 seconds (2000 milliseconds)
    await elsaProPage.waitForTimeout(2000);

    // select no in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[42].labelNamesArray, data.testCase[42].infomediaArray)

    // select the label
    await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[42].labelNamesArray2, data.testCase[42].infomediaArray2)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup);

    // click "OK" in Popup
    await direktInformationssystemService.clickOkInPopup(elsaProPage)

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[42].codierenText)

    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[42].HSTTitle)


    //click on given link 
    //Note here in test case given document name "/ Image catalogue for diagnosing crank drive in gasoline engines (2013425/3)"
    //but this document name not availble there so taken another name 
    await page.waitForTimeout(3000);
    //this method click & open any document after clicking on HST without searching
    await HandbuchServiceTechnikPage.openDocumentByName(elsaProPage, "2008818/18")

    //this method click on "HST nach DISS übernehmen"/"Copy HST to DISS" (📋) button after open the document
    await page.waitForTimeout(3000);
    await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage)

    // Choose "nein" in "Would you like to make a request?"
    await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, "2")

    //enter text in auftragsnummer box
    await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

    //enter the mileage in mileage feild
    await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[42].mileage)

    //click on next process step button
    await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)

    // select  yes option for Has the complaint been rectified?/Ist die Beanstandung behoben?
    await elsaProPage.waitForTimeout(3000);
    await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, "ja")

    //click on radio buttons in Art der Reparatur
    await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "ohneteiltpl")

    //static wait for stability
    await elsaProPage.waitForTimeout(5000)

    //this method is used to select option in "Haben Sie entsprechend der vorliegenden TPI gearbeitet?"/"Have you worked according to the present TPI" popup
    await direktInformationssystemService.selectOptionInHaveYouWorkedAccordingToTPIPopup(elsaProPage, "TPIReparaturJ")

    //clicks"Auswahl übernehmen"/"Apply selection" button
    await direktInformationssystemService.clickApplySelectionInHaveYouWorkedAccordingToTPIPopup(elsaProPage)


    //static wait for stability
    await elsaProPage.waitForTimeout(3000)
    // Enter Number of work Item
    await direktInformationssystemService.enterNumberOfWorkItem(elsaProPage, "123456")

    //click on Abschliessen/finish button
    await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)

    //click on feedback btn in popup
    await direktInformationssystemService.clickonOKoption(elsaProPage)
    await elsaProPage.waitForTimeout(2000)
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')

    //click on the close infomedia
    await direktInformationssystemService.closeDissinfomediabtn(elsaProPage)

    // this method clicks on the "Vorgang schliessen" button
    await homepage.clickOnVorgangSchliessenButton(elsaProPage)

    //click on message Box Ja Button
    await homepage.clickMessageBoxSchließenButton(elsaProPage)

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[42].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[42].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[42].TestConfigurations[0].customerComplaint_2)
    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // select yes in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "ja")

    // Static wait for 2 seconds (2000 milliseconds)
    await elsaProPage.waitForTimeout(2000);

    // select ja, in anderer Werkstatt in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "jaandere")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup2] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup2, data.testCase[42].labelNamesArray, data.testCase[42].infomediaArray)

    // select the label
    await Editpage.clickOnTheLabel(editPopup2, ["Beanstandungsart"])

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup2, data.testCase[42].labelNamesArray2, data.testCase[42].infomediaArray2)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup2);

    // click "OK" in Popup
    await direktInformationssystemService.clickOkInPopup(elsaProPage)

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[42].codierenText)

    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[42].HSTTitle)

    // click exit button in order to close the Handsbuchservicetechnik page
    await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

    //click on edit baid row
    await direktInformationssystemService.clickEditThisComplaintButton(elsaProPage)

    //enter text in auftragsnummer box
    await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

    //enter the mileage in mileage feild
    await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[42].mileage_2)

    //click on next process step button
    await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)

    // Choose "nein" in "Would you like to make a request?""
    await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, "2")

    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //click on given link 
    //Note here in test case given document name "Image catalogue for diagnosing crank drive in gasoline engines (2013425/3)"
    //but this document name not availble there so taken another name 
    await page.waitForTimeout(3000);
    ////this method click & open any document after clicking on HST without searching
    await HandbuchServiceTechnikPage.openDocumentByName(elsaProPage, "2008818/18")

    //this method click on "HST nach DISS übernehmen"/"Copy HST to DISS" (📋) button after open the document
    await page.waitForTimeout(3000);
    await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage)

    // verify warning Icon Locator Is Yellow and title attribute contain "Zu dieser Beanstandung ist bereits eine Reparatur zur übernommenen TPI erfolgt."
    await direktInformationssystemService.verifyWarningIcon(elsaProPage)

    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)
});