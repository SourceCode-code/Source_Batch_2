const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');


const fs = require('fs');
const path = require('path');

test('UAT_127509_ELP_DISS_061_Pflichtangaben zur Schadensbehobenen Arbeitspostition_Mandatory information on the damage-repaired work position_Suche for data unknown to the DMS_VW', async () => {
  // adjust global timeout for this test case only as it takes more than 100000 ms in config file
  test.test.setTimeout(300000)
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  // Define the path to the fixture file
  const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
  // Read the JSON file synchronously
  const fixtureData = fs.readFileSync(fixtureFilePath);
  // Parse the JSON data
  const data = JSON.parse(fixtureData);


  // visit website grp prelive, login and click on Elsa Pro application
  await navigation.navigateToBaseUrl(page);
  // login with credentials
  await navigation.loginWithCredentials(page, data.testCase[8].user);
  // change context from GRP page
  await navigation.GRP_Context(page, data.testCase[8].context)
  // Click on specific Application 
  await navigation.goToApplication(page, data.testCase[8].elsaApp, data.testCase[8].user)
  // set the new page opened to elsaProPage
  const allPages = context.pages();
  const elsaProPage = allPages[0];
  await elsaProPage.waitForLoadState('domcontentloaded');

  // verify ELP homepage 
  await homepage.verifyELPHomePage(elsaProPage)
  // change Language to DE
  await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

  // click on FahrzeugidentifikationBtn
  await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

  // write FIn and click send button
  await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[8].TestConfigurations[0].VIN);

  // click ok message box, click OK on Fahrzeugauswahl
  await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
  await fahrzeugAuswahl.clickOKButton(elsaProPage);

  // click on "Schließen" Button in message box
  // await homepage.clickMessageBoxSchließenButton(elsaProPage)

  // click on DISS
  await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[8].link)

  // click on "Neuen Auftrag Anlegen" button
  await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

  //enter text in Customer Complaint box
  await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[8].TestConfigurations[0].customerComplaint)

  // select no in is the car brokendown?
  await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, data.testCase[8].carBrokendown)

  // select no in our workshop because of this complaint?
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, data.testCase[8].alreadyVisitInWorkshop)

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup.waitForLoadState('domcontentloaded');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[8].labelNamesArray, data.testCase[8].infomediaArray)

  // select the label
  await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[8].labelNamesArray2, data.testCase[8].infomediaArray2)

  // Click on Übernehmen button

  await Editpage.clickÜbernehmenButton(editPopup);

  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage, true)

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[8].codierenText)


  //click on HST Button In DISS Page
  await direktInformationssystemService.clickHstButton(elsaProPage)

  // click exit button in order to close the Handsbuchservicetechnik page
  await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

  await page.waitForTimeout(3000);

  // Choose "nein" in Already Visit In Workshop
  await direktInformationssystemService.selectSendingQueryRadioBtn(elsaProPage, data.testCase[8].queryRadioBtn1)

  //enter text in auftragsnummer box
  await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

  //enter the mileage in mileage feild
  await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[8].mileage)

  await page.waitForTimeout(1000);
  //click on next proceed button
  await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)

  //verify the status of top DISS page tabs
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Beanstandungs-Erfassung', 'Disabled')
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Werkstattfeststellung', 'Active')
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Enabled')

  //click on "Optionale Angaben erfassen" / "Enter optional information" button to made the question in step 10 visible
  await direktInformationssystemService.clickEnterOptionalInformationButton(elsaProPage)

  //click on "nein" option for Has the complaint been rectified?
  await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, data.testCase[8].complaintResloved)

  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)
  // To make sure that the page loaded successfully 
  await elsaProPage.waitForLoadState("networkidle")
  //select option Reparatur mit Teiletausch for type of repair
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, data.testCase[8].artDerReparaturValue1)
  //verify option Reparatur mit Teiletausch for type of repair
  await direktInformationssystemService.verifySelectionTypeOfRepairRadioBtn(elsaProPage, data.testCase[8].artDerReparaturValue1)

  //enter text in Additional Information on workshop inspection
  await direktInformationssystemService.enterTextinAdditionalinformationonworkshopinspection(elsaProPage, data.testCase[8].additionalInformation)

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup2] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup2.waitForLoadState('domcontentloaded');

  // select tab from the tab hearder in edit pop up
  await Editpage.selectTab(editPopup2, "Selektion")

  // Making sure edit popup window is loaded successfully   
  await editPopup2.waitForLoadState('domcontentloaded');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup2, data.testCase[8].labelNamesArray3, data.testCase[8].infomediaArray3)
  // the method verifys the label name and selects the infomedia value for it from secondary table
  await Editpage.verifyTheLabelAndSelectInfomediaSecondary(editPopup2, data.testCase[8].labelNamesArray4, data.testCase[8].infomediaArray4)
  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup2, data.testCase[8].labelNamesArray5, data.testCase[8].infomediaArray5)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup2);

  // To make sure that the page loaded successfully 
  await elsaProPage.waitForLoadState("networkidle")
  await page.waitForTimeout(3000);

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[8].codierenText2)


  //click on yes in send query
  await direktInformationssystemService.selectSendingQueryRadioBtnInPage2(elsaProPage, data.testCase[8].queryRadioBtn2)
  // this is because the page is auto refresh after click on the button
  // await page.waitForTimeout(1000);
  await direktInformationssystemService.verifySaveButtonIsDisabled(elsaProPage)
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)
  // click on Abschliessen button
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)
  // To make sure that the page loaded successfully 
  await elsaProPage.waitForLoadState("networkidle")
  // verify text, color & background color of the end of page message box
  await direktInformationssystemService.verifyMessageContainsTextAndVerifyColor(elsaProPage, "Bitte geben Sie die Nummer des schadensbehebenden Originalteils an!")

  // To make sure that the page loaded successfully 
  await elsaProPage.waitForLoadState("networkidle")
  //select option Reparatur ohne Teiletausch for type of repair
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, data.testCase[8].artDerReparaturValue2)
  //verify option Reparatur ohne Teiletausch for type of repair selected
  await direktInformationssystemService.verifySelectionTypeOfRepairRadioBtn(elsaProPage, data.testCase[8].artDerReparaturValue2)
  // this is because the page is auto refresh after click on the button
  await page.waitForTimeout(1000);
  // click on Abschliessen button 
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)
  // this is because the page is auto refresh after click on the button
  // To make sure that the page loaded successfully 
  await elsaProPage.waitForLoadState("networkidle")
  // verify text, color & background color of the end of page message box
  await direktInformationssystemService.verifyMessageContainsTextAndVerifyColor(elsaProPage, "Bitte geben Sie die Nummer der schadensbehebenden Arbeitsposition an!")

  // To make sure that the page loaded successfully 
  await elsaProPage.waitForLoadState("networkidle")
  //select option Lackreparatur for type of repair
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, data.testCase[8].artDerReparaturValue3)
  //verify option Lackreparatur for type of repair selected
  await direktInformationssystemService.verifySelectionTypeOfRepairRadioBtn(elsaProPage, data.testCase[8].artDerReparaturValue3)
  // this is because the page is auto refresh after click on the button
  await page.waitForTimeout(1000);
  // click on Abschliessen button 
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)
  // this is because the page is auto refresh after click on the button
  // To make sure that the page loaded successfully 
  await elsaProPage.waitForLoadState("networkidle")
  // verify text, color & background color of the end of page message box
  await direktInformationssystemService.verifyMessageContainsTextAndVerifyColor(elsaProPage, "Bitte geben Sie die Nummer der schadensbehebenden Arbeitsposition an!")

  // To make sure that the page loaded successfully 
  await elsaProPage.waitForLoadState("networkidle")
  //select option Lackreparatur for type of repair
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, data.testCase[8].artDerReparaturValue3)
  //verify option Lackreparatur for type of repair selected
  await direktInformationssystemService.verifySelectionTypeOfRepairRadioBtn(elsaProPage, data.testCase[8].artDerReparaturValue3)
  // this is because the page is auto refresh after click on the button
  await page.waitForTimeout(1000);
  // click on Nummer des schadensbehebenden Originalteils radion btn
  await direktInformationssystemService.clickOnNumberOfDamageRectifyingRadionBtn(elsaProPage, "PartNumber")
  // click on Abschliessen button 
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)
  // this is because the page is auto refresh after click on the button
  // To make sure that the page loaded successfully 
  await elsaProPage.waitForLoadState("networkidle")
  // verify text, color & background color of the end of page message box
  await direktInformationssystemService.verifyMessageContainsTextAndVerifyColor(elsaProPage, "Bitte geben Sie die Nummer des schadensbehebenden Originalteils an!")

  // select type of repair  Radio btn 
  // enter value "keine" for option --> Keine Reparatur durchgeführt
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(page, "keine")

  // click on Abschliessen button 
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)

  // this method logs out from elsaPro and GRP
  await navigation.logOut(elsaProPage)

    // Close the browser
    await browser.close();
});