const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');

const fs = require('fs');
const path = require('path');

test('UAT_130302_ELP_DISS_047_Kurze variant of workshop approval - Optional information verwerfen_Variant of workshop approval -Discard optional information_VW', async () => {
    // adjust global timeout for this test case only as it takes more than 100000 ms in config file
    test.test.setTimeout(150000)
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);

    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[35].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[35].context)
    await navigation.goToApplication(page, data.testCase[35].elsaApp, data.testCase[35].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[35].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[35].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[35].TestConfigurations[0].customerComplaint)

    // select no in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

    // select no in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[35].labelNamesArray, data.testCase[35].infomediaArray)

    // select the label
    await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[35].labelNamesArray2, data.testCase[35].infomediaArray2)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup);

    // click "OK" in Popup
    await direktInformationssystemService.clickOkInPopup(elsaProPage)

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[35].codierenText)


    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[35].HSTTitle)

    // click exit button in order to close the Handsbuchservicetechnik page
    await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

    // Choose "nein" in "Would you like to make a request?"
    await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, "2")

    //enter text in auftragsnummer box
    await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

    //enter the mileage in mileage feild
    await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[35].mileage)

    //click on next process step button
    await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)

    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(2000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    //click on "Optionale Angaben erfassen" / "Enter optional information" button to made the question in step 10 visible
    await direktInformationssystemService.clickEnterOptionalInformationButton(elsaProPage)
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    //click on "yes" in the radio buttons in Ist die Beanstandung behoben?  / Has the complaint been resolved?
    await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, "ja")

    //enter text in Additional Information on workshop inspection
    await direktInformationssystemService.enterTextinAdditionalinformationonworkshopinspection(elsaProPage, "Test")


    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup2] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup2.waitForLoadState('domcontentloaded');

    // select tab from the tab hearder in edit pop up
    await Editpage.selectTab(editPopup2, "Selektion")

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup2, data.testCase[35].labelNamesArray3, data.testCase[35].infomediaArray3)


    // Click on Übernehmen button
    await Editpage.clickVorläufigÜbernehmenButton(editPopup2);

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await page.waitForTimeout(3000);
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[35].codierenText2)

    //click on save button
    await direktInformationssystemService.clickonSaveBtn(elsaProPage)

    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(2000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    // Click the top DISS page tabs
    await direktInformationssystemService.selectTab(elsaProPage, "Zusammenfassung")
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')

    // Verify the text row in Beanstandungsdaten  when the Zusammenfassung tab is active
    await elsaProPage.waitForTimeout(3000);
    await direktInformationssystemService.checkTextsInBeanstandungsdatenTable(elsaProPage, data.testCase[35].rowLabels, data.testCase[35].expectedTexts)

    // Click the top DISS page tabs
    await elsaProPage.waitForTimeout(3000);
    await direktInformationssystemService.selectTab(elsaProPage, "Werkstattfeststellung")
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Werkstattfeststellung', 'Active')

    //click on "Optionale Angaben löschen" / "Delete optional information" button
    await direktInformationssystemService.clickOptionaleAngabenlöschenButton(elsaProPage)

    // Click the top DISS page tabs
    await elsaProPage.waitForTimeout(3000);

    await direktInformationssystemService.selectTab(elsaProPage, "Zusammenfassung")
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')

    // Verify the text row in Beanstandungsdaten  when the Zusammenfassung tab is active
    await elsaProPage.waitForTimeout(3000);
    await direktInformationssystemService.checkTextsInBeanstandungsdatenTable(elsaProPage, data.testCase[35].rowLabels2, data.testCase[35].expectedTexts2)

    // Click the top DISS page tabs
    await elsaProPage.waitForTimeout(3000);
    await direktInformationssystemService.selectTab(elsaProPage, "Werkstattfeststellung")
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Werkstattfeststellung', 'Active')

    //click on "Optionale Angaben erfassen" / "Enter optional information" button
    await direktInformationssystemService.clickEnterOptionalInformationButton(elsaProPage)

    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    // verify the radio button in Has the complaint been resolved ?
    await direktInformationssystemService.verifyRadioButtonBeanstandungBehoben(elsaProPage, 'ja', 'enabled')
    await direktInformationssystemService.verifyRadioButtonBeanstandungBehoben(elsaProPage, 'nein', 'enabled')

    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)
});
