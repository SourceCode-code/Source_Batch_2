const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { protocolViewer } = require('../../support/pageObjects/DISSPageObjects/protocolViewerPage');
const fs = require('fs');
const path = require('path');

test('119162_DISS_023_006_Liste der Diagnoseprotokolle anzeigen_Filterung mit Hilfe der DropDown-Liste überprüfen', async () => {
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[47].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[47].context)
    await navigation.goToApplication(page, data.testCase[47].elsaApp, data.testCase[47].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');
    await elsaProPage.bringToFront();
    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[47].FIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[47].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage);
    
    // setting the new child window opened after clicking on "Bearbeiten" button
    const [protocolViewerPage] = await Promise.all([
        context.waitForEvent('page'),
        //click Diagnoseprotokoll icon in top of the page
        await direktInformationssystemService.clickDiagnoseProtkollIcon(elsaProPage)
    ]);
    await protocolViewerPage.waitForLoadState('domcontentloaded');
    
    //verify page title
    await protocolViewer.verifyPageTitle(protocolViewerPage);

    //Verify FIN/VIN number in protocol viewer page
    await protocolViewer.verifyFahrzeugidentNr(protocolViewerPage, data.testCase[47].FIN);

    //verify protocoll types
    await protocolViewer.verifyProtocolTypes(protocolViewerPage, data.testCase[47].protocolTypes);
    //sort system in the table and verify it
    await protocolViewer.sortAndVerifySystemInTheTable(protocolViewerPage);

    //select and verify protocol type : selected "Geführte Funktionen" 
    
    await protocolViewer.selectAndVerifySpecificOptionInProtocolTypeDropdown(protocolViewerPage, data.testCase[47].protocolTypes[2]);
    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage);
});