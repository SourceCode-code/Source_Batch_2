const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage')
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { FeedBackMonitor_create } = require('../../support/pageObjects/FBMPageobjects/feedBackMonitor_create')
const { FeedBackMonitor_view } = require('../../support/pageObjects/FBMPageobjects/feedbackMonitor_view')
const { FeedBackMonitor_history } = require('../../support/pageObjects/FBMPageobjects/feedbackMonitor_history')

const fs = require('fs');
const path = require('path');
const { waitForDebugger } = require('inspector');

test('UAT_127514_ELP_DISS_064_Beanstandung - Incomplete Werkstattcodierung_Closing the Complaint - Incomplete Workshop Coding_VW', async () => {
  // adjust global timeout for this test case only as it takes more than 100000 ms in config file
  test.test.setTimeout(300000)
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  // Define the path to the fixture file
  const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
  // Read the JSON file synchronously
  const fixtureData = fs.readFileSync(fixtureFilePath);
  // Parse the JSON data
  const data = JSON.parse(fixtureData);


  // visit website grp prelive, login and click on Elsa Pro application
  await navigation.navigateToBaseUrl(page);
  // login with credentials
  await navigation.loginWithCredentials(page, data.testCase[6].user);
  // change context from GRP page
  await navigation.GRP_Context(page, data.testCase[6].context)
  // Click on the specific Application
  await navigation.goToApplication(page, data.testCase[6].elsaApp, data.testCase[6].user);

  // set the new page opened to elsaProPage
  const allPages = context.pages();
  const elsaProPage = allPages[0];
  await elsaProPage.waitForLoadState('domcontentloaded');

  // verify ELP homepage 
  await homepage.verifyELPHomePage(elsaProPage)
  // change Language to DE
  await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")
  // click on FahrzeugidentifikationBtn
  await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')
  // write FIn and click send button
  await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[6].VIN);

  // click ok message box, click OK on Fahrzeugauswahl
  await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
  await fahrzeugAuswahl.clickOKButton(elsaProPage);
  // click on "Schließen" Button in message box
  await homepage.clickMessageBoxSchließenButton(elsaProPage)
  // click on DISS
  await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[6].link)
  //static wait for stability
  await page.waitForTimeout(5000)
  // click on "Neuen Auftrag Anlegen" buttonY
  await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)
  // enter the customer complaint in the textbox
  await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[6].customerComplaint)
  // select no in is the car brokendown?
  await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, data.testCase[6].carBrokenDown)
  //static wait for stability
  await page.waitForTimeout(1000)
  // // select yes in our workshop because of this complaint?
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, data.testCase[6].alreadyVisitInWorkshop)
  //static wait for stability
  await page.waitForTimeout(1000)
  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);
  // Making sure edit popup window is loaded successfully   
  await editPopup.waitForLoadState('domcontentloaded');
  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[6].labelNamesArray, data.testCase[6].infomediaArray)
  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup);
  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage, true)
  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[6].codierenText)
  //click on HST icon 
  await direktInformationssystemService.clickHstButton(elsaProPage)
  //select the hst document 
  await HandbuchServiceTechnikPage.openDocumentByName(elsaProPage, data.testCase[6].HSTDocument)
  //click on the list icon 
  await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage)
  //enter mileage
  await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[6].mileage)
  //enter the order number 
  await direktInformationssystemService.enterAuftragsnummer(elsaProPage)
  //select no btn in the do you want to send the query
  await direktInformationssystemService.selectSendingQueryRadioBtn(elsaProPage, data.testCase[6].sendingQueryPage1)
  //click on save btn
  await direktInformationssystemService.clickonSaveBtn(elsaProPage)
  //static wait for stability
  await page.waitForTimeout(5000)
  //click on next proceed btn 
  await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)
  //click on yes in send query 
  await direktInformationssystemService.selectSendingQueryRadioBtnInPage2(elsaProPage, data.testCase[6].sendingQueryPage2)
  //static wait for stability
  await page.waitForTimeout(5000)
  //select option Reparatur nach TPI mit Teiletausch	 for type of repair
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, data.testCase[6].repairTypeOption)
  //static wait for stability
  await elsaProPage.waitForTimeout(2000)
  //click yes in the pop up
  await direktInformationssystemService.selectOptionInHaveYouWorkedAccordingToTPIPopup(elsaProPage, data.testCase[6].popupConfirmation)
  //click on apply btn
  await direktInformationssystemService.clickApplySelectionInHaveYouWorkedAccordingToTPIPopup(elsaProPage)
  //static wait for stability
  await elsaProPage.waitForTimeout(2000)
  //click on No in has complaint been rectifed  radio btn
  await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, data.testCase[6].complaintResolved)
  //enter the number in  Nummer des schadensbehebenden input box 
  await direktInformationssystemService.fillPartNumberInputs(elsaProPage, data.testCase[6].partNumber)
  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup2] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);
  // Making sure edit popup window is loaded successfully   
  await editPopup2.waitForLoadState('domcontentloaded');
  //enter the search text in input box 
  await Editpage.enterSearchText(editPopup2, data.testCase[6].searchText)
  //click on search btn on number
  await Editpage.ClickonSearchfornumberbox(editPopup2)
  //click on search btn
  await Editpage.ClickonSearchforsearchtextbox(editPopup2)
  //slect the text form the search box 
  await Editpage.SelectThecorrectEntry(editPopup2, data.testCase[6].searchResultText)
  //click on apply btn
  await Editpage.clickVorläufigÜbernehmenButton(editPopup2);
  //enter text in Additional Information on workshop inspection
  await direktInformationssystemService.enterTextinAdditionalinformationonworkshopinspection(elsaProPage, "test")
  //static wait for stability
  await elsaProPage.waitForTimeout(2000)
  //click on end btn
  await direktInformationssystemService.ClickonEndBtn(elsaProPage)
  //static wait for stability
  await elsaProPage.waitForTimeout(5000)
  // setting the new child window opened after clicking on "Feedback" button
  const [feedbackpopup] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    direktInformationssystemService.clickonFeedbackoption(elsaProPage)
  ]);
  //enter the error in description text
  await FeedBackMonitor_create.enterErrorDescripition(feedbackpopup, data.testCase[6].descriptiontext)
  //click on send button
  await FeedBackMonitor_create.clickonSendBtn(feedbackpopup)
  //get the feedback created id
  let CreatedID = await FeedBackMonitor_create.GettheCreatedID(feedbackpopup)
  console.log(CreatedID)
  //click on close Button
  await FeedBackMonitor_create.clickonCloseButton(feedbackpopup)
  //click on the close infomedia
  await direktInformationssystemService.clickonHSTButtonInPopup(elsaProPage)
  //static wait for stability
  await elsaProPage.waitForTimeout(2000)
  //click on ok btn in popup 
  await direktInformationssystemService.clickonOKoption(page)
  //static wait for stability
  await elsaProPage.waitForTimeout(2000)
  //click on the close infomedia
  await direktInformationssystemService.closeDissinfomediabtn(elsaProPage)
  //click on logout btn form headers 
  await headers.clickOnLogOutBtn(elsaProPage)
  // change context from GRP page
  await navigation.GRP_Context(page, data.testCase[6].context2)
  //static wait for stability
  await elsaProPage.waitForTimeout(2000)
  // Click on the specific Application
  await navigation.goToApplication(page, data.testCase[6].fbmapp, data.testCase[6].user);
  // set the new page opened to elsaProPage
  const Fbmpage = allPages[0];
  await Fbmpage.waitForLoadState('domcontentloaded');
  // Ensure the new page is fully loaded
  await Fbmpage.waitForLoadState('domcontentloaded');
  //static wait for stability
  await Fbmpage.waitForTimeout(2000)
  //enter the created fbm id
  await FeedBackMonitor_view.enterfeedbackidinputbox(Fbmpage, CreatedID)
  //click on update button
  await FeedBackMonitor_view.clickonUpdatebtn(Fbmpage)
  // setting the new child window opened after clicking on "Bearbeiten" button
  const [Historytab] = await Promise.all([
    context.waitForEvent('page'),
    //click on history icon
    await FeedBackMonitor_view.clickonHistoryIcon(Fbmpage)
  ]);
  //verify the error decription in history page
  await FeedBackMonitor_history.verifyErrorDescription(Historytab, data.testCase[6].descriptiontext)
  //close the histot=ry page
  await Historytab.close()
  //close the feedback view page 
  await Fbmpage.close()

  // Close the browser
  await browser.close();
});