const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');

const fs = require('fs');
const path = require('path');

test('UAT_129671_ELP_DISS_004_DISS erneut zum einem ElsaPro Vorgang aufrufen_DISS to call an ElsaPro operation again_Audi', async () => {
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[63].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[63].TestConfigurations[1].context)
    await navigation.goToApplication(page, data.testCase[63].elsaApp, data.testCase[63].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[63].TestConfigurations[1].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[63].link)
    await elsaProPage.waitForTimeout(3000);
    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await elsaProPage.waitForTimeout(1000)
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[63].customerComplaint)

    //click on save btn 
    await direktInformationssystemService.clickonSaveBtn(elsaProPage)
    await elsaProPage.waitForTimeout(3000)
    // this is because the page is auto refresh after click on the button
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    //click on list of comaplaint btn 
    await direktInformationssystemService.clickonListederBeanstandungen(elsaProPage)

    // Verify table headers in 'Liste der beanstandungen' page
    await elsaProPage.waitForTimeout(2000)
    await direktInformationssystemService.verifyComplaintsForOrderTableIsVisible(elsaProPage)
    // Verify text in complain table entry
    await direktInformationssystemService.verifyComplainEntryText(elsaProPage, data.testCase[63].customerComplaint, 0)

    //click on 'X' icon to close page
    await direktInformationssystemService.closeDissinfomediabtn(elsaProPage)

    // click on DISS
    await elsaProPage.waitForTimeout(3000);
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[63].link)

    // Verify table headers in 'Liste der beanstandungen' page
    await direktInformationssystemService.verifyComplaintsForOrderTableIsVisible(elsaProPage)

    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)
});