const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');
const { common } = require('../../support/common');

const fs = require('fs');
const path = require('path');

test('UAT_127500_ELP_DISS_079_Auftragsdaten bearbeiten_Edit order data_VWN', async () => {
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[60].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[60].TestConfigurations[4].context)
    await navigation.goToApplication(page, data.testCase[60].elsaApp, data.testCase[60].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[60].TestConfigurations[4].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[60].link)


    //enter order number in search for it
    await direktInformationssystemService.enterOrderNumberAndClickSearch(elsaProPage, data.testCase[60].TestConfigurations[4].orderNumber)

    // Click on the "Search" button
    await direktInformationssystemService.clickOnSearchField(elsaProPage)

    //click on list of complaint symbol
    await direktInformationssystemService.clickOnListOfComplaintsForOrder(elsaProPage, data.testCase[60].TestConfigurations[4].orderNumber)


    const dateBefore = await direktInformationssystemService.getValueFromAuftragsdatenTable(elsaProPage, "Auftragsdatum:")
    const mileageBefore = ((await direktInformationssystemService.getValueFromAuftragsdatenTable(elsaProPage, "Laufleistung:")).toString().split("\n"))[0]
    const newOrderDate = await common.addRandomDaysToDate(await common.getTodayDate(-20), 5, 10)
    const newMileage = await common.getRandomIntegerBetween(5000, 50000)

    // click "Edit this complaint"\"Diese Beanstandung bearbeiten" button in complaints list
    await direktInformationssystemService.clickEditThisComplaintButtonForBAID(elsaProPage, data.testCase[60].TestConfigurations[4].BAID)

    await elsaProPage.waitForLoadState("load")

    //verify mileage in mileage feild
    await direktInformationssystemService.verifyMileage(elsaProPage, mileageBefore)
    // verify order date in respective fields and verifies this date
    await direktInformationssystemService.verifyOrderDate(elsaProPage, dateBefore)

    // edit order data 
    await direktInformationssystemService.clickEditOrderData(elsaProPage)
    await elsaProPage.waitForTimeout(2000);
    // this is because the page is auto refresh after click on the button
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Beanstandungs-Erfassung', 'Active')
    //enter the new mileage in mileage feild
    await direktInformationssystemService.enterMileage(elsaProPage, newMileage, true)
    // type order date in respective fields and verifies this date
    await direktInformationssystemService.typeOrderDate(elsaProPage, newOrderDate)
    //click on save btn
    await direktInformationssystemService.clickonSaveBtn(elsaProPage)
    await elsaProPage.waitForTimeout(2000);
    // this is because the page is auto refresh after click on the button
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    //verify mileage in mileage feild
    await direktInformationssystemService.verifyMileage(elsaProPage, newMileage)

    // verify order date in respective fields and verifies this date
    await direktInformationssystemService.verifyOrderDate(elsaProPage, newOrderDate)
    //click on close infomedia
    await direktInformationssystemService.closeDissinfomediabtn(elsaProPage)

    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)
    // Close the browser
    await browser.close();
});