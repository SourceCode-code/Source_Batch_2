const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');


const fs = require('fs');
const path = require('path');

test('UAT_127469_ELP_DISS_054_Steuerung der Schadensbehebenen Arbeitsposition - Ersatzteil durch die Reparaturart_Control of the repaired working position - spare part by the repair type_VW', async () => {
  // adjust global timeout for this test case only as it takes more than 100000 ms in config file
  test.test.setTimeout(150000)
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  // Define the path to the fixture file
  const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
  // Read the JSON file synchronously
  const fixtureData = fs.readFileSync(fixtureFilePath);
  // Parse the JSON data
  const data = JSON.parse(fixtureData);


  // visit website grp prelive, login and click on Elsa Pro application
  await navigation.navigateToBaseUrl(page);
  // login with credentials
  await navigation.loginWithCredentials(page, data.testCase[33].user);
  // change context from GRP page
  await navigation.GRP_Context(page, data.testCase[33].context)
  // Click on specific Application 
  await navigation.goToApplication(page, data.testCase[33].elsaApp, data.testCase[33].user)
  // set the new page opened to elsaProPage
  const allPages = context.pages();
  const elsaProPage = allPages[0];
  await elsaProPage.waitForLoadState('domcontentloaded');

  // verify ELP homepage 
  await homepage.verifyELPHomePage(elsaProPage)
  // change Language to DE
  await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

  // click on FahrzeugidentifikationBtn
  await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

  // write FIn and click send button
  await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[33].TestConfigurations[0].VIN);

  // click ok message box, click OK on Fahrzeugauswahl
  await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
  await fahrzeugAuswahl.clickOKButton(elsaProPage);

  // click on DISS
  await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[33].link)

  // click on "Neuen Auftrag Anlegen" button
  await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

  //enter text in Customer Complaint box
  await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[33].TestConfigurations[0].customerComplaint)

  // select no in is the car brokendown?
  await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "ja")

  // select no in our workshop because of this complaint?
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup.waitForLoadState('domcontentloaded');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[33].labelNamesArray, data.testCase[33].infomediaArray)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup);

  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage)

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[33].codierenText)
  //click on HST Button In DISS Page
  await direktInformationssystemService.clickHstButton(elsaProPage)

  // click exit button in order to close the Handsbuchservicetechnik page
  await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

  await page.waitForTimeout(3000);

  //enter text in auftragsnummer box
  await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

  //enter the mileage in mileage feild
  await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[33].mileage)

  //select no in would you like to make request
  await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, 2)

  //click on save btn
  await direktInformationssystemService.clickSpeichernButton(elsaProPage)
  await elsaProPage.waitForTimeout(2000)

  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

  //click on next proceed button
  await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)

  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

  await page.waitForTimeout(3000);

  //select type of repair selected as Reparatur mit Teiletausch
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "mitteil")

  //verify type of repair selected as Reparatur mit Teiletausch
  await direktInformationssystemService.verifySelectionTypeOfRepairRadioBtn(elsaProPage, "mitteil")

  // verify the radio button in Nummer des schadensbehebenden Originalteils / Nummer der schadensbehebenden Arbeitsposition
  await direktInformationssystemService.verifyRadioButtonOriginalteilsOrArbeitsposition(elsaProPage, 'Nummer des schadensbehebenden Originalteils', 'enabled')

  // click on ElsaPro Auftragsdaten btn
  await direktInformationssystemService.clickonElsaProAuftragsdaten(elsaProPage)

  //click ok in the popup 
  await direktInformationssystemService.clickonOKbtninElsaProAuftragsdatenPopUp(elsaProPage)

  //select type of repair selected as Reparatur mit Teiletausch
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "ohneteil")

  //verify type of repair selected as Reparatur mit Teiletausch
  await direktInformationssystemService.verifySelectionTypeOfRepairRadioBtn(elsaProPage, "ohneteil")

  await page.waitForTimeout(2000);

  await direktInformationssystemService.verifyRadioButtonOriginalteilsOrArbeitsposition(elsaProPage, 'Nummer der schadensbehebenden Arbeitsposition', 'enabled')

  //click on finish btn 
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)

  //select type of repair selected as Paint repair
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "lack")

  //verify type of repair selected as Paint repair
  await direktInformationssystemService.verifySelectionTypeOfRepairRadioBtn(elsaProPage, "lack")

  await page.waitForTimeout(2000);
  // verify the radio button in Nummer der schadensbehebenden Arbeitsposition
  await direktInformationssystemService.verifyRadioButtonOriginalteilsOrArbeitsposition(elsaProPage, 'Nummer der schadensbehebenden Arbeitsposition', 'enabled')

  // verify the radio button in Nummer des schadensbehebenden Originalteils
  await direktInformationssystemService.verifyRadioButtonOriginalteilsOrArbeitsposition(elsaProPage, 'Nummer des schadensbehebenden Originalteils', 'enabled')

  //select type of repair selected as No repair performed
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "keine")

  //verify type of repair selected as No repair performed
  await direktInformationssystemService.verifySelectionTypeOfRepairRadioBtn(elsaProPage, "keine")

  //click on HST Btn in page 2
  await direktInformationssystemService.clickHstButtonSecondState(elsaProPage)

  //open the given documnet 
  await HandbuchServiceTechnikPage.searchDocumentByName(elsaProPage, data.testCase[33].documentNumber)

  //this method open document after search on document
  await HandbuchServiceTechnikPage.openDocumentFromSearchResult(elsaProPage, data.testCase[33].documentNumber)

  //click on copy hst to diss
  await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage)
  await page.waitForTimeout(3000);
  //select type of repair selected as Reparatur nach TPI mit Teiletausch	
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "mitteiltpl")
  await page.waitForTimeout(3000);
  //click on option 	Ja, TPI übernehmen in popup
  await direktInformationssystemService.selectOptionInHaveYouWorkedAccordingToTPIPopup(elsaProPage, "TPIReparaturJ")
  //click on apply in TPI POPup
  await direktInformationssystemService.clickApplySelectionInHaveYouWorkedAccordingToTPIPopup(elsaProPage)
  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

  //select type of repair selected as Reparatur nach TPI mit Teiletausch	
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "ohneteiltpl")
  await page.waitForTimeout(3000);
  //click on option 	Ja, TPI übernehmen in popup
  await direktInformationssystemService.selectOptionInHaveYouWorkedAccordingToTPIPopup(elsaProPage, "TPIReparaturJ")
  await page.waitForTimeout(3000);
  //click on apply in TPI POPup
  await direktInformationssystemService.clickApplySelectionInHaveYouWorkedAccordingToTPIPopup(elsaProPage)
  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)


  // this method logs out from elsaPro and GRP
  await navigation.logOut(elsaProPage)
});