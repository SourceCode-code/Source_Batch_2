const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');
const { EingangPage } = require('../../support/pageObjects/DISSMPageObjects/eingangPage');

const fs = require('fs');
const path = require('path');
const { AES } = require('crypto-js');

test('UAT_128182_ ELP_DISS_095_Anfrage Meldepflicht lt. HST versenden_request Reporting obligation according to HST_VW', async () => {
    // adjust global timeout for this test case only as it takes more than 100000 ms in config file
    test.test.setTimeout(200000)
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);

    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[41].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[41].context)
    //selecting the ELP app
    await navigation.goToApplication(page, data.testCase[41].elsaApp, data.testCase[41].user);
    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[41].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[41].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[41].TestConfigurations[0].customerComplaint)

    // select no in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

    // select no in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[41].labelNamesArray, data.testCase[41].infomediaArray)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup);

    // click "OK" in Popup
    await direktInformationssystemService.clickOkInPopup(elsaProPage)

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[41].codierenText)

    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[41].HSTTitle)

    //click on given link 
    //Note here in test case given document name "Obligation to report deviations in the process of field action (2040432/15)"
    //but this document name not availble so taken "Meldepflicht bei Klärungen und Rückfragen zu Feldmaßnahmen   (2040432/20)"
    await HandbuchServiceTechnikPage.openDocumentByName(elsaProPage, "2040432/20")
    //this method click on "HST nach DISS übernehmen"/"Copy HST to DISS" (📋) button after open the document
    await elsaProPage.waitForTimeout(3000);
    await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage)

    //enter text in auftragsnummer box
    await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

    //enter the mileage in mileage feild
    await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[41].mileage)

    // this is because the page is auto refresh after click on the button
    await direktInformationssystemService.clickonSaveBtn(elsaProPage)
    //Static wait for 2 seconds (2000 milliseconds)
    await elsaProPage.waitForTimeout(2000);
    // Click the top DISS page tabs
    await direktInformationssystemService.selectTab(elsaProPage, "Meldepflicht lt HST")
    //Static wait for 2 seconds (2000 milliseconds)
    await elsaProPage.waitForTimeout(2000);
    // verify "Meldepflicht lt HST" tab is active
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Meldepflicht lt HST', 'ActiveAnfrage')
    // this is because the page is auto refresh after click on the button
    await direktInformationssystemService.clickonSaveBtn(elsaProPage)
    //Static wait for 2 seconds (2000 milliseconds)
    await elsaProPage.waitForTimeout(2000);
    //enter text in Anmerkung zum Diagnoseergebnis:/Note on the diagnostic result: box
    await direktInformationssystemService.enterDiagnoseergebnis(elsaProPage, "TEST")

    //Static wait for 2 seconds (2000 milliseconds)
    await elsaProPage.waitForTimeout(2000);

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup2] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButtonOnMeldepflichtPage(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup2.waitForLoadState('domcontentloaded');

    // select tab from the tab hearder in edit pop up
    await Editpage.selectTab(editPopup2, "Selektion")

    // Making sure edit popup window is loaded successfully   
    await editPopup2.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup2, data.testCase[41].labelNamesArray3, data.testCase[41].infomediaArray3)

    // Click on Übernehmen button
    await page.waitForTimeout(3000)
    await Editpage.clickÜbernehmenButton(editPopup2)

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await elsaProPage.waitForTimeout(3000)
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[41].codierenText2)

    await direktInformationssystemService.clickOnSendBtn(elsaProPage)

    await direktInformationssystemService.verifyMessageAfterClickSendBtn(elsaProPage, "Die Anfrage wurde versendet und kann nicht mehr geändert werden!", "rgb(128, 0, 0)")

    // select the Zusammenfassung tab
    await direktInformationssystemService.selectTab(elsaProPage, "Zusammenfassung")
    //Static wait for 2 seconds (2000 milliseconds)
    await elsaProPage.waitForTimeout(2000);
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')

    // get BAID 
    const BA_ID = await direktInformationssystemService.getValueFromBeanstandungsdatenTable(elsaProPage, "BA-ID:")
    await console.log("BA_ID", BA_ID)
    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)

    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[41].user);

    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[41].context2)
    //static wait for stability
    await page.waitForTimeout(2000)
    // Click on the specific Application
    await navigation.goToApplication(page, data.testCase[41].dissmApp, data.testCase[41].user);
    await page.waitForTimeout(3000);

    // set the new page opened to elsaProPage
    const elsaProPage2 = (context.pages())[0];
    await elsaProPage2.waitForLoadState('domcontentloaded');

    await EingangPage.filterTable(elsaProPage2, "test uk 2")
    await EingangPage.sortTableByColumn(elsaProPage2, "BA-ID", "desc")

    //prepare rowValues object to click on Lesen on correct row
    let rowValues = {
        "BA-ID": BA_ID,
        "FG.-NR.": data.testCase[41].TestConfigurations[0].VIN
    }

    // click on lesen button
    await EingangPage.clickOnLesen(elsaProPage2, rowValues)

    // verify BA-ID value
    await EingangPage.verifyValueFromAnfrageTable(elsaProPage2, "BA-ID:", BA_ID)

    // verify Rückinfozeit +2 hrs or +01:5x as some times it decreases to less than +2 hrs with one or two minutes
    await EingangPage.verifyValueFromAnfrageTable(elsaProPage2, "Rückinfozeit:", "\\+01:5|\\+02:00", true)

    await EingangPage.verifyWorkshopCoding(elsaProPage2, data.testCase[41].codierenText2)

    await navigation.navigateToBaseUrl(elsaProPage2);

    await elsaProPage2.waitForTimeout(2000)
    // this method logs out from elsaPro and GRP
    await navigation.logOutGRP(elsaProPage2)
});