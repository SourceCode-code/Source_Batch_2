const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');

const fs = require('fs');
const path = require('path');

test('UAT_129670_ELP_DISS_018_WHR Popup ohne TPI Link_WHR popup without TPI link_VW', async () => {
  // adjust global timeout for this test case only as it takes more than 100000 ms in config file
  test.test.setTimeout(150000)
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  // Define the path to the fixture file
  const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
  // Read the JSON file synchronously
  const fixtureData = fs.readFileSync(fixtureFilePath);
  // Parse the JSON data
  const data = JSON.parse(fixtureData);


  // visit website grp prelive, login and click on Elsa Pro application
  await navigation.navigateToBaseUrl(page);
  // login with credentials
  await navigation.loginWithCredentials(page, data.testCase[31].user);
  // change context from GRP page
  await navigation.GRP_Context(page, data.testCase[31].context)
  await navigation.goToApplication(page, data.testCase[31].elsaApp, data.testCase[31].user);

  // set the new page opened to elsaProPage
  const allPages = context.pages();
  const elsaProPage = allPages[0];
  await elsaProPage.waitForLoadState('domcontentloaded');

  // verify ELP homepage
  await homepage.verifyELPHomePage(elsaProPage)
  // change Language to DE
  await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

  // click on FahrzeugidentifikationBtn
  await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

  // write FIn and click send button
  await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[31].TestConfigurations[0].VIN);

  // click ok message box, click OK on Fahrzeugauswahl
  await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
  await fahrzeugAuswahl.clickOKButton(elsaProPage);

  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);
  // click on DISS
  await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[31].link)

  // click on "Neuen Auftrag Anlegen" button
  await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

  //enter text in Customer Complaint box
  await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[31].TestConfigurations[0].customerComplaint1)

  // select no in is the car brokendown?
  await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

  // select no in our workshop because of this complaint?
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup.waitForLoadState('domcontentloaded');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[31].labelNamesArray, data.testCase[31].infomediaArray)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup);

  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage)

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[31].codierenText1)

  //click on HST Button In DISS Page
  await direktInformationssystemService.clickHstButton(elsaProPage)

  //this method verifies the HST page title
  await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[31].HSTTitle)

  // click exit button in order to close the Handsbuchservicetechnik page
  await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

  // Choose "no" in "Would you like to make a request?"
  await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, "2")

  //enter text in auftragsnummer box
  await direktInformationssystemService.enterAuftragsnummer(elsaProPage)
  // click on "Speichern"/ "Save" button
  await direktInformationssystemService.clickSpeichernButton(elsaProPage)
  //Static wait for 2 seconds (2000 milliseconds)
  await elsaProPage.waitForTimeout(2000);

  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

  //click on Abbrechen/Cancel button
  await direktInformationssystemService.clickonAbbrechennBtn(elsaProPage)

  //click on close infomedia 
  //Static wait for 2 seconds (2000 milliseconds)
  await elsaProPage.waitForTimeout(2000);
  await direktInformationssystemService.closeDissinfomediabtn(elsaProPage)

  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);

  // verify ELP homepage
  await homepage.verifyELPHomePage(elsaProPage)
  // change Language to DE
  await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

  // click on Kunde / Fzg suchen Btn
  await headers.clickBtnOnHeader(elsaProPage, 'Kunde / Fzg suchen')
  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);

  // click on FahrzeugidentifikationBtn
  await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

  // write FIn and click send button
  await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[31].TestConfigurations[0].VIN);

  // click ok message box, click OK on Fahrzeugauswahl
  await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
  await fahrzeugAuswahl.clickOKButton(elsaProPage);

  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);
  // click on DISS
  await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[31].link)

  // click on "Neuen Auftrag Anlegen" button
  await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

  //enter text in Customer Complaint box
  await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[31].TestConfigurations[0].customerComplaint2)

  // select no in is the car brokendown?
  await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

  // select no in our workshop because of this complaint?
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup_2] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup_2.waitForLoadState('domcontentloaded');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup_2, data.testCase[31].labelNamesArray, data.testCase[31].infomediaArray2)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup_2);

  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage)

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[31].codierenText2)

  //click on HST Button In DISS Page
  await direktInformationssystemService.clickHstButton(elsaProPage)

  // //this method verifies the HST page title
  await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[31].HSTTitle)

  // click exit button in order to close the Handsbuchservicetechnik page
  await elsaProPage.waitForTimeout(2000);
  await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

  // Choose "no" in "Would you like to make a request?"
  await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, "2")

  // enter text in auftragsnummer box
  await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

  // click on "Speichern"/ "Save" button
  await direktInformationssystemService.clickSpeichernButton(elsaProPage)

  // setting the new child window opened after clicking on "Bearbeiten" button
  await elsaProPage.waitForTimeout(2000);
  const [editPopup_3] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup_3.waitForLoadState('domcontentloaded');

  // select the label
  await Editpage.clickOnTheLabel(editPopup_3, ["Hauptgruppe"])
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup_3, ["Hauptgruppe"], ["Karosserie"])

  // the method verifys the label name and selects the infomedia value for it
  await elsaProPage.waitForTimeout(2000);
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup_3, data.testCase[31].labelNamesArray2, data.testCase[31].infomediaArray3)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup_3);

  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage)

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[31].codierenText3)

  // this method logs out from elsaPro and GRP
  await navigation.logOut(elsaProPage)
});