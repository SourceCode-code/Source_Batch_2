const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { FahrzeugHistorie } = require('../../support/pageObjects/elsaPageObjects/fahrzeugHistoriePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');
const { teschnischeProduktinformation } = require('../../support/pageObjects/elsaPageObjects/teschnischeProduktinformationPage');
const { common } = require('../../support/common');

const fs = require('fs');
const path = require('path');

test('UAT_129721_ELP_DISS_019_WHR Popup mit TPI Link_VW', async () => {
    // adjust global timeout for this test case only as it takes more than 100000 ms in config file
    test.test.setTimeout(150000)
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[39].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[39].context)
    await navigation.goToApplication(page, data.testCase[39].elsaApp, data.testCase[39].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[39].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[39].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[39].TestConfigurations[0].customerComplaint)

    // select no in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

    // select no in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[39].labelNamesArray, data.testCase[39].infomediaArray)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup);
    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click "OK" in Popup
    await direktInformationssystemService.clickOkInPopup(elsaProPage)
    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[39].codierenText)

    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[39].HSTTitle)
    // this method verifies the open tree nodes according to the array that is passed as an attribute: nodeTexts
    await HandbuchServiceTechnikPage.clickNodesAndLinks(elsaProPage, data.testCase[39].nodeTexts)

    await page.waitForTimeout(5000)
    //select the hst document 
    await HandbuchServiceTechnikPage.openDocumentByName(elsaProPage, data.testCase[39].HSTDocument)

    //click on copy hst to diss
    await elsaProPage.waitForTimeout(2000);
    await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage)
    // click exit button in order to close the Handsbuchservicetechnik page
    await elsaProPage.waitForTimeout(2000);

    //enter text in auftragsnummer box
    await direktInformationssystemService.enterAuftragsnummer(elsaProPage)
    //enter the mileage in mileage feild
    await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[39].mileage)
    await elsaProPage.waitForTimeout(2000);

    //click on next proceed button
    await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)
    await elsaProPage.waitForTimeout(5000);

    //select type of repair selected as Reparatur nach TPI mit Teiletausch
    await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "mitteiltpl")

    //click on option 	Ja, TPI übernehmen in popup
    await direktInformationssystemService.selectOptionInHaveYouWorkedAccordingToTPIPopup(elsaProPage, "TPIReparaturJ")
    await elsaProPage.waitForTimeout(3000);
    //click on apply in TPI POPup
    await direktInformationssystemService.clickApplySelectionInHaveYouWorkedAccordingToTPIPopup(elsaProPage)
    await elsaProPage.waitForTimeout(3000);
    // this is because the page is auto refresh after click on the button
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)
    // select  yes option for Has the complaint been rectified?
    await direktInformationssystemService.selectComplaintreslovedRadioBtn(page, "ja")

    //enter number in  Nummer des schadensbehebenden Originalteils
    await direktInformationssystemService.enterNumberinNummerDesSchadensbehebenden(elsaProPage, ["5k0", "423", "445", "54", ""])

    //   await direktInformationssystemService.verifyRadioButtonOriginalteilsOrArbeitsposition(elsaProPage, 'Nummer der schadensbehebenden Arbeitsposition', 'enabled')

    //click on finish btn 
    await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)

    // // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)

    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);

    // change context from GRP page
    await page.waitForTimeout(5000)
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[39].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[39].context)
    await navigation.goToApplication(page, data.testCase[39].elsaApp, data.testCase[39].user);

    // set the new page opened to elsaProPage
    const elsaProPagenew = allPages[0];
    await elsaProPagenew.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPagenew)

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPagenew, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPagenew, data.testCase[39].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPagenew);
    await fahrzeugAuswahl.clickOKButton(elsaProPagenew);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPagenew, data.testCase[39].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPagenew)

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPagenew, data.testCase[39].TestConfigurations[0].customerComplaint2)

    // select no in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPagenew, "nein")

    // select no in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPagenew, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopupnew] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPagenew)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopupnew.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopupnew, data.testCase[39].labelNamesArray, data.testCase[39].infomediaArray)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopupnew);

    // get today's date 
    const date = await common.getTodayDate()

    // click on "Transaction Number" link
    await direktInformationssystemService.cliclOnTransactionNumberLinkInSuspectedRepeatRepair(elsaProPagenew, date, data.testCase[39].transactionNumber)

    // set the new page opened to  technical product information page
    await elsaProPage.waitForTimeout(3000);
    const technicalProductInformationPage = context.pages()[(context.pages().length) - 1];

    //Verify VIN History Page 
    await teschnischeProduktinformation.verifyTeschnischeProduktinformationPageTitle(technicalProductInformationPage, "Technische Produktinformation")

    //close technical ProductInformation Page
    await technicalProductInformationPage.close();

    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPagenew)

    // Close the browser
    await browser.close();
});