const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');

const fs = require('fs');
const path = require('path');

test('UAT_127391_ELP_DISS_051_Steuerung der Reparaturarten ohne TPI_Control of repair types without TPI_VW', async () => {
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[5].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[5].context)
    await navigation.goToApplication(page, data.testCase[1].elsaApp, data.testCase[1].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[5].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[5].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[5].customerComplaint)

    // select no in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

    // select "nein" in Were you in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[5].labelNamesArray, data.testCase[5].infomediaArray)

    // select the label
    await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[5].labelNamesArray2, data.testCase[5].infomediaArray2)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup);

    // click "OK" in Popup
    await direktInformationssystemService.clickOkInPopup(elsaProPage, true)

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[5].codierenText)

    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[5].HSTTitle)

    // click exit button in order to close the Handsbuchservicetechnik page
    await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

    // Choose "nein" in "Would you like to make a request?"
    await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, "2")

    //enter text in auftragsnummer box
    await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

    //enter the mileage in mileage feild
    await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[5].mileage)

    //click on next process step button
    await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)

    //verify the status of top DISS page tabs
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Beanstandungs-Erfassung', 'Disabled')
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Werkstattfeststellung', 'Active')

    //verify if the radio buttons in Art der Reparatur are enabled or disabled
    await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Reparatur mit Teiletausch', 'enabled')
    await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Reparatur ohne Teiletausch', 'enabled')
    await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Lackreparatur', 'enabled')
    await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Keine Reparatur durchgeführt', 'enabled')

    await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Reparatur nach TPI mit Teiletausch', 'disabled')
    await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Reparatur nach TPI ohne Teiletausch', 'disabled')

    // // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)

    // Close the browser
    await browser.close();
});