const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');
const { EingangPage } = require('../../support/pageObjects/DISSMPageObjects/eingangPage');
const { AuftraglistePage } = require('../../support/pageObjects/DISSMPageObjects/auftragliste');
const fs = require('fs');
const path = require('path');

test('UAT_130614_ELP_DISS_089_Lackunterbeanstandung erzeugen_Creating a Paint Undercomplaint_VW', async () => {
  // adjust global timeout for this test case only as it takes more than 100000 ms in config file
  test.test.setTimeout(240000)
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  // Define the path to the fixture file
  const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
  // Read the JSON file synchronously
  const fixtureData = fs.readFileSync(fixtureFilePath);
  // Parse the JSON data
  const data = JSON.parse(fixtureData);


  // visit website grp prelive, login and click on Elsa Pro application
  await navigation.navigateToBaseUrl(page);
  // login with credentials
  await navigation.loginWithCredentials(page, data.testCase[43].user);
  // change context from GRP page
  await navigation.GRP_Context(page, data.testCase[43].context)
  await navigation.goToApplication(page, data.testCase[43].elsaApp, data.testCase[43].user);

  // set the new page opened to elsaProPage
  const allPages = context.pages();
  const elsaProPage = allPages[0];
  await elsaProPage.waitForLoadState('domcontentloaded');

  // verify ELP homepage
  await homepage.verifyELPHomePage(elsaProPage)
  // change Language to DE
  await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

  // click on FahrzeugidentifikationBtn
  await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

  // write FIn and click send button
  await elsaProPage.waitForTimeout(3000);
  await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[43].TestConfigurations[0].VIN);

  // click ok message box, click OK on Fahrzeugauswahl
  await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
  await fahrzeugAuswahl.clickOKButton(elsaProPage);

  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);
  // click on DISS
  await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[43].link)

  // click on "Neuen Auftrag Anlegen" button
  await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

  //enter text in Customer Complaint box
  await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[43].customerComplaint)

  // select no in is the car brokendown?
  await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

  // select no in our workshop because of this complaint?
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup.waitForLoadState('domcontentloaded');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[43].labelNamesArray, data.testCase[43].infomediaArray)

  // select the label
  await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[43].labelNamesArray2, data.testCase[43].infomediaArray2)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup);

  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage)

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[43].codierenText)

  //click on HST Button In DISS Page
  await direktInformationssystemService.clickHstButton(elsaProPage)

  //this method verifies the HST page title
  await elsaProPage.waitForTimeout(3000);
  await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[43].HSTTitle)

  // click exit button in order to close the Handsbuchservicetechnik page
  await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

  //enter text in auftragsnummer box
  let auftragsnummer = await direktInformationssystemService.enterAuftragsnummer(elsaProPage)
  await console.log("auftragsnummer")
  await console.log(auftragsnummer)

  //enter the mileage in mileage feild
  await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[43].mileage)

  // the method below select (Yes) radio button in 	"Paint Complaint with Release Costing"
  await direktInformationssystemService.selectRadioBtnInPaintComplaint(elsaProPage, "0")

  // Click on System Anzeigen Icon
  await direktInformationssystemService.clickOnSystemAnzeigen(elsaProPage)

  await direktInformationssystemService.clickOnLinkInSystemsLinks(elsaProPage, "DISS-M")
  await elsaProPage.waitForTimeout(10000)
  const allPages1 = await context.pages();
  const DissM = await allPages1[allPages1.length - 1];
  await DissM.waitForLoadState('load');
  await DissM.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
  await DissM.waitForTimeout(2000);
  await EingangPage.clickSpecificTabAfterOpeningDissMonitor(DissM, 'Auftragliste')

  await AuftraglistePage.fillAuftragsnummer(DissM, auftragsnummer)
  await AuftraglistePage.clickOnSearchButton(DissM)
  await AuftraglistePage.verifyColumnValueForOrderNumber(DissM, auftragsnummer, "BA/Anfr", "1/1")

  // Click on System Verbergen Icon to hide the links menue
  await direktInformationssystemService.clickOnSystemeVerbergen(elsaProPage)

  // clicks on "Record additional paint complaints" / "Zusätzliche Lackbeanstandung erfassen" button
  await direktInformationssystemService.clickOnRecordAdditionalPaintComplaintsButton(elsaProPage)
  await elsaProPage.waitForTimeout(30000);
  // clicks on "Record additional paint complaints" / "Zusätzliche Lackbeanstandung erfassen" button
  await direktInformationssystemService.clickOnRecordAdditionalPaintComplaintsButton(elsaProPage)
  await elsaProPage.waitForTimeout(5000)
  await DissM.reload()
  await AuftraglistePage.verifyColumnValueForOrderNumber(DissM, auftragsnummer, "BA/Anfr", "3/1")
  // this method logs out from elsaPro and GRP
  await navigation.logOut(elsaProPage)
});