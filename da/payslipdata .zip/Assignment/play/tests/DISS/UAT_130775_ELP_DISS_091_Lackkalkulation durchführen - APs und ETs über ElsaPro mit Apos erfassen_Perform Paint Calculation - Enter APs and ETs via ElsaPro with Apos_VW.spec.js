const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');
const { PaketKatalogPage } = require('../../support/pageObjects/elsaPageObjects/paketKatalogPage');

const fs = require('fs');
const path = require('path');

test('UAT_130775_ELP_DISS_091_Lackkalkulation durchführen - APs und ETs über ElsaPro mit Apos erfassen_Perform Paint Calculation - Enter APs and ETs via ElsaPro with Apos_VW', async () => {
    // adjust global timeout for this test case only as it takes more than 100000 ms in config file
    test.test.setTimeout(150000)
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[50].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[50].context)
    await navigation.goToApplication(page, data.testCase[50].elsaApp, data.testCase[50].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[50].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await headers.clickBtnOnHeader(elsaProPage, 'PaketkatalogBtn')
    // select category from "Kategorie wählen" list
    // As per discussion with the manual team, I selected a different one so step 23 is working as expected
    await PaketKatalogPage.selectCategory(elsaProPage, data.testCase[50].category)
    // expand header paket by paket number
    await PaketKatalogPage.expandHeaderPaket(elsaProPage, data.testCase[50].headerPaketNumber)
    // click on info icon for paket number
    await PaketKatalogPage.clickOnInfoIcon(elsaProPage, data.testCase[50].paketNumber)
    //verify Info Popup Title
    await PaketKatalogPage.verifyInfoPopupTitle(elsaProPage, data.testCase[50].infoPopupTitle)
    //get all parts description after click on info tool
    const allIconPartsDescription = await PaketKatalogPage.getAllPartsDescription(elsaProPage)
    await console.log(allIconPartsDescription)
    // click add to cart inside Info Popup
    await PaketKatalogPage.clickAddToCartBtn(elsaProPage)
    // wait for overlay UI icon to disappear
    // click on cart icon inside Info Popup
    await PaketKatalogPage.clickOnCartInsideInfoErledigtPopup(elsaProPage)
    // click on Save button inside cart
    await PaketKatalogPage.clickOnSaveBtnInsideCart(elsaProPage)
    // wait for overlay UI icon to disappear
    await PaketKatalogPage.waitForOverlayToDisappear(elsaProPage)
    // Static wait for 2 seconds for stability
    await elsaProPage.waitForTimeout(2000);
    // close PaketKatalog Page
    await PaketKatalogPage.closePaketKatalogFInfomedia(elsaProPage)
    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // click on parts/Teile column in results/Ergebnisliste table 
    await homepage.clickOnPartsColumnInResultsTable(elsaProPage)
    // Static wait for 5 seconds for stability
    await elsaProPage.waitForTimeout(5000);
    //get all parts/Teile column in results/Ergebnisliste table 
    const allPartsInResultsTableText = await homepage.getPartsColumnInResultsTable(elsaProPage)
    await expect(allPartsInResultsTableText).toEqual(allIconPartsDescription)

    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[50].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[50].customerComplaint)

    // select no in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

    // select no in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[50].labelNamesArray, data.testCase[50].infomediaArray)

    // select the label
    await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[50].labelNamesArray2, data.testCase[50].infomediaArray2)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup);

    await elsaProPage.waitForTimeout(2000);

    // click "OK" in Popup
    await direktInformationssystemService.clickOkInPopup(elsaProPage)

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[50].codierenText)
    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[50].HSTTitle)

    // click exit button in order to close the Handsbuchservicetechnik page
    await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);

    //enter text in auftragsnummer box
    await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

    //enter the mileage in mileage feild
    await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[50].mileage)

    // the method below select (Yes) or (No) radio button in 	"Paint Complaint with Release Costing"
    await direktInformationssystemService.selectRadioBtnInPaintComplaint(elsaProPage, "0")

    await elsaProPage.waitForTimeout(2000);
    await direktInformationssystemService.selectTab(elsaProPage, "Freigabe Lackanfrage mit Kalkulation")

    // Click on Lackkalkulation zu dieser Beanstandung öffnen
    await direktInformationssystemService.clickOnLackkalkulationZuDieserBeanstandung(elsaProPage)

    // Fill in KDNummer
    await direktInformationssystemService.fillKDNummer(elsaProPage, data.testCase[50].KDNummer)
    // Fill in Schadensart
    await direktInformationssystemService.fillSchadensart(elsaProPage, data.testCase[50].schadensart)
    // Fill in Schadensort
    await direktInformationssystemService.fillSchadensort(elsaProPage, data.testCase[50].schadensort)
    // Select "nein" in 'Fremdlackierung enthalten?'
    await direktInformationssystemService.selectJaOrNeinInFremdlackierungEnthalten(elsaProPage, "nein")

    //click ElsaPro Auftragsdaten btn inside Lackkalkulation zur Kundencodierung
    await direktInformationssystemService.clickonElsaProAuftragsdatenInLackkalkulation(elsaProPage)
    // click on sub tab inside ElsaPro Auftragsdaten
    await direktInformationssystemService.clickOnTabInElsaProAuftragsdaten(elsaProPage, "Teile")
    // click Checkbox For ET-Nummer inside ElsaPro Auftragsdaten
    await direktInformationssystemService.clickOnCheckboxForInElsaProAuftragsdaten(elsaProPage, data.testCase[50].ETNummer)
    // click on sub tab inside ElsaPro Auftragsdaten
    await direktInformationssystemService.clickOnTabInElsaProAuftragsdaten(elsaProPage, "Positionen")
    // click Checkbox For Arbeitsposition/work position inside ElsaPro Auftragsdaten
    await direktInformationssystemService.clickOnCheckboxForInElsaProAuftragsdaten(elsaProPage, data.testCase[50].Arbeitsposition)
    // click Ubernehmen inside ElsaPro Auftragsdaten (after clicks on ElsaPro Auftragsdaten and the ElsaPro Auftragsdaten popup opens )
    await direktInformationssystemService.clickOnUbernehmenInElsaProAuftragsdaten(elsaProPage)
    // verify Apos Arbeitsposition/work position inside Lackkalkulation zur Kundencodierung
    await elsaProPage.waitForTimeout(2000);
    await direktInformationssystemService.verifyAposArbeitspositionInLackkalkulation(elsaProPage, [data.testCase[50].Arbeitsposition])
    // verify Teile ET-Nummer inside Lackkalkulation zur Kundencodierung
    await direktInformationssystemService.verifyTeileETNummerInLackkalkulation(elsaProPage, [data.testCase[50].ETNummer])
    // Click in Plausibilitätsprüfung in 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.clickPlausibilitätsprüfungInLackkalkulationZurKundencodierung(elsaProPage)
    await direktInformationssystemService.clickSpeichernInLackkalkulationZurKundencodierung(elsaProPage)
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)


    // This method checks the text inside the status tab
    await direktInformationssystemService.checkLackkalkulationStatus(elsaProPage, 'Kalkuliert')

    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)
});