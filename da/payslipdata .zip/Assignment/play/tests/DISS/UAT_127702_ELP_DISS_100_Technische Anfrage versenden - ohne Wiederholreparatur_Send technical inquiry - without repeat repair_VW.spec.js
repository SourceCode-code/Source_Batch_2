const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');
const { EingangPage } = require('../../support/pageObjects/DISSMPageObjects/eingangPage');
const { AuftraglistePage } = require('../../support/pageObjects/DISSMPageObjects/auftragliste');

const fs = require('fs');
const path = require('path');

test('UAT_127702_ELP_DISS_100_Technische Anfrage versenden - ohne Wiederholreparatur_Send technical inquiry - without repeat repair_VW', async () => {
    // adjust global timeout for this test case only as it takes more than 100000 ms in config file
    test.test.setTimeout(3.5 * 60 * 1000)
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    await page.waitForTimeout(2000)
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[52].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[52].context)
    await navigation.goToApplication(page, data.testCase[52].elsaApp, data.testCase[52].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    await elsaProPage.bringToFront();
    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[52].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[52].link);

    await direktInformationssystemService.enterOrderNumberAndClickSearch(elsaProPage, data.testCase[52].TestConfigurations[0].orderNumber);

    await page.waitForTimeout(3000);
    await direktInformationssystemService.clickOnListOfComplaints(elsaProPage);
    await page.waitForTimeout(3000);
    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await page.waitForLoadState("networkidle");

    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[52].customerComplaint)

    // select no in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

    // select no in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[52].labelNamesArray, data.testCase[52].infomediaArray)

    // select the label
    await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[52].labelNamesArray2, data.testCase[52].infomediaArray2)
    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup);
    // click "OK" in Popup
    await elsaProPage.waitForTimeout(4000);
    await direktInformationssystemService.clickOkInPopup(elsaProPage);

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[52].codierenText)


    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[52].HSTTitle)

    // click exit button in order to close the Handsbuchservicetechnik page
    await HandbuchServiceTechnikPage.clickExitButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);

    // Choose "nein" in "Would you like to make a request?""
    await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, "2");

    //click on next process step button
    await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)

    await elsaProPage.waitForTimeout(3000);

    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Beanstandungs-Erfassung', 'Disabled')
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Werkstattfeststellung', 'Active');

    // Choose "ja, Technische Reparaturanfrage stellen" in "Möchten Sie eine Anfrage stellen? /Would you like to make an inquiry "
    await direktInformationssystemService.selectSendingQueryRadioBtnInPage2(elsaProPage, "T")

    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Technische Reparaturanfrage', 'Anfrage')
    await direktInformationssystemService.verifyTabTextColor(elsaProPage, 'Technische Reparaturanfrage', "rgb(128, 0, 0)")

    // Click the top DISS page tabs
    await direktInformationssystemService.selectTab(elsaProPage, "Technische Reparaturanfrage")
    await elsaProPage.waitForTimeout(3000);
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Technische Reparaturanfrage', 'ActiveAnfrage')

    // select the option von Anfang in Since when has the complaint occurred?//Seit wann tritt die Beanstandung auf? question  
    await direktInformationssystemService.selectWhenComplaintOccurredRadioBtn(elsaProPage, "0")

    //select ja radio check box from Has a comparison vehicle been tested? // Wurde ein Vergleichsfahrzeug geprüft? section 
    await direktInformationssystemService.selectHasVehicleTestedRadioBtn(elsaProPage, "0")

    //select  ja radio check box from Is the vehicle currently available for telediagnosis? // Steht das Fahrzeug derzeit zur Telediagnose zur Verfügung? 
    await direktInformationssystemService.selectIsVehicleAvailableForTelediagnosisRadioBtn(elsaProPage, "0")

    //select ja radio check box from Have you done the "Guided Troubleshooting"? //   Haben Sie die "Geführte Fehlersuche" durchgeführt?
    await direktInformationssystemService.selectGuidedTroubleshootingRadioBtn(elsaProPage, "0")

    //select ja radio check box from Is the emission warning light on? //  Ist die Abgaswarnleuchte an?
    await direktInformationssystemService.selectEmissionWarningLightRadioBtn(elsaProPage, "0")

    //select ja radio check box from Does the complaint relate to an original accessory (VWN: bodies and conversions)? // Bezieht sich die Beanstandung auf ein Originalzubehör (VWN: Auf- und Ausbauten)?
    await direktInformationssystemService.selectComplaintRelateToOriginalAccessoryRadioBtn(elsaProPage, "0")

    //select radio check box from  Does the vehicle correspond to the series version?  // Entspricht das Fahrzeug dem Serienstand? 
    await direktInformationssystemService.selectVehicleCorrespondToSeriesStandardRadioBtn(elsaProPage, "0")

    //eneter text "text" in  Wenn nein, welche Änderungen wurden durchgeführt? /If not, what changes have been made?
    await direktInformationssystemService.enterTextInWennNein(elsaProPage, data.testCase[52].text1);

    //eneter text in Welche Arbeiten hat die Werkstatt durchgeführt und wobei benötigen Sie Unterstützung? // What work did the workshop do and what do you need help with?
    await direktInformationssystemService.enterTextInWerkstattDurchgeführt(elsaProPage, data.testCase[52].text)

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup2] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup2.waitForLoadState('domcontentloaded');

    // select tab from the tab hearder in edit pop up
    await Editpage.selectTab(editPopup2, "Selektion")

    // Making sure edit popup window is loaded successfully   
    await editPopup2.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup2, data.testCase[52].labelNamesArray, data.testCase[52].infomediaArray)

    // select the label
    await Editpage.clickOnTheLabel(editPopup2, ["Beanstandungsart"])

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup2, data.testCase[52].labelNamesArray2, data.testCase[52].infomediaArray3)
    await elsaProPage.waitForTimeout(2000)
    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup2);
    await elsaProPage.waitForTimeout(3000)
    await elsaProPage.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[52].codierenText2)

    // click on "Send" button
    await page.waitForTimeout(3000)
    //click on send btn
    await direktInformationssystemService.clickOnSendBtn(elsaProPage)

    await page.waitForTimeout(3000);

    await direktInformationssystemService.verifyMessageAfterClickSendBtn(elsaProPage, "Die Anfrage wurde versendet und kann nicht mehr geändert werden!", "rgb(128, 0, 0)")
    // select the tab option
    await page.waitForTimeout(5000)
    await direktInformationssystemService.selectTab(elsaProPage, "Zusammenfassung")
    await elsaProPage.waitForTimeout(3000);
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')

    const baID = await direktInformationssystemService.getValueFromBeanstandungsdatenTable(elsaProPage, 'BA-ID:');
    await direktInformationssystemService.verifyValueFromBeanstandungsdatenTable(elsaProPage, "Werkstattcodierung:", data.testCase[52].codierenText2);

    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)
    //static wait for stability
    await page.waitForTimeout(2000)

    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[52].user);


    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[52].context2)
    //static wait for stability
    await page.waitForTimeout(2000)
    // Click on the specific Application
    await navigation.goToApplication(page, data.testCase[52].dissmApp, data.testCase[52].user);
    await page.waitForTimeout(3000);

    // set the new page opened to elsaProPage
    const dissmonitorapp = (context.pages())[0];
    await dissmonitorapp.waitForLoadState('domcontentloaded');
    await dissmonitorapp.bringToFront();

    await EingangPage.filterTable(dissmonitorapp, "test uk 2")
    await EingangPage.sortTableByColumn(dissmonitorapp, "BA-ID", "desc")

    //prepare rowValues object to click on Lesen on correct row
    let rowValues = {
        "BA-ID": baID,
        "FG.-NR.": data.testCase[52].TestConfigurations[0].VIN
    }

    // click on lesen button
    await EingangPage.clickOnLesen(dissmonitorapp, rowValues)

    // verify BA-ID value
    await EingangPage.verifyValueFromAnfrageTable(dissmonitorapp, "BA-ID:", baID);


    // verify Rückinfozeit +2 hrs or +01:5x as some times it decreases to less than +2 hrs with one or two minutes
    await EingangPage.verifyValueFromAnfrageTable(dissmonitorapp, "Rückinfozeit:", "\\+05:5|\\+06:00", true)
    const kommunikationshistoriedate = await EingangPage.getdateKommunikationshistorie(dissmonitorapp)
    const anfrageDate = await EingangPage.getFeedbackTimeValueFromAnfrageTable(dissmonitorapp);

    await EingangPage.checkiftodaysdate(kommunikationshistoriedate[0])
    await EingangPage.checkiftodaysdate(anfrageDate[0])
    await EingangPage.getTimeDifference(anfrageDate[1], kommunikationshistoriedate[1], 6);

    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    await dissmonitorapp.waitForTimeout(2000)
    await navigation.logOutGRP(page);

});