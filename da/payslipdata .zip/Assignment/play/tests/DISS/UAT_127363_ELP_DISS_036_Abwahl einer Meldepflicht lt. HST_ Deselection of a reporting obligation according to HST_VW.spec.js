const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');

const fs = require('fs');
const path = require('path');
const { dir } = require('console');

test('UAT_127363_ELP_DISS_036_Abwahl einer Meldepflicht lt. HST_ Deselection of a reporting obligation according to HST_VW', async () => {
  // adjust global timeout for this test case only as it takes more than 100000 ms in config file
  test.test.setTimeout(150000)
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  // Define the path to the fixture file
  const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
  // Read the JSON file synchronously
  const fixtureData = fs.readFileSync(fixtureFilePath);
  // Parse the JSON data
  const data = JSON.parse(fixtureData);


  // visit website grp prelive, login and click on Elsa Pro application
  await navigation.navigateToBaseUrl(page);
  await page.waitForTimeout(2000)
  // login with credentials
  await navigation.loginWithCredentials(page, data.testCase[53].user);
  // change context from GRP page
  //Note: In the test case contex given "DEU08761V" but as we dont have access for this so as per discussion with manual team we can use ""DEU99975V""
  await navigation.GRP_Context(page, data.testCase[53].context)
  await navigation.goToApplication(page, data.testCase[53].elsaApp, data.testCase[53].user);

  // set the new page opened to elsaProPage
  const allPages = context.pages();
  const elsaProPage = allPages[0];
  await elsaProPage.waitForLoadState('domcontentloaded');
  await elsaProPage.bringToFront()

  // verify ELP homepage
  await homepage.verifyELPHomePage(elsaProPage)
  // change Language to DE
  await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

  // click on FahrzeugidentifikationBtn
  await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

  // write FIn and click send button
  await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[53].TestConfigurations[0].VIN);

  // click ok message box, click OK on Fahrzeugauswahl
  await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
  await fahrzeugAuswahl.clickOKButton(elsaProPage);

  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);
  // click on DISS
  await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[53].link)

  // click on "Neuen Auftrag Anlegen" button
  await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage);

  //enter text in Customer Complaint box
  await direktInformationssystemService.enterCustomerComplaint(elsaProPage, 'Motor ruckelt');

  // select no in is the car brokendown?
  await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein");

  // select no in our workshop because of this complaint?
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein");

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup.waitForLoadState('domcontentloaded');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[53].labelNamesArray, data.testCase[53].infomediaArray)

  // select the label
  await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[53].labelNamesArray2, data.testCase[53].infomediaArray2)
  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup);

  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage, true)

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[53].codierenText)

  // click on HST Button
  await elsaProPage.waitForTimeout(3000)
  await direktInformationssystemService.clickHstButton(elsaProPage);

  await HandbuchServiceTechnikPage.openDocumentByName(elsaProPage, data.testCase[53].documentNumber);
  await elsaProPage.waitForTimeout(3000)
  await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage);
  await elsaProPage.waitForTimeout(3000)
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Meldepflicht lt HST', 'Anfrage');

  //verify tap "Meldepflicht lt. HST" hilighted in red color
  await direktInformationssystemService.verifyTabTextColor(elsaProPage, "Meldepflicht lt HST", "rgb(128, 0, 0)")

  //verify HST field number text 
  await direktInformationssystemService.verifyLowerHSTNumberField(elsaProPage, data.testCase[53].documentNumber)

  // verify hst field title text
  await direktInformationssystemService.verifyLowerHSTTitleField(elsaProPage, data.testCase[53].documentName)

  // Verify that 'MakeReques' radion button is enabled
  await direktInformationssystemService.verifyRadioBtnInMakeRequestIsEnabled(elsaProPage, "ja, Meldepflicht laut HST")

  // Verify that 'MakeReques' radion button is selected with te option "ja, Meldepflicht laut HST"
  await direktInformationssystemService.verifyRadioBtnInMakeRequestIsChecked(elsaProPage, "ja, Meldepflicht laut HST")

  //enter text in auftragsnummer box
  await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

  await direktInformationssystemService.enterMileage(elsaProPage, '90000');

  //click Speichern Button
  await direktInformationssystemService.clickSpeichernButton(elsaProPage)

  await page.waitForTimeout(3000);
  // verify "Auftragsnummer" is read only
  await direktInformationssystemService.verifyAuftragsnummerIsReadOnly(elsaProPage);

  //click nein in "Would you like to make a request?"
  await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, '2')
  //check that this tab is not visible
  await direktInformationssystemService.verifyTabnotvisible(elsaProPage, 'Meldepflicht lt HST');

  //click save
  await direktInformationssystemService.clickonSaveBtn(elsaProPage);
  await page.waitForTimeout(3000);
  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)
  //verify that HST fields are empty
  // verify lower HSt field number (first one from left to the right) to be empty
  await direktInformationssystemService.verifyLowerHSTNumberFieldIsEmpty(elsaProPage)

  // verify lower HSt field title (second one from left to the right) to be empty
  await direktInformationssystemService.verifyLowerHSTTitleFieldIsEmpty(elsaProPage)

  // click on HST Button
  await elsaProPage.waitForTimeout(3000)
  await direktInformationssystemService.clickHstButton(elsaProPage);

  await HandbuchServiceTechnikPage.openDocumentByName(elsaProPage, data.testCase[53].documentNumber);

  await page.waitForTimeout(3000);
  await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage);

  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Meldepflicht lt HST', 'Anfrage');

  //verify tap "Meldepflicht lt. HST" hilighted in red color
  await direktInformationssystemService.verifyTabTextColor(elsaProPage, "Meldepflicht lt HST", "rgb(128, 0, 0)")

  //verify HST field number text 
  await direktInformationssystemService.verifyLowerHSTNumberField(elsaProPage, data.testCase[53].documentNumber)

  // verify hst field title text
  await direktInformationssystemService.verifyLowerHSTTitleField(elsaProPage, data.testCase[53].documentName)
  // Verify that 'MakeReques' radion button is enabled
  await direktInformationssystemService.verifyRadioBtnInMakeRequestIsEnabled(elsaProPage, "ja, Meldepflicht laut HST")

  // Verify that 'MakeReques' radion button is selected with te option "ja, Meldepflicht laut HST"
  await direktInformationssystemService.verifyRadioBtnInMakeRequestIsChecked(elsaProPage, "ja, Meldepflicht laut HST")

  //click save
  await direktInformationssystemService.clickonSaveBtn(elsaProPage);
  await elsaProPage.waitForTimeout(3000);
  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)
  //click ja, es liegt einer der Fälle Brand, Airbag oder Unfall vor (Sicherheitsrelevante Anfrage) in "Would you like to make a request?"
  await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, '1')
  await page.waitForTimeout(2000);
  //click save
  await direktInformationssystemService.clickonSaveBtn(elsaProPage);
  await elsaProPage.waitForTimeout(3000);
  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)
  //check tab is visible
  await direktInformationssystemService.verifyTabvisible(elsaProPage, 'Sicherheitsrelevante Anfrage');
  // this method logs out from elsaPro and GRP
  await navigation.logOut(elsaProPage)

});