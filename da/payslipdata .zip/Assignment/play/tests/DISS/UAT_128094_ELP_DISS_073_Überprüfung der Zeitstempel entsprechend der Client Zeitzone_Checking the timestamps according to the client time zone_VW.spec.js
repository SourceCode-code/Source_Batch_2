const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');
const { common } = require('../../support/common');

const fs = require('fs');
const path = require('path');

test('UAT_128094_ELP_DISS_073_Überprüfung der Zeitstempel entsprechend der Client Zeitzone_Checking the timestamps according to the client time zone_VW', async () => {
  // adjust global timeout for this test case only as it takes more than 100000 ms in config file
  test.test.setTimeout(150000)
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  // Define the path to the fixture file
  const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
  // Read the JSON file synchronously
  const fixtureData = fs.readFileSync(fixtureFilePath);
  // Parse the JSON data
  const data = JSON.parse(fixtureData);

  // visit website grp prelive, login and click on Elsa Pro application
  await navigation.navigateToBaseUrl(page);
  // login with credentials
  await navigation.loginWithCredentials(page, data.testCase[38].user);
  // change context from GRP page
  await navigation.GRP_Context(page, data.testCase[38].context)
  await navigation.goToApplication(page, data.testCase[38].elsaApp, data.testCase[38].user);


  // set the new page opened to elsaProPage
  const allPages = context.pages();
  const elsaProPage = allPages[0];
  await elsaProPage.waitForLoadState('domcontentloaded');

  // verify ELP homepage
  await homepage.verifyELPHomePage(elsaProPage)
  // change Language to DE
  await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

  // click on FahrzeugidentifikationBtn
  await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

  // write FIn and click send button
  await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[38].TestConfigurations[0].VIN);

  // click ok message box, click OK on Fahrzeugauswahl
  await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
  await fahrzeugAuswahl.clickOKButton(elsaProPage);

  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);
  // click on DISS
  await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[38].link)

  // click on "Neuen Auftrag Anlegen" button
  await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

  //enter text in Customer Complaint box
  await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[38].TestConfigurations[0].customerComplaint)

  // select yes in is the car brokendown?
  await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "ja")

  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);

  // select no in our workshop because of this complaint?
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup.waitForLoadState('domcontentloaded');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[38].labelNamesArray, data.testCase[38].infomediaArray)

  // select the label
  await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[38].labelNamesArray2, data.testCase[38].infomediaArray2)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup);

  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage, true)

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[38].codierenText)

  //click on HST Button In DISS Page
  await direktInformationssystemService.clickHstButton(elsaProPage)

  //this method verifies the HST page title
  await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[38].HSTTitle)

  //click on given link 
  //Note here in test case given document name "Bildkatalog zur Diagnose Kurbeltrieb bei Ottomotoren (2013425/3)"
  //but for this need to wait to 20 min to unable next process button so here taken anothe document name 
  await page.waitForTimeout(3000);
  await HandbuchServiceTechnikPage.openDocumentByName(elsaProPage, "2008818/18")

  //this method click on "HST nach DISS übernehmen"/"Copy HST to DISS" (📋) button after open the document
  await page.waitForTimeout(3000);
  await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage)

  // the method below select (No) radio button in "Would you like to make a request?"
  await page.waitForTimeout(3000);
  await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, "2")

  //enter text in auftragsnummer box
  await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

  //enter the mileage in mileage feild
  await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[38].mileage)

  //click on next process step button
  await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)

  //Static wait for 2 seconds (2000 milliseconds)
  await elsaProPage.waitForTimeout(2000);

  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

  // click on ja in Ist die Beanstandung behoben? section
  await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, "ja")

  // select Reparatur nach TPI ohne Teiletausch in Art der Reparatur section
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "ohneteiltpl")

  //click on option 	Ja, TPI übernehmen in popup
  await page.waitForTimeout(3000)
  await direktInformationssystemService.selectOptionInHaveYouWorkedAccordingToTPIPopup(elsaProPage, "TPIReparaturJ")

  //click on apply in TPI POPup
  await page.waitForTimeout(3000);
  await direktInformationssystemService.clickApplySelectionInHaveYouWorkedAccordingToTPIPopup(elsaProPage)

  //Enter Number of work Item / Nummer der schadensbehebenden Arbeitsposition
  await page.waitForTimeout(3000);
  await direktInformationssystemService.enterNumberOfWorkItem(elsaProPage, "123456")

  // click on finish button 
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)

  // click ok in popup
  await direktInformationssystemService.clickonOKoption(elsaProPage)

  await elsaProPage.waitForTimeout(3000);
  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')

  // click on open event list / Ruft eine Liste mit Prozessinformationen zu dieser Beanstandung auf "(ℹ️) icon"
  await direktInformationssystemService.clickOnOpenEventList(elsaProPage)

  // get value from event list table
  const timestampValue = await direktInformationssystemService.getValueInEventList(elsaProPage, "Zeitstempel", "last()")

  expect(await direktInformationssystemService.verifyTimeStampFormat(timestampValue)).toBeTruthy();

  // this method logs out from elsaPro and GRP
  await navigation.logOut(elsaProPage)
});