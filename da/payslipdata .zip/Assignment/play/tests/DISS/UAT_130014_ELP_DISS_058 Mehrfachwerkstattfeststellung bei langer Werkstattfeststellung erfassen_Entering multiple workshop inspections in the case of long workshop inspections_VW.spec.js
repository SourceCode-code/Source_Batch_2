const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');

const fs = require('fs');
const path = require('path');

test('UAT_130014_ELP_DISS_058 Mehrfachwerkstattfeststellung bei langer Werkstattfeststellung erfassen_Entering multiple workshop inspections in the case of long workshop inspections_VW', async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  // Define the path to the fixture file
  const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
  // Read the JSON file synchronously
  const fixtureData = fs.readFileSync(fixtureFilePath);
  // Parse the JSON data
  const data = JSON.parse(fixtureData);


  // visit website grp prelive, login and click on Elsa Pro application
  await navigation.navigateToBaseUrl(page);
  // login with credentials
  await navigation.loginWithCredentials(page, data.testCase[26].user);
  // change context from GRP page
  await navigation.GRP_Context(page, data.testCase[26].context)
  await navigation.goToApplication(page, data.testCase[26].elsaApp, data.testCase[26].user);

  // set the new page opened to elsaProPage
  const allPages = context.pages();
  const elsaProPage = allPages[0];
  await elsaProPage.waitForLoadState('domcontentloaded');

  // verify ELP homepage
  await homepage.verifyELPHomePage(elsaProPage)
  // change Language to DE
  await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

  // click on FahrzeugidentifikationBtn
  await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

  // write FIn and click send button
  await elsaProPage.waitForTimeout(3000);
  await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[26].TestConfigurations[0].VIN);

  // click ok message box, click OK on Fahrzeugauswahl
  await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
  await fahrzeugAuswahl.clickOKButton(elsaProPage);

  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);
  // click on DISS
  await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[26].link)

  // click on "Neuen Auftrag Anlegen" button
  await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

  //enter text in Customer Complaint box
  await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[26].TestConfigurations[0].customerComplaint)

  // select yes in is the car brokendown?
  await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "ja")

  // select no in our workshop because of this complaint?
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup.waitForLoadState('domcontentloaded');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[26].labelNamesArray, data.testCase[26].infomediaArray)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup);

  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage)

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[26].codierenText)

  //click on HST Button In DISS Page
  await direktInformationssystemService.clickHstButton(elsaProPage)

  //this method verifies the HST page title
  await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[26].HSTTitle)

  // this method search document by name after clicking on HST
  await HandbuchServiceTechnikPage.searchDocumentByName(elsaProPage, data.testCase[26].linkSearchText)

  //this method open document after search on document
  await HandbuchServiceTechnikPage.openDocumentFromSearchResult(elsaProPage, data.testCase[26].docName)

  //this method click on "HST nach DISS übernehmen"/"Copy HST to DISS" (📋) button after open the document
  await HandbuchServiceTechnikPage.clickOnHSTNachDISSUbernehmenButton(elsaProPage)

  // the method below select (No) radio button in "Would you like to make a request?"
  await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, "2")

  // the method below select (No) radio button in 	"Were you in our workshop because of this complaint?"
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

  //enter text in auftragsnummer box
  await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

  //enter the mileage in mileage feild
  await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[26].mileage)

  //click on next proceed button
  await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)

  //verify the status of "Werkstattfeststellung" tab to be active
  await direktInformationssystemService.verifyTabStatus(elsaProPage, "Werkstattfeststellung", "Active")

  // this method is to click on "Über diese Schaltfläche können Sie weitere Werkstattfeststellungen...
  //  zur Kundenbeanstandung hinzufügen, die unmittelbar im Zusammenhang mit dieser stehen." button
  await direktInformationssystemService.clickOnWeitereWorkshopErgebnisseButton(elsaProPage)

  // select "ja" in popup
  await direktInformationssystemService.clickOnButtonInKundenbeanstandungErfassenPopup(elsaProPage, "ja")

  // select  yes option for Has the complaint been rectified?/Ist die Beanstandung behoben?
  await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, "ja")

  // select type of repair  Radio btn
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(page, "mitteil")

  // verify lower HSt field number (first one from left to the right) to be empty
  await direktInformationssystemService.verifyLowerHSTNumberFieldIsEmpty(elsaProPage)

  // verify lower HSt field title (second one from left to the right) to be empty
  await direktInformationssystemService.verifyLowerHSTTitleFieldIsEmpty(elsaProPage)

  // this method verifies if the book icon in the HST button is open
  await direktInformationssystemService.verifyHSTBookStatus(elsaProPage, "open")

  // Verify that the "Bearbeiten" button is clickable
  await direktInformationssystemService.verifyBearbeitenButtonClickable(elsaProPage)

  //click on save btn 
  await direktInformationssystemService.clickSpeichernButton(elsaProPage)
  await elsaProPage.waitForTimeout(2000)

  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

  // this method clicks on Zusammenfassung tab
  await direktInformationssystemService.selectTab(page, "Zusammenfassung")

  // this method to verify the text in any row in Beanstandungsdaten  when the Zusammenfassung tab is active
  await elsaProPage.waitForTimeout(1000)
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')
  await direktInformationssystemService.checkTextsInBeanstandungsdatenTable(page, data.testCase[26].rowLabels, data.testCase[26].expectedTexts)

  // this method logs out from elsaPro and GRP
  await navigation.logOut(elsaProPage)
});