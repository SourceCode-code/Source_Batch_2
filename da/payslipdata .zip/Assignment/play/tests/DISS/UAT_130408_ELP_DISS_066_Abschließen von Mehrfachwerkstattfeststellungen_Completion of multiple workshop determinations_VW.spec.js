const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');

const fs = require('fs');
const path = require('path');

test('UAT_130408_ELP_DISS_066_Abschließen von Mehrfachwerkstattfeststellungen_Completion of multiple workshop determinations_VW', async () => {
  // adjust global timeout for this test case only as it takes more than 100000 ms in config file
  test.test.setTimeout(400000)
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  // Define the path to the fixture file
  const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
  // Read the JSON file synchronously
  const fixtureData = fs.readFileSync(fixtureFilePath);
  // Parse the JSON data
  const data = JSON.parse(fixtureData);

  // visit website grp prelive, login and click on Elsa Pro application
  await navigation.navigateToBaseUrl(page);
  // login with credentials
  await navigation.loginWithCredentials(page, data.testCase[55].user);
  // change context from GRP page
  await navigation.GRP_Context(page, data.testCase[55].context)
  await navigation.goToApplication(page, data.testCase[55].elsaApp, data.testCase[55].user);

  // set the new page opened to elsaProPage
  const allPages = context.pages();
  const elsaProPage = allPages[0];
  await elsaProPage.waitForLoadState('domcontentloaded');

  // verify ELP homepage
  await homepage.verifyELPHomePage(elsaProPage)
  // change Language to DE
  await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

  // click on FahrzeugidentifikationBtn
  await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

  // write FIn and click send button
  await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[55].TestConfigurations[0].VIN);

  // click ok message box, click OK on Fahrzeugauswahl
  await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
  await fahrzeugAuswahl.clickOKButton(elsaProPage);

  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);
  // click on DISS
  await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[55].link)

  // click on "Neuen Auftrag Anlegen" button
  await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

  //enter text in Customer Complaint box
  await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[55].customerComplaint)

  // select no in is the car brokendown?
  await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

  // select no in our workshop because of this complaint?
  await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // Making sure edit popup window is loaded successfully   
  await editPopup.waitForLoadState('domcontentloaded');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[55].labelNamesArray, data.testCase[55].infomediaArray)

  // select the label
  await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[55].labelNamesArray2, data.testCase[55].infomediaArray2)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup);

  // click "OK" in Popup
  await direktInformationssystemService.clickOkInPopup(elsaProPage)

  // Static wait for 3 seconds (3000 milliseconds)
  await elsaProPage.waitForTimeout(3000);

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[55].codierenText)

  //click on HST Button In DISS Page
  await direktInformationssystemService.clickHstButton(elsaProPage)

  //this method verifies the HST page title
  await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[55].HSTTitle)

  // click exit button in order to close the Handsbuchservicetechnik page
  await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

  // Choose "nein" in "Would you like to make a request?"
  await direktInformationssystemService.selectRadioBtnInMakeRequest(elsaProPage, "2")

  //enter text in auftragsnummer box
  await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

  //enter the mileage in mileage feild
  await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[55].mileage)

  //click on next process step button
  await direktInformationssystemService.clickonNextprocessStepdBtn(elsaProPage)
  await page.waitForTimeout(1000);
  // this is because the page is auto refresh after click on the button
  await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

  const BAID_1 = await direktInformationssystemService.getValueFromKundenbeanstandungTable(elsaProPage, "BA-ID:")
  await console.log(BAID_1)

  // clicks on "Über diese Schaltfläche können Sie weitere Werkstattfeststellungen
  // this method is to click on "Über diese Schaltfläche können Sie weitere Werkstattfeststellungen...
  //  zur Kundenbeanstandung hinzufügen, die unmittelbar im Zusammenhang mit dieser stehen." button
  await direktInformationssystemService.clickOnWeitereWorkshopErgebnisseButton(elsaProPage)
  await elsaProPage.waitForTimeout(2000);

  //click Ok In Kundenbeanstandung Erfassen Popup
  await direktInformationssystemService.clickOnButtonInKundenbeanstandungErfassenPopup(elsaProPage, "ja")
  await elsaProPage.waitForTimeout(5000);

  // verify count of available BAIDs
  await direktInformationssystemService.verifyCountOfBAIDs(elsaProPage, 2)

  // get new BA-ID
  const BAID_2 = await direktInformationssystemService.getActiveBAID(elsaProPage)
  await console.log(BAID_2)

  // clicks on "Über diese Schaltfläche können Sie weitere Werkstattfeststellungen
  // this method is to click on "Über diese Schaltfläche können Sie weitere Werkstattfeststellungen...
  //  zur Kundenbeanstandung hinzufügen, die unmittelbar im Zusammenhang mit dieser stehen." button
  await direktInformationssystemService.clickOnWeitereWorkshopErgebnisseButton(elsaProPage)
  await elsaProPage.waitForTimeout(2000);

  //click Ok In Kundenbeanstandung Erfassen Popup
  await direktInformationssystemService.clickOnButtonInKundenbeanstandungErfassenPopup(elsaProPage, "ja")
  await elsaProPage.waitForTimeout(5000);

  // verify count of available BAIDs
  await direktInformationssystemService.verifyCountOfBAIDs(elsaProPage, 3)

  // get new BA-ID
  const BAID_3 = await direktInformationssystemService.getActiveBAID(elsaProPage)
  await console.log(BAID_3)


  // clicks on "Über diese Schaltfläche können Sie weitere Werkstattfeststellungen
  // this method is to click on "Über diese Schaltfläche können Sie weitere Werkstattfeststellungen...
  //  zur Kundenbeanstandung hinzufügen, die unmittelbar im Zusammenhang mit dieser stehen." button
  await direktInformationssystemService.clickOnWeitereWorkshopErgebnisseButton(elsaProPage)
  await elsaProPage.waitForTimeout(2000);

  //click Ok In Kundenbeanstandung Erfassen Popup
  await direktInformationssystemService.clickOnButtonInKundenbeanstandungErfassenPopup(elsaProPage, "ja")
  await elsaProPage.waitForTimeout(5000);

  // verify count of available BAIDs
  await direktInformationssystemService.verifyCountOfBAIDs(elsaProPage, 4)

  // get new BA-ID
  const BAID_4 = await direktInformationssystemService.getActiveBAID(elsaProPage)
  await console.log(BAID_4)
  
  /*------------------------------------------------------------------------------------------------*/

  await direktInformationssystemService.switchToBAID(elsaProPage, BAID_1)
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.verifyActiveBAID(elsaProPage, BAID_1)

  //click on "Optionale Angaben erfassen" / "Enter optional information" button
  await direktInformationssystemService.clickEnterOptionalInformationButton(elsaProPage)

  //click on "nein" option for Has the complaint been rectified?
  await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, "nein")

  //select type of repair selected as Reparatur mit Teiletausch
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "keine")
  await elsaProPage.waitForTimeout(3000);

  // Enter the generated text into the 'AdditionalInformation' textarea field
  await direktInformationssystemService.clearAndEnterAdditionalInformation(elsaProPage, "alles ok")

  //click on Abschliessen/finish button
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)

  //click on feedback btn in popup
  await direktInformationssystemService.clickonOKoption(elsaProPage)

  await elsaProPage.waitForTimeout(3000);

  /*------------------------------------------------------------------------------------------------*/

  await direktInformationssystemService.switchToBAID(elsaProPage, BAID_2)
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.verifyActiveBAID(elsaProPage, BAID_2)

  await direktInformationssystemService.verifyHSTAufrufenNumberFieldIsEmpty(page)
  await direktInformationssystemService.verifyHSTAufrufenTitleFieldIsEmpty(page)

  //verify if the radio buttons in Art der Reparatur are enabled or disabled
  await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Reparatur mit Teiletausch', 'enabled')
  await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Reparatur ohne Teiletausch', 'enabled')


  //click on "Optionale Angaben erfassen" / "Enter optional information" button
  await direktInformationssystemService.clickEnterOptionalInformationButton(elsaProPage)

  //click on "nein" option for Has the complaint been rectified?
  await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, "nein")

  //select type of repair selected as Reparatur mit Teiletausch
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "ohneteil")
  await elsaProPage.waitForTimeout(3000);

  // Enter the generated text into the 'AdditionalInformation' textarea field
  await direktInformationssystemService.clearAndEnterAdditionalInformation(elsaProPage, "ok")

  await direktInformationssystemService.enterNumberOfWorkItem(elsaProPage, "1234")

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup2] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // select tab from the tab hearder in edit pop up
  await Editpage.selectTab(editPopup2, "Selektion")

  // Making sure edit popup window is loaded successfully   
  await editPopup2.waitForLoadState('load');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup2, data.testCase[55].labelNamesArray3, data.testCase[55].infomediaArray3)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup2)

  //click on Abschliessen/finish button
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)

  //click on feedback btn in popup
  await direktInformationssystemService.clickonOKoption(elsaProPage)

  await elsaProPage.waitForTimeout(3000);

  /*------------------------------------------------------------------------------------------------*/

  await direktInformationssystemService.switchToBAID(elsaProPage, BAID_3)
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.verifyActiveBAID(elsaProPage, BAID_3)

  await direktInformationssystemService.verifyHSTAufrufenNumberFieldIsEmpty(page)
  await direktInformationssystemService.verifyHSTAufrufenTitleFieldIsEmpty(page)

  //verify if the radio buttons in Art der Reparatur are enabled or disabled
  await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Reparatur mit Teiletausch', 'enabled')
  await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Reparatur ohne Teiletausch', 'enabled')


  //click on "Optionale Angaben erfassen" / "Enter optional information" button
  await direktInformationssystemService.clickEnterOptionalInformationButton(elsaProPage)

  //click on "nein" option for Has the complaint been rectified?
  await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, "nein")

  //select type of repair selected as Reparatur mit Teiletausch
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "ohneteil")
  await elsaProPage.waitForTimeout(3000);

  // Enter the generated text into the 'AdditionalInformation' textarea field
  await direktInformationssystemService.clearAndEnterAdditionalInformation(elsaProPage, "ok")

  await direktInformationssystemService.enterNumberOfWorkItem(elsaProPage, "1234")

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup3] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // select tab from the tab hearder in edit pop up
  await Editpage.selectTab(editPopup3, "Selektion")

  // Making sure edit popup window is loaded successfully   
  await editPopup3.waitForLoadState('load');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup3, data.testCase[55].labelNamesArray3, data.testCase[55].infomediaArray3)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup3)

  //click on Abschliessen/finish button
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)

  //click on feedback btn in popup
  await direktInformationssystemService.clickonOKoption(elsaProPage)

  await elsaProPage.waitForTimeout(3000);

  /*------------------------------------------------------------------------------------------------*/

  await direktInformationssystemService.switchToBAID(elsaProPage, BAID_4)
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.verifyActiveBAID(elsaProPage, BAID_4)

  await direktInformationssystemService.verifyHSTAufrufenNumberFieldIsEmpty(page)
  await direktInformationssystemService.verifyHSTAufrufenTitleFieldIsEmpty(page)

  //verify if the radio buttons in Art der Reparatur are enabled or disabled
  await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Reparatur mit Teiletausch', 'enabled')
  await direktInformationssystemService.verifyRadioButtonArtDerReparaturStatus(page, 'Reparatur ohne Teiletausch', 'enabled')


  //click on "Optionale Angaben erfassen" / "Enter optional information" button
  await direktInformationssystemService.clickEnterOptionalInformationButton(elsaProPage)

  //click on "nein" option for Has the complaint been rectified?
  await direktInformationssystemService.selectComplaintreslovedRadioBtn(elsaProPage, "nein")

  //select type of repair selected as Reparatur mit Teiletausch
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.selectTypeOfRepairRadioBtn(elsaProPage, "ohneteil")
  await elsaProPage.waitForTimeout(3000);

  // Enter the generated text into the 'AdditionalInformation' textarea field
  await direktInformationssystemService.clearAndEnterAdditionalInformation(elsaProPage, "ok")

  await direktInformationssystemService.enterNumberOfWorkItem(elsaProPage, "1234")

  // setting the new child window opened after clicking on "Bearbeiten" button
  const [editPopup4] = await Promise.all([
    context.waitForEvent('page'),
    // click on "Bearbeiten" button
    await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
  ]);

  // select tab from the tab hearder in edit pop up
  await Editpage.selectTab(editPopup4, "Selektion")

  // Making sure edit popup window is loaded successfully   
  await editPopup4.waitForLoadState('load');

  // the method verifys the label name and selects the infomedia value for it
  await Editpage.verifyTheLabelAndSelectInfomedia(editPopup4, data.testCase[55].labelNamesArray3, data.testCase[55].infomediaArray3)

  // Click on Übernehmen button
  await Editpage.clickÜbernehmenButton(editPopup4)

  //click on Abschliessen/finish button
  await direktInformationssystemService.clickonAbschliessenBtn(elsaProPage)

  //click on feedback btn in popup
  await direktInformationssystemService.clickonOKoption(elsaProPage)

  await elsaProPage.waitForTimeout(8000);
  await direktInformationssystemService.switchToBAID(elsaProPage, BAID_1)
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.verifyActiveBAID(elsaProPage, BAID_1)
  await direktInformationssystemService.verifyStatusOfBAIDTab(elsaProPage, BAID_1, "ClosedActiveTab")
  //verify the status of top DISS page tabs
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Beanstandungs-Erfassung', 'Disabled')
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Werkstattfeststellung', 'Disabled')
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')

  
  await direktInformationssystemService.switchToBAID(elsaProPage, BAID_2)
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.verifyActiveBAID(elsaProPage, BAID_2)
  await direktInformationssystemService.verifyStatusOfBAIDTab(elsaProPage, BAID_2, "ClosedActiveTab")
  //verify the status of top DISS page tabs
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Beanstandungs-Erfassung', 'Disabled')
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Werkstattfeststellung', 'Disabled')
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')


  await direktInformationssystemService.switchToBAID(elsaProPage, BAID_3)
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.verifyActiveBAID(elsaProPage, BAID_3)
  await direktInformationssystemService.verifyStatusOfBAIDTab(elsaProPage, BAID_3, "ClosedActiveTab")
  //verify the status of top DISS page tabs
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Beanstandungs-Erfassung', 'Disabled')
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Werkstattfeststellung', 'Disabled')
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')


  await direktInformationssystemService.switchToBAID(elsaProPage, BAID_4)
  await elsaProPage.waitForTimeout(3000);
  await direktInformationssystemService.verifyActiveBAID(elsaProPage, BAID_4)
  await direktInformationssystemService.verifyStatusOfBAIDTab(elsaProPage, BAID_4, "ClosedActiveTab")
  //verify the status of top DISS page tabs
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Beanstandungs-Erfassung', 'Disabled')
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Werkstattfeststellung', 'Disabled')
  await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Zusammenfassung', 'Active')

  
  // this method logs out from elsaPro and GRP
  await navigation.logOut(elsaProPage)
});