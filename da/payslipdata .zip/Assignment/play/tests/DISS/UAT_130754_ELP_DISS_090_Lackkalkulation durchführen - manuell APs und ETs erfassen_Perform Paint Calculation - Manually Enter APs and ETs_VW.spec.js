const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');

const fs = require('fs');
const path = require('path');

test('UAT_130754_ELP_DISS_090_Lackkalkulation durchführen - manuell APs und ETs erfassen_Perform Paint Calculation - Manually Enter APs and ETs_VW', async () => {
    // adjust global timeout for this test case only as it takes more than 100000 ms in config file
    test.test.setTimeout(150000)
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[36].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[36].context)
    await navigation.goToApplication(page, data.testCase[36].elsaApp, data.testCase[36].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[36].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[36].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[36].customerComplaint)

    // select no in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

    // select no in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[36].labelNamesArray, data.testCase[36].infomediaArray)

    // select the label
    await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[36].labelNamesArray2, data.testCase[36].infomediaArray2)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup);

    await elsaProPage.waitForTimeout(2000);

    // click "OK" in Popup
    await direktInformationssystemService.clickOkInPopup(elsaProPage)

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[36].codierenText)
    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[36].HSTTitle)

    // click exit button in order to close the Handsbuchservicetechnik page
    await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);

    //enter text in auftragsnummer box
    await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

    //enter the mileage in mileage feild
    await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[36].mileage)

    // the method below select (Yes) or (No) radio button in 	"Paint Complaint with Release Costing"
    await direktInformationssystemService.selectRadioBtnInPaintComplaint(elsaProPage, "0")

    await elsaProPage.waitForTimeout(2000);
    await direktInformationssystemService.selectTab(elsaProPage, "Freigabe Lackanfrage mit Kalkulation")

    const [LackbeanstandungPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Neue Schichtstärke auswählen und hinzufügen" symbol
        await direktInformationssystemService.clickFreigabeLackanfrageMitKalkulationSelector(elsaProPage)
    ]);

    // Fill in Schichtstärke
    await direktInformationssystemService.fillSchichtstärke(LackbeanstandungPopup, "5")

    // Fill in Beschädigtes Bauteil
    await direktInformationssystemService.fillBeschädigtesBauteil(LackbeanstandungPopup, "4")

    // Click Übernehmen or Abbrechen in "Neue Schichtstärke auswählen und hinzufügen" popup
    await direktInformationssystemService.clickÜbernehmenOrAbbrechenInBeschädigtesBauteilPopUp(LackbeanstandungPopup, "Übernehmen")

    // Click on Lackkalkulation zu dieser Beanstandung öffnen
    await direktInformationssystemService.clickOnLackkalkulationZuDieserBeanstandung(elsaProPage)


    // Fill in KDNummer
    await direktInformationssystemService.fillKDNummer(elsaProPage, data.testCase[36].KDNummer)
    // Fill in Schadensart
    await direktInformationssystemService.fillSchadensart(elsaProPage, data.testCase[36].schadensart)
    // Fill in Schadensort
    await direktInformationssystemService.fillSchadensort(elsaProPage, data.testCase[36].schadensort)
    // Select "nein" in 'Fremdlackierung enthalten?'
    await direktInformationssystemService.selectJaOrNeinInFremdlackierungEnthalten(elsaProPage, "nein")
    // Fill in Arbeitsposition
    await direktInformationssystemService.fillArbeitsposition(elsaProPage, data.testCase[36].Arbeitsposition1)
    // Fill in ET-Nummer
    await direktInformationssystemService.fillETNummer(elsaProPage, data.testCase[36].ETNummer1)
    // Fill in Anzahl
    await direktInformationssystemService.fillAnzahl(elsaProPage, data.testCase[36].Anzahl1)
    // Click in Speichern in 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.clickSpeichernInLackkalkulationZurKundencodierung(elsaProPage)
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)

    // This method checks the text inside the status tab
    await direktInformationssystemService.checkLackkalkulationStatus(elsaProPage, 'Erfasst')

    // Click on Lackkalkulation zu dieser Beanstandung öffnen
    await direktInformationssystemService.clickOnLackkalkulationZuDieserBeanstandung(elsaProPage)

    // Fill in Arbeitsposition
    await direktInformationssystemService.fillArbeitsposition(elsaProPage, data.testCase[36].Arbeitsposition2)
    // Fill in ZE
    await direktInformationssystemService.fillZE(elsaProPage, data.testCase[36].ZE)
    // Fill in ET-Nummer
    await direktInformationssystemService.fillETNummer(elsaProPage, data.testCase[36].ETNummer2)
    // Fill in Anzahl
    await direktInformationssystemService.fillAnzahl(elsaProPage, data.testCase[36].Anzahl2)
    // Click in Plausibilitätsprüfung in 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.clickPlausibilitätsprüfungInLackkalkulationZurKundencodierung(elsaProPage)
    // The method checks on the error messages inside the error text box 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.checkErrorTextAndColorInLackkalkulationZurKundencodierung(elsaProPage, data.testCase[36].arrayOfErrorMessages1)

    // this function checks all the checkboxes for all the ET Nummer entries in 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.checkCheckboxeForETNummer(elsaProPage, 2)
    await elsaProPage.waitForTimeout(2000);
    await elsaProPage.waitForLoadState("load")

    // Click in Löchen in 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.clickLöschenInLackkalkulationZurKundencodierung(elsaProPage)
    await elsaProPage.waitForLoadState("load")
    // Click in Plausibilitätsprüfung in 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.clickPlausibilitätsprüfungInLackkalkulationZurKundencodierung(elsaProPage)
    // Click in Speichern in 'Lackkalkulation zur Kundencodierung' Popup
    // The method checks on the error messages inside the error text box 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.checkErrorTextAndColorInLackkalkulationZurKundencodierung(elsaProPage, data.testCase[36].arrayOfErrorMessages2)
    await direktInformationssystemService.clickSpeichernInLackkalkulationZurKundencodierung(elsaProPage)
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)


    // This method checks the text inside the status tab
    await direktInformationssystemService.checkLackkalkulationStatus(elsaProPage, 'Kalkuliert')

    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)
});