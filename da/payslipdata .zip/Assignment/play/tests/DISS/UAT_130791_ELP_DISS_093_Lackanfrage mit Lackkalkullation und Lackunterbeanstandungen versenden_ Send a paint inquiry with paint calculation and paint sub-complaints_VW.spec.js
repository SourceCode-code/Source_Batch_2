const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');
const { PaketKatalogPage } = require('../../support/pageObjects/elsaPageObjects/paketKatalogPage');
const { EingangPage } = require('../../support/pageObjects/DISSMPageObjects/eingangPage');

const fs = require('fs');
const path = require('path');

test('UAT_130791_ELP_DISS_093_Lackanfrage mit Lackkalkullation und Lackunterbeanstandungen versenden_ Send a paint inquiry with paint calculation and paint sub-complaints_VW', async () => {
    // adjust global timeout for this test case only as it takes more than 100000 ms in config file
    test.test.setTimeout(300000)
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[56].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[56].context)
    await navigation.goToApplication(page, data.testCase[56].elsaApp, data.testCase[56].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');

    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on FahrzeugidentifikationBtn
    await headers.clickBtnOnHeader(elsaProPage, 'FahrzeugidentifikationBtn')

    // write FIn and click send button
    await fahrzeugAuswahl.writeFinAndClickSendButton(elsaProPage, data.testCase[56].TestConfigurations[0].VIN);

    // click ok message box, click OK on Fahrzeugauswahl
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await fahrzeugAuswahl.clickOKButton(elsaProPage);

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);
    await fahrzeugAuswahl.clickMessageBoxOkButton(elsaProPage);
    await headers.clickBtnOnHeader(elsaProPage, 'PaketkatalogBtn')
    // select category from "Kategorie wählen" list
    await PaketKatalogPage.selectCategory(elsaProPage, data.testCase[56].category)
    // expand header paket by paket number
    await PaketKatalogPage.expandHeaderPaket(elsaProPage, data.testCase[56].headerPaketNumber)
    // click on Paket übernehmen/Apply Package after expand paket
    await PaketKatalogPage.clickOnApplyPackage(elsaProPage, data.testCase[56].paketNumber)
    // click on Warenkorb/shopping cart in Info - erledigt/Info - done after click on Paket übernehmen/Apply Package
    await PaketKatalogPage.clickOnShoppingCartInsideInfoDone(elsaProPage, data.testCase[56].paketNumber)
    // click on Save button inside cart
    await PaketKatalogPage.clickOnSaveBtnInsideCart(elsaProPage)
    // wait for overlay UI icon to disappear
    await PaketKatalogPage.waitForOverlayToDisappear(elsaProPage)
    // Static wait for 2 seconds for stability
    await elsaProPage.waitForTimeout(2000);
    // close PaketKatalog Page
    await PaketKatalogPage.closePaketKatalogFInfomedia(elsaProPage)
    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // click on DISS
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[56].link)

    // click on "Neuen Auftrag Anlegen" button
    await direktInformationssystemService.clickNeuenAuftragAnlegen(elsaProPage)

    //enter text in Customer Complaint box
    await direktInformationssystemService.enterCustomerComplaint(elsaProPage, data.testCase[56].customerComplaint)

    // select no in is the car brokendown?
    await direktInformationssystemService.selectRadioBtninCarBrokenDown(elsaProPage, "nein")

    // select no in our workshop because of this complaint?
    await direktInformationssystemService.selectRadioBtnInAlreadyVisitInWorkshop(elsaProPage, "nein")

    // setting the new child window opened after clicking on "Bearbeiten" button
    const [editPopup] = await Promise.all([
        context.waitForEvent('page'),
        // click on "Bearbeiten" button
        await direktInformationssystemService.clickBearbeitenButton(elsaProPage)
    ]);

    // Making sure edit popup window is loaded successfully   
    await editPopup.waitForLoadState('domcontentloaded');

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[56].labelNamesArray, data.testCase[56].infomediaArray)

    // select the label
    await Editpage.clickOnTheLabel(editPopup, ["Beanstandungsart"])

    // the method verifys the label name and selects the infomedia value for it
    await Editpage.verifyTheLabelAndSelectInfomedia(editPopup, data.testCase[56].labelNamesArray2, data.testCase[56].infomediaArray2)

    // Click on Übernehmen button
    await Editpage.clickÜbernehmenButton(editPopup);

    await elsaProPage.waitForTimeout(2000);

    // click "OK" in Popup
    await direktInformationssystemService.clickOkInPopup(elsaProPage)

    // verify "Bitte die Situation aus Kundensicht codieren:" text area
    await direktInformationssystemService.verifyKundensichtCodierenTextArea(elsaProPage, data.testCase[56].codierenText)
    //click on HST Button In DISS Page
    await direktInformationssystemService.clickHstButton(elsaProPage)

    //this method verifies the HST page title
    await HandbuchServiceTechnikPage.verifyPageTitle(elsaProPage, data.testCase[56].HSTTitle)

    // click exit button in order to close the Handsbuchservicetechnik page
    await HandbuchServiceTechnikPage.clickExitButton(elsaProPage)

    // Static wait for 3 seconds (3000 milliseconds)
    await elsaProPage.waitForTimeout(3000);

    //enter text in auftragsnummer box
    await direktInformationssystemService.enterAuftragsnummer(elsaProPage)

    //enter the mileage in mileage feild
    await direktInformationssystemService.enterMileage(elsaProPage, data.testCase[56].mileage)

    // the method below select (Yes) or (No) radio button in 	"Paint Complaint with Release Costing"
    await direktInformationssystemService.selectRadioBtnInPaintComplaint(elsaProPage, "0")

    await elsaProPage.waitForTimeout(2000);

    // clicks on "Record additional paint complaints" / "Zusätzliche Lackbeanstandung erfassen" button
    await direktInformationssystemService.clickOnRecordAdditionalPaintComplaintsButton(elsaProPage)
    await elsaProPage.waitForTimeout(15000);

    // clicks on "Record additional paint complaints" / "Zusätzliche Lackbeanstandung erfassen" button
    await direktInformationssystemService.clickOnRecordAdditionalPaintComplaintsButton(elsaProPage)
    await elsaProPage.waitForTimeout(15000);

    // verify count of available BAIDs
    await direktInformationssystemService.verifyCountOfBAIDs(elsaProPage, 3)

    const allBAIDs = await direktInformationssystemService.getAllBAIDs(elsaProPage)

    console.log(allBAIDs)

    await direktInformationssystemService.selectTab(elsaProPage, "Freigabe Lackanfrage mit Kalkulation")
    // verify that "Freigabe Lackanfrage mit Kalkulation" tab is active
    await direktInformationssystemService.verifyTabStatus(elsaProPage, 'Freigabe Lackanfrage mit Kalkulation', 'ActiveAnfrage')

    /***********************************************************************************************************************/

    // Click on Lackkalkulation zu dieser Beanstandung öffnen
    await direktInformationssystemService.clickOnLackkalkulationZuDieserBeanstandung(elsaProPage, allBAIDs[0])
    // Fill in KDNummer
    await direktInformationssystemService.fillKDNummer(elsaProPage, data.testCase[56].KDNummer)
    // Fill in Schadensart
    await direktInformationssystemService.fillSchadensart(elsaProPage, data.testCase[56].schadensart)
    // Fill in Schadensort
    await direktInformationssystemService.fillSchadensort(elsaProPage, data.testCase[56].schadensort)
    // Select "nein" in 'Fremdlackierung enthalten?'
    await direktInformationssystemService.selectJaOrNeinInFremdlackierungEnthalten(elsaProPage, "nein")

    //click ElsaPro Auftragsdaten btn inside Lackkalkulation zur Kundencodierung
    await direktInformationssystemService.clickonElsaProAuftragsdatenInLackkalkulation(elsaProPage)
    // click on sub tab inside ElsaPro Auftragsdaten
    await direktInformationssystemService.clickOnTabInElsaProAuftragsdaten(elsaProPage, "Positionen")
    // click Checkbox For Arbeitsposition/work position inside ElsaPro Auftragsdaten
    await direktInformationssystemService.clickOnCheckboxForInElsaProAuftragsdaten(elsaProPage, data.testCase[56].Arbeitsposition)
    // click Ubernehmen inside ElsaPro Auftragsdaten (after clicks on ElsaPro Auftragsdaten and the ElsaPro Auftragsdaten popup opens )
    await direktInformationssystemService.clickOnUbernehmenInElsaProAuftragsdaten(elsaProPage)
    // verify Apos Arbeitsposition/work position inside Lackkalkulation zur Kundencodierung
    await elsaProPage.waitForTimeout(2000);
    await direktInformationssystemService.verifyAposArbeitspositionInLackkalkulation(elsaProPage, [data.testCase[56].Arbeitsposition])
    // Click in Plausibilitätsprüfung in 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.clickPlausibilitätsprüfungInLackkalkulationZurKundencodierung(elsaProPage)
    await direktInformationssystemService.clickSpeichernInLackkalkulationZurKundencodierung(elsaProPage)
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)
    // This method checks the text inside the status tab
    await direktInformationssystemService.checkLackkalkulationStatus(elsaProPage, 'Kalkuliert', allBAIDs[0])

    /***********************************************************************************************************************/

    // Click on Lackkalkulation zu dieser Beanstandung öffnen
    await direktInformationssystemService.clickOnLackkalkulationZuDieserBeanstandung(elsaProPage, allBAIDs[1])
    // Fill in KDNummer
    await direktInformationssystemService.fillKDNummer(elsaProPage, data.testCase[56].KDNummer)
    // Fill in Schadensart
    await direktInformationssystemService.fillSchadensart(elsaProPage, data.testCase[56].schadensart)
    // Fill in Schadensort
    await direktInformationssystemService.fillSchadensort(elsaProPage, data.testCase[56].schadensort)
    // Select "nein" in 'Fremdlackierung enthalten?'
    await direktInformationssystemService.selectJaOrNeinInFremdlackierungEnthalten(elsaProPage, "nein")

    //click ElsaPro Auftragsdaten btn inside Lackkalkulation zur Kundencodierung
    await direktInformationssystemService.clickonElsaProAuftragsdatenInLackkalkulation(elsaProPage)
    // click on sub tab inside ElsaPro Auftragsdaten
    await direktInformationssystemService.clickOnTabInElsaProAuftragsdaten(elsaProPage, "Positionen")
    // click Checkbox For Arbeitsposition/work position inside ElsaPro Auftragsdaten
    await direktInformationssystemService.clickOnCheckboxForInElsaProAuftragsdaten(elsaProPage, data.testCase[56].Arbeitsposition)
    // click Ubernehmen inside ElsaPro Auftragsdaten (after clicks on ElsaPro Auftragsdaten and the ElsaPro Auftragsdaten popup opens )
    await direktInformationssystemService.clickOnUbernehmenInElsaProAuftragsdaten(elsaProPage)
    // verify Apos Arbeitsposition/work position inside Lackkalkulation zur Kundencodierung
    await elsaProPage.waitForTimeout(2000);
    await direktInformationssystemService.verifyAposArbeitspositionInLackkalkulation(elsaProPage, [data.testCase[56].Arbeitsposition])
    // Click in Plausibilitätsprüfung in 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.clickPlausibilitätsprüfungInLackkalkulationZurKundencodierung(elsaProPage)
    await direktInformationssystemService.clickSpeichernInLackkalkulationZurKundencodierung(elsaProPage)
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)
    // This method checks the text inside the status tab
    await direktInformationssystemService.checkLackkalkulationStatus(elsaProPage, 'Kalkuliert', allBAIDs[1])

    /***********************************************************************************************************************/

    // Click on Lackkalkulation zu dieser Beanstandung öffnen
    await direktInformationssystemService.clickOnLackkalkulationZuDieserBeanstandung(elsaProPage, allBAIDs[2])
    // Fill in KDNummer
    await direktInformationssystemService.fillKDNummer(elsaProPage, data.testCase[56].KDNummer)
    // Fill in Schadensart
    await direktInformationssystemService.fillSchadensart(elsaProPage, data.testCase[56].schadensart)
    // Fill in Schadensort
    await direktInformationssystemService.fillSchadensort(elsaProPage, data.testCase[56].schadensort)
    // Select "nein" in 'Fremdlackierung enthalten?'
    await direktInformationssystemService.selectJaOrNeinInFremdlackierungEnthalten(elsaProPage, "nein")

    //click ElsaPro Auftragsdaten btn inside Lackkalkulation zur Kundencodierung
    await direktInformationssystemService.clickonElsaProAuftragsdatenInLackkalkulation(elsaProPage)
    // click on sub tab inside ElsaPro Auftragsdaten
    await direktInformationssystemService.clickOnTabInElsaProAuftragsdaten(elsaProPage, "Positionen")
    // click Checkbox For Arbeitsposition/work position inside ElsaPro Auftragsdaten
    await direktInformationssystemService.clickOnCheckboxForInElsaProAuftragsdaten(elsaProPage, data.testCase[56].Arbeitsposition)
    // click Ubernehmen inside ElsaPro Auftragsdaten (after clicks on ElsaPro Auftragsdaten and the ElsaPro Auftragsdaten popup opens )
    await direktInformationssystemService.clickOnUbernehmenInElsaProAuftragsdaten(elsaProPage)
    // verify Apos Arbeitsposition/work position inside Lackkalkulation zur Kundencodierung
    await elsaProPage.waitForTimeout(2000);
    await direktInformationssystemService.verifyAposArbeitspositionInLackkalkulation(elsaProPage, [data.testCase[56].Arbeitsposition])
    // Click in Plausibilitätsprüfung in 'Lackkalkulation zur Kundencodierung' Popup
    await direktInformationssystemService.clickPlausibilitätsprüfungInLackkalkulationZurKundencodierung(elsaProPage)
    await direktInformationssystemService.clickSpeichernInLackkalkulationZurKundencodierung(elsaProPage)
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await direktInformationssystemService.verifySaveButtonIsEnabled(elsaProPage)
    // This method checks the text inside the status tab
    await direktInformationssystemService.checkLackkalkulationStatus(elsaProPage, 'Kalkuliert', allBAIDs[2])

    /***********************************************************************************************************************/

    await elsaProPage.waitForTimeout(3000)
    await elsaProPage.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    // select "nein" in "Ist das Fahrzeug unfallbeschädigt, bzw. sind Vorschäden vorhanden?
    await direktInformationssystemService.selectRadioBtnInAccidentPreviousDamage(elsaProPage, "1")
    await elsaProPage.waitForTimeout(3000)

    //click on send btn
    await direktInformationssystemService.clickOnSendBtn(elsaProPage)

    await page.waitForTimeout(3000);

    await direktInformationssystemService.verifyMessageAfterClickSendBtn(elsaProPage, "Die Anfrage wurde versendet und kann nicht mehr geändert werden!", "rgb(128, 0, 0)")


    await navigation.logOut(elsaProPage)

    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[56].user);

    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[56].context2)
    //static wait for stability
    await page.waitForTimeout(2000)
    // Click on the specific Application
    await navigation.goToApplication(page, data.testCase[56].dissmApp, data.testCase[56].user);
    await page.waitForTimeout(4000);

    // set the new page opened to elsaProPage
    const elsaProPage2 = (context.pages())[0];
    await elsaProPage2.waitForLoadState('domcontentloaded');

    await EingangPage.filterTable(elsaProPage2, "test uk 2")
    await EingangPage.sortTableByColumn(elsaProPage2, "BA-ID", "desc")

    //prepare rowValues object to click on Lesen on correct row
    let rowValues = {
        "BA-ID": allBAIDs[0],
        "FG.-NR.": data.testCase[56].TestConfigurations[0].VIN
    }

    // click on lesen button
    await EingangPage.clickOnLesen(elsaProPage2, rowValues)
    await elsaProPage.waitForTimeout(3000)

    // verify Rückinfozeit +2 hrs or +01:5x as some times it decreases to less than +2 hrs with one or two minutes
    await EingangPage.verifyValueFromAnfrageTable(elsaProPage2, "Rückinfozeit:", "\\+29:5|\\+30:00", true)
    await EingangPage.verifyCustomerCoding(elsaProPage2, data.testCase[56].codierenText, allBAIDs[0])

    await navigation.navigateToBaseUrl(elsaProPage2);

    await elsaProPage2.waitForTimeout(2000)
    // this method logs out from elsaPro and GRP
    await navigation.logOutGRP(elsaProPage2)
});