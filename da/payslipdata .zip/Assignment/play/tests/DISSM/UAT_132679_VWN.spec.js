const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const { Editpage } = require('../../support/pageObjects/DISSPageObjects/editPage');
const { HandbuchServiceTechnikPage } = require('../../support/pageObjects/elsaPageObjects/handbuchServiceTechnikPage');
const { EingangPage } = require('../../support/pageObjects/DISSMPageObjects/eingangPage');
const { AuftraglistePage } = require('../../support/pageObjects/DISSMPageObjects/auftragliste');

const fs = require('fs');
const path = require('path');

test('UAT_132679_ELP_DISS-Monitor_145_Filterkriterien für die Auftragsliste - Partner - Offene Archivkandidaten_Filterkriterien for the Order List  Partners - Open Archive Candidates_VWN', async () => {
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[62].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[62].TestConfigurations[1].context)
    await navigation.goToApplication(page, data.testCase[62].dissmApp, data.testCase[62].user);

    // set the new page opened to elsaProPage
    const allPages = context.pages();
    const dissMPage = allPages[0];
    await dissMPage.waitForLoadState('domcontentloaded');

    // verify DISSM homepage
    await homepage.verifyDISSMHomePage(dissMPage)
    await EingangPage.clickSpecificTabAfterOpeningDissMonitor(dissMPage, data.testCase[62].dissmTab)
    await AuftraglistePage.clickOnSubTab(dissMPage, data.testCase[62].dissmSubTab)
    await dissMPage.waitForTimeout(3000);
    await AuftraglistePage.verifyVisiblePageNumbers(dissMPage, ['1', '2'])
    await AuftraglistePage.selectPage(dissMPage, "2")

    await AuftraglistePage.enterTextInSearchFields(dissMPage, 'Auftragsnummer', data.testCase[62].TestConfigurations[1].orderNumber)
    await AuftraglistePage.enterTextInSearchFields(dissMPage, 'Auftragsdatum', data.testCase[62].TestConfigurations[1].Auftragsdatum)
    await AuftraglistePage.enterTextInSearchFields(dissMPage, 'Archivierung', data.testCase[62].TestConfigurations[1].Archivierung)
    await AuftraglistePage.enterTextInSearchFields(dissMPage, 'Fahrgestellnummer', data.testCase[62].TestConfigurations[1].VIN)

    await AuftraglistePage.clickOnSearchButton(dissMPage)
    await AuftraglistePage.verifyCountOfRows(dissMPage, "1")
    await AuftraglistePage.verifyTableColumnIsSortable(dissMPage, ["Auftragsnummer", "Auftragsdatum", "Archivierung", "Fahrgestellnummer"])



    // this method logs out from DISSM and GRP
    await navigation.logOutDISSM(dissMPage)
    // Close the browser
    await browser.close();
});