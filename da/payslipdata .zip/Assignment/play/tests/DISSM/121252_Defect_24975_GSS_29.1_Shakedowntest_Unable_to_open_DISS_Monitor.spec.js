const { test, expect, chromium } = require('@playwright/test');
const { navigation } = require('../../support/pageObjects/navigationPage');
const { homepage } = require('../../support/pageObjects/elsaPageObjects/homePage');
const { headers } = require('../../support/pageObjects/elsaPageObjects/headers');
const { fahrzeugAuswahl } = require('../../support/pageObjects/elsaPageObjects/fahrzeugAuswahl');
const { direktInformationssystemService } = require('../../support/pageObjects/DISSPageObjects/direktInformationssystemServicePage');
const fs = require('fs');
const path = require('path');
const { EingangPage } = require('../../support/pageObjects/DISSMPageObjects/eingangPage');


test('121252-Defect_24975_GSS_29.1_Shakedowntest_Unable to open DISS Monitor system link for Importer User', async () => {
    const browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    // Define the path to the fixture file
    const fixtureFilePath = path.resolve(__dirname, '../../fixtures/testsData.json');
    // Read the JSON file synchronously
    const fixtureData = fs.readFileSync(fixtureFilePath);
    // Parse the JSON data
    const data = JSON.parse(fixtureData);


    // visit website grp prelive, login and click on Elsa Pro application
    await navigation.navigateToBaseUrl(page);
    // login with credentials
    await navigation.loginWithCredentials(page, data.testCase[49].user);
    // change context from GRP page
    await navigation.GRP_Context(page, data.testCase[49].context)
    await navigation.goToApplication(page, data.testCase[49].elsaApp, data.testCase[49].user);

    // set the new page opened to diss app
    const allPages = context.pages();
    const elsaProPage = allPages[0];
    await elsaProPage.waitForLoadState('domcontentloaded');
    await elsaProPage.bringToFront();


    // verify ELP homepage
    await homepage.verifyELPHomePage(elsaProPage)
    // change Language to DE
    await homepage.changeELPInterfaceLanguage(elsaProPage, "de-DE (German)")

    // click on DISS Monitor
    await homepage.clickOnLinkInSystemsLinks(elsaProPage, data.testCase[49].link)
    await context.waitForEvent('page');
    const allPages2 = context.pages();
    const dissMonitorPage = allPages2[allPages2.length - 1];
    await dissMonitorPage.waitForLoadState('domcontentloaded');
    await dissMonitorPage.bringToFront();

    //verify page url
    await EingangPage.verifyPageUrl(dissMonitorPage);

    //verify tab is active
    await EingangPage.verifyTabisActive(dissMonitorPage, data.testCase[49].tabName);

    await elsaProPage.bringToFront();
    // this method logs out from elsaPro and GRP
    await navigation.logOut(elsaProPage)


});