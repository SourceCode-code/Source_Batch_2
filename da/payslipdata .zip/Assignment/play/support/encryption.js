class encryption {
 
    // this methode encodes a string
    encode(string) {
        let passPhrase = 5
        let encodedString = ""
        let duplicate = passPhrase
 
        for (let i = 0; i < string.length; ++i) {
            let ASCIIValue = string[i].charCodeAt(0)
            encodedString = encodedString + String.fromCharCode(ASCIIValue + passPhrase)
            passPhrase = duplicate
        }
        return encodedString
    }
 
    // this method decodes a string
    decode(codedString) {
        let passPhrase = 5
        let decodedString = ""
 
        for (let i = 0; i < codedString.length; ++i) {
            let ASCIIValue = codedString[i].charCodeAt(0)
            if(ASCIIValue- passPhrase == 92){
                decodedString = decodedString + '\\\\'
            }else
            {
                decodedString = decodedString + String.fromCharCode(ASCIIValue - passPhrase)
            }
        }
        return decodedString      
    }
}
 
export const crypt = new encryption()