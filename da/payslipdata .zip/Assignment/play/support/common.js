class Common {
  // this method removes \r \t and \n of a string
  // input should be a string
  // method should be used inside of a promise
  removeBackslashOperatorsOfString(txt) {
    return txt.text().replace(/(\r\n|\n|\r|\t)/gm, "");
  }

  // This method is to get today's date in the format: dd-mm-yy
  // offset default is zero unless you send another value
  async getTodayDate(offset = 0) {
    const today = new Date();
    today.setDate(today.getDate() + offset);
    const dd = String(today.getDate()).padStart(2, "0");
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // January is 0!
    const yy = today.getFullYear().toString(); // Get last two digits of the year
    const formattedDate = `${yy}-${mm}-${dd}`;
    console.log("Formatted Date:", formattedDate); // Log in the console
    return formattedDate;
  }

  // This method is to get today day only 
  async getCurrentDay() {
    var today = new Date();
    var currentDay = String(today.getDate()).padStart(2, "");
    console.log({ currentDay });
    return currentDay;
  }

  async getRandomAlphanumeric(length) {
    const collection = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += collection.charAt(Math.floor(Math.random() * collection.length));
    }
    return result;
  }

  async getRandomNumeric(length) {
    const collection = '0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += collection.charAt(Math.floor(Math.random() * collection.length));
    }
    return result;
  }

  async addRandomDaysToDate(dateString, minDays, maxDays) {
    // Regular expression to match YYYY-MM-DD format
    const regex = /^\d{4}-\d{2}-\d{2}$/;

    // Check if the format is correct
    if (!regex.test(dateString)) {
      return false;
    }

    const date = new Date(dateString);
    if (isNaN(date)) {
      return "Invalid date";
    }

    const randomDays = Math.floor(Math.random() * (maxDays - minDays + 1)) + minDays;
    date.setDate(date.getDate() + randomDays);

    return date.toISOString().split('T')[0]; // Returns the date in YYYY-MM-DD format
  }

  async getRandomIntegerBetween(min, max) {
    // Validate that max is greater than or equal to min
    if (max < min) {
      throw new Error('Max number must be greater than or equal to min number.');
    }

    // Generate random integer between min and max (inclusive)
    const randomNum = Math.floor(Math.random() * (max - min + 1)) + min;

    return randomNum.toString();
  }

  //generate a random number for auftragsnummer/order number
  async generateRandomOrderNumber() {
    // Generate random month and day
    const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0'); // 01 to 12
    const day = String(Math.floor(Math.random() * 31) + 1).padStart(2, '0'); // 01 to 31
    const year = String(Math.floor(Math.random() * 100)).padStart(2, '0'); // 00 to 99
    const suffix = String(Math.floor(Math.random() * 99) + 1).padStart(2, '0'); // 01 to 99
    console.log('this is the generated random number:' + `"${month}${day}${year}-${suffix}"`)
    const generatedRandomNumber = `${month}${day}${year}-${suffix}`
    return generatedRandomNumber.toString();
  }
}

export const common = new Common();