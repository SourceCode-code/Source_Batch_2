const { test, expect, chromium } = require('@playwright/test');

class auftraglistePage {
    mainIframe = '#mainFs'
    auftragsnummerTextField = 'input[name="GridAuftrList$ctl23$_2_"]'
    searchButton = '//input[@class="FilterButton"][contains(@name, "submit")]'
    clearSearchButton = '//input[@class="FilterButton"][contains(@name, "reset")]'
    allTableHeaders = '#GridAuftrList tr[class^="ListHeader"] td[onmouseover] a, #GridAuftrList tr[class^="ListHeader"] td:not(:has(a)):not(:has(div))'
    allRows = '#GridAuftrList tr[class^="Row"]'
    firstEditIcon = '[id="GridAuftrList_ctl03_IbBeaList"]'
    lockIconBAID = '//table[@id="GridBeaList"]//td[text()="BA-ID"]/ancestor::tr[contains(@class,"Row")]//td//input[@src="img/lock.gif"]'
    editIconBAID = '//table[@id="GridBeaList"]//td[text()="BA-ID"]/ancestor::tr[contains(@class,"Row")]//td//input[@src="img/edit.gif"]'
    tabs = '[id="BeaTabs_div"] a'
    headerRowLabel = '//table[@id="GridAuftrList"]//tr[@class="ListHeader"]//*[self::a or self::td][text()="label"]//parent::td'
    searchTextInput = '(//table[@id="GridAuftrList"]//tr[@class="ListQuery"]//input[@type="text"][contains(@name, "$_index_")])'
    allPageSelectors = '//tr[@class="PageSelect"]//*[self::span or self::a]'
    pageSelector = '//tr[@class="PageSelect"]//*[self::span or self::a][text()="pageNum"]'
    sortableColumns = '//table[@id="GridAuftrList"]//tr[@class="ListHeader"]//*[self::a or self::td]//parent::td/a'
    WBCheckbox = '//table[@id="GridAuftrList"]//tr[@class="ListQuery"]//input[@type="checkbox"]'
    tableValueForSpecificColumn = '//table[@id="GridAuftrList"]//tr[starts-with(@class,"Row")]//td[count(//table[@id="GridAuftrList"]//tr[@class="ListHeader"]//*[self::a or self::td][text()="columnLabel"]//parent::td//preceding-sibling::td)+1]'


    async fillAuftragsnummer(page, auftragsnummer) {
        await page.waitForLoadState("load")
        await page.fill(this.auftragsnummerTextField, auftragsnummer);
    }

    async clickOnSearchButton(page) {
        await page.waitForLoadState("load")
        await page.locator(this.searchButton).click()
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    }

    async clickOnClearSearchButton(page) {
        await page.waitForLoadState("load")
        await page.locator(this.clearSearchButton).click()
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    }

    // this method verifies on coulmn value for specific order number (auftragsnummer)
    // auftragsnummer is the needed auftragsnummer want to verify value for from the table
    // columnLabel is the coulmn label (i.e. Auftragsdatum, BA/Anfr .... etc.)
    // expectedValue is the value needs to be asserted
    // refer to (130614) as a usage refernce 
    async verifyColumnValueForOrderNumber(page, auftragsnummer, columnLabel, expectedValue) {
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        let isRowFound = false
        let allTableHeadersText = []
        let rowText = []
        let row = 0
        let rowIndex = 0
        const allTableHeaders = await page.locator(this.allTableHeaders).all()
        const allRows = await page.locator(this.allRows).all()

        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        await allTableHeaders[0].waitFor({ state: "attached", timeout: 10000 });
        await allTableHeaders[0].waitFor({ state: "visible", timeout: 10000 });

        // get all table headers
        for (let i = 0; i < allTableHeaders.length; i++) {
            await allTableHeadersText.push((await allTableHeaders[i].textContent()).trim())
        }
        await console.log(allTableHeadersText)
        // go row by row 
        for (let i = 0; i < allRows.length; i++) {
            rowText = []
            row = await allRows[i].locator("td").all()

            // get each row values
            for (let j = 0; j < row.length; j++) {
                await rowText.push((await row[j].textContent()).trim())
            }

            // check if the current row is matching the expected one with auftragsnummer
            if (auftragsnummer === rowText[allTableHeadersText.indexOf("Auftragsnummer")]) {
                isRowFound = true
            }
            else {
                isRowFound = false
                break
            }
            if (isRowFound) {
                rowIndex = i
                break
            }
        }
        await console.log(rowText)
        if (!(isRowFound)) {
            throw new Error(`Required row is not existed`);
        }
        else {
            await expect(rowText[allTableHeadersText.indexOf(`${columnLabel}`)]).toEqual(expectedValue, { timeout: 10000 })
        }
    }

    //click on firstedit icon after searching for an order
    async clickfirstEditicon(page) {
        await page.locator(this.firstEditIcon).click({ timeout: 5000 });
    }

    //check that lock icon is visible for specific BA-ID
    async verifyLockIconisVisible(page, baID) {
        const loc = (this.lockIconBAID).replace('BA-ID', baID);
        await expect(await page.locator(loc)).toBeVisible({ timeout: 10000 });
    }

    //check that edit icon is not visible for specific BA-ID
    async verifyEditIconnotVisible(page, baID) {
        const loc = (this.editIconBAID).replace('BA-ID', baID);
        await expect(await page.locator(loc)).toBeHidden();
    }

    //click on lock icon of BA-ID
    async clickLockIcon(page, baID) {
        const loc = (this.lockIconBAID).replace('BA-ID', baID);
        await page.locator(loc).click({ timeout: 10000 });
    }

    //verify status of tabs (Beanstandungs-Erfassung, Werkstattfeststellung, Technische Reparaturanfrage
    //,Zusammenfassung)
    //status whether Disabled, Active

    async verifyTabStatus(page, tab, status) {
        const loc = await page.locator(this.tabs).filter({ hasText: tab });
        await expect(loc).toHaveClass(`${status}Tab`);
    }

    // click on sub tabs in auftragliste tabs
    async clickOnSubTab(page, tabName) {
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        await page.waitForLoadState('load')
        let btnSelector;
        switch (tabName) {
            case 'Produktiv':
                btnSelector = 'a[id="P_AuftragTabs_ctl00_Hl"]'
                break;
            case 'Archiv':
                btnSelector = 'a[id="P_AuftragTabs_ctl01_Hl"]'
                break;
            case 'Offene Archivkandidaten':
                btnSelector = 'a[id="P_AuftragTabs_ctl02_Hl"]'
                break;
        }
        await page.locator(btnSelector).click()
        // verify tab have the expected status class
        await expect(page.locator(btnSelector)).toHaveClass('ActiveTab', { timeout: 10000 })
    }

    // enter text in search field
    // fiedl label could ba any of the coulmn headers (Auftragsnummer, Fahrgestellnummer, ... etc.)
    async enterTextInSearchFields(page, fieldLabel, searchText) {
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        await page.waitForLoadState('load')
        const headerRowLabelLocator = await page.locator(this.headerRowLabel.replace("label", fieldLabel))
        await headerRowLabelLocator.waitFor({ state: "visible", timeout: 10000 });
        let nameIndex = (await (await headerRowLabelLocator.getAttribute('onmouseover')).match(new RegExp("(?<=,)\\s*(\\d+)"))[0]).trim()
        const searchTextInputLocator = await page.locator(this.searchTextInput.replace("index", nameIndex))
        await searchTextInputLocator.waitFor({ state: "visible", timeout: 10000 });
        await page.fill(this.searchTextInput.replace("index", nameIndex), searchText);
    }

    // verify visible page numbers selectors at the bottom of the page
    // expectedPageNumbers is array with the expected page numbers (i.e. ['1','2'])
    async verifyVisiblePageNumbers(page, expectedPageNumbers) {
        let actualPageNumbers = []
        const allPageSelectors = await page.locator(this.allPageSelectors).all()
        await allPageSelectors[0].waitFor({ state: "visible", timeout: 10000 });
        // get all visible page numbers
        for (let i = 0; i < allPageSelectors.length; i++) {
            await actualPageNumbers.push((await allPageSelectors[i].textContent()).trim())
        }
        expect(expectedPageNumbers).toEqual(actualPageNumbers);
    }

    // click on page number
    // pageNum is the page number you want to navigate to
    async selectPage(page, pageNum) {
        const pageSelector = await page.locator(this.pageSelector.replace("pageNum", pageNum))
        await pageSelector.waitFor({ state: "visible", timeout: 10000 });
        let tag_name = await pageSelector.evaluate(element => element.tagName.toLowerCase())
        await console.log(tag_name)
        if (tag_name == 'span') {
            console.log(`⚠️: Page ${pageNum} is already selected`)
        }
        if (tag_name == 'a') {
            await pageSelector.click({ timeout: 5000 });
            // ensure that page is selected
            await expect(pageSelector).not.toHaveAttribute('href');
            expect(await pageSelector.evaluate(element => element.tagName.toLowerCase())).toEqual('span');
        }
    }

    // verify number of rows after filtring
    async verifyCountOfRows(page, expectedRowCount) {
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        await expect(await (await page.locator(this.allRows).all()).length).toEqual(parseInt(expectedRowCount))
    }

    // verify column is sortable or not
    // expectedSortableColumnsNames is array containing the columns names expected to be sortable
    async verifyTableColumnIsSortable(page, expectedSortableColumnsNames) {
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        let actualSortableColumnsNames = []
        const allSortableColumns = await page.locator(this.sortableColumns).all()

        await allSortableColumns[0].waitFor({ state: "attached", timeout: 10000 });
        await allSortableColumns[0].waitFor({ state: "visible", timeout: 10000 });

        // get all table headers
        for (let i = 0; i < allSortableColumns.length; i++) {
            await actualSortableColumnsNames.push((await allSortableColumns[i].textContent()).trim())
        }
        expect(actualSortableColumnsNames).toEqual(expectedSortableColumnsNames);
    }

    // this method check WB checkbox
    async checkWBCheckbox(page) {
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        const checkboxLocator = await page.locator(this.WBCheckbox)
        await checkboxLocator.waitFor({ state: "visible", timeout: 10000 });
        if (!(await checkboxLocator.isChecked())) {
            await checkboxLocator.check(); // Check the checkbox
        }
        await expect(checkboxLocator).toBeChecked({ timeout: 10000 });
    }

    //verify coulmn value after search to check that filter/search is working as expected
    //columnLabel could ba any of the coulmn headers (Auftragsnummer, Fahrgestellnummer, ... etc.)
    //expectedValue could be any value, but in case of WB the expectedValue should be (checked)
    async verifyCoulmnEntriesValue(page, columnLabel, expectedValue) {
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        await page.waitForLoadState('load')
        const tableValuesInOneColumn = await page.locator(this.tableValueForSpecificColumn.replace("columnLabel", columnLabel)).all()
        await tableValuesInOneColumn[0].waitFor({ state: "attached", timeout: 10000 });
        await tableValuesInOneColumn[0].waitFor({ state: "visible", timeout: 10000 });
        if (columnLabel == "WB") {
            if (expectedValue == "checked") {
                const WBCheckedlocator = await page.locator(this.tableValueForSpecificColumn.replace("columnLabel", columnLabel) + "/img").all()
                expect(await (tableValuesInOneColumn.length)).toEqual(await (WBCheckedlocator.length))

            }
        }
        else {
            // assert all table values
            for (let i = 0; i < tableValuesInOneColumn.length; i++) {
                expect((await tableValuesInOneColumn[i].textContent()).trim()).toEqual(expectedValue)
            }
        }
    }
}

export const AuftraglistePage = new auftraglistePage();