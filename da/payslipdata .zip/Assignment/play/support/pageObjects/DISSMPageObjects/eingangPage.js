const { test, expect, chromium } = require('@playwright/test');

class eingangPage {

  filterSelector = "#DdlFilter"
  filterSelectedValue = "#DdlFilter option[selected]"
  filterNonSelectedValues = "#DdlFilter option:not([selected])"
  filterButton = "#BtnFilter"
  sortableColumn = '#GridAnfrList tr[class^="ListHeader"] td a:not([target])'
  allTableHeaders = '#GridAnfrList tr[class^="ListHeader"] td[onmouseover] a, #GridAnfrList tr[class^="ListHeader"] td:not(:has(a)):not(:has(div))'
  allRows = '#GridAnfrList tr:not([class^="ListHeader"])'
  anfrageTabelRows = '#Z_TableAnfrage tr[class^="Row"] td'
  workshopCodingTextArea = '#Z_TbWCode'
  customerCodingTextArea = '#Z_TbKCode'
  shownTabs = '[class="Tabs"] a:not([class="HiddenTab"])'
  tableHistorie = '[id="H_TableHistorie"] [class="RowOdd"] td'

  // this method select filter from filter dropdown above the table
  // value is the filter value neede to be selected
  async filterTable(page, value) {
    const filterSelectorLocator = await page.locator(this.filterSelector)
    const filterButtonLocator = await page.locator(this.filterButton)


    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    await filterSelectorLocator.waitFor({ state: "attached", timeout: 10000 });
    await filterSelectorLocator.waitFor({ state: "visible", timeout: 10000 });
    await filterButtonLocator.waitFor({ state: "visible", timeout: 10000 });

    // check if the required value is already selected so no need to select
    const selectedValueBefore = await page.locator(this.filterSelectedValue).textContent()
    if (!(await selectedValueBefore === await value)) {
      await filterSelectorLocator.selectOption(value)
      await filterButtonLocator.click()
      await page.waitForLoadState("load")
      await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
      await expect(await page.locator(this.filterSelectedValue)).toHaveText(value, { timeout: 6000 }); // Timeout can be adjusted as needed
    }
  }

  // this method sort DISSM table columns asc or desc
  // column is the column header name
  // sortingType is one of this two values:
  // 1 - "asc" for ascending
  // 2 - "desc" for descending
  async sortTableByColumn(page, column, sortingType) {
    const sortableColumnLocator = await page.locator(this.sortableColumn + `:text-is("${column}")`)
    const sortedColumnArrowLocator = await sortableColumnLocator.locator('xpath=..').locator("img")

    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    await sortableColumnLocator.waitFor({ state: "attached", timeout: 10000 });
    await sortableColumnLocator.waitFor({ state: "visible", timeout: 10000 });

    // check if the column is already sorted
    if (sortedColumnArrowLocator.count() > 0) {
      let sortingTybeBefore = await sortedColumnArrowLocator.getAttribute('src');
      if (!(sortingTybeBefore === sortingType)) {
        await sortableColumnLocator.click()
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
      }
    }

    // if the column is not sorted so we will click on the column 2 times maximum to sort it as expected 
    else {
      for (let i = 0; i < 2; i++) {
        await sortableColumnLocator.click()
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        if ((await sortedColumnArrowLocator.getAttribute('src')).includes(sortingType)) {
          break;
        }
      }
    }
    await page.waitForTimeout(1000);
    await expect(await sortedColumnArrowLocator.getAttribute('src')).toContain(sortingType)
  }

  // click on Lesen
  // filterObject is key value object, refer to 128182 test case as a usage referance
  async clickOnLesen(page, filterObject) {
    let isRowFound = false
    let row = 0
    let rowIndex = 0
    let allTableHeadersText = []
    const allTableHeaders = await page.locator(this.allTableHeaders).all()
    const allRows = await page.locator(this.allRows).all()

    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    await allTableHeaders[0].waitFor({ state: "attached", timeout: 10000 });
    await allTableHeaders[0].waitFor({ state: "visible", timeout: 10000 });

    // get all table headers
    for (let i = 0; i < allTableHeaders.length; i++) {
      await allTableHeadersText.push((await allTableHeaders[i].textContent()).trim())
    }

    // go row by row 
    for (let i = 0; i < allRows.length; i++) {
      let rowText = []
      row = await allRows[i].locator("td").all()

      // get each row values
      for (let j = 0; j < row.length; j++) {
        await rowText.push((await row[j].textContent()).trim())
      }

      // check if the current row is matching the expected filter
      for (const [key, value] of Object.entries(filterObject)) {
        if (filterObject[key] === rowText[allTableHeadersText.indexOf(key)]) {
          isRowFound = true
        }
        else {
          isRowFound = false
          break
        }
      }
      if (isRowFound) {
        rowIndex = i
        break
      }
    }
    if (!(isRowFound)) {
      throw new Error(`Required row is not existed`);
    }
    else {
      await allRows[rowIndex].locator('input[title = "Lesen"]').click()
      await allRows[rowIndex].locator('input[title = "Lesen"]').waitFor({ state: "hidden", timeout: 10000 });
    }
  }

  // verfiy values from anfrage table after click on Lesen for complaint
  // rgeRex default value is false, so value parameter expected to be noraml string
  // if rgeRex is true , so value parameter expected to be regular expression
  // refer to 128182 test case as a usage referance
  async verifyValueFromAnfrageTable(page, label, value, regRex = false) {
    const labelLocator = await page.locator(this.anfrageTabelRows).filter({ hasText: label })

    await labelLocator.waitFor({ state: "attached", timeout: 10000 });
    await labelLocator.waitFor({ state: "visible", timeout: 10000 });

    const actualValue = await (await labelLocator.locator('~td').textContent()).trim()
    if (!(regRex)) {
      await expect(actualValue).toEqual(value, { timeout: 10000 })
    }

    else {
      await expect(actualValue).toMatch(new RegExp(value), { timeout: 10000 });
    }
  }

  // verify Workshop coding/Werkstattcodierung value
  async verifyWorkshopCoding(page, value) {
    const workshopCodingTextArea = await page.locator(this.workshopCodingTextArea)
    const actualValue = await (await workshopCodingTextArea.textContent()).trim()
    await expect(actualValue).toEqual(value, { timeout: 10000 })
  }

  // verify Customer coding/Kundencodierung value
  async verifyCustomerCoding(page, value, BAID = "") {
    let actualValue = ""
    if (BAID == "") {
      const customerCodingTextArea = await page.locator(this.customerCodingTextArea)
      actualValue = await (await customerCodingTextArea.textContent()).trim()
    }
    else {
      const customerCodingTextArea = await page.locator(this.customerCodingTextArea.split("_")[0]
        + "_"
        + `MLS_${BAID}`
        + "_"
        + this.customerCodingTextArea.split("_")[1]
      )
      actualValue = await (await customerCodingTextArea.textContent()).trim()
    }
    await expect(actualValue).toEqual(value, { timeout: 10000 })
  }

  // Click tab after opening
  async clickSpecificTabAfterOpeningDissMonitor(page, tabName) {
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    await page.waitForLoadState('load')
    let btnSelector;
    switch (tabName) {
      case 'Eingang':
        btnSelector = 'a[id="N_MonTabs_ctl00_Hyperlink1"]'
        break;
      case 'In Bearbeitung':
        btnSelector = 'a[id="N_MonTabs_ctl01_Hyperlink1"]'
        break;
      case 'Versendete Anfragen':
        btnSelector = 'a[id="N_MonTabs_ctl02_Hyperlink1"]'
        break;
      case 'Detailansicht BA':
        btnSelector = 'a[id="N_MonTabs_ctl03_Hyperlink1"]'
        break;
      case 'Suche':
        btnSelector = 'a[id="N_MonTabs_ctl04_Hyperlink1"]'
        break;
      case 'Auftragliste':
        btnSelector = 'a[id="N_MonTabs_ctl05_Hyperlink1"]'
        break;
      case 'Administration':
        btnSelector = 'a[id="N_MonTabs_ctl06_Hyperlink1"]'
        break;
    }

    await page.locator(btnSelector).click()
  }
  //verify page url
  async verifyPageUrl(page) {
    const url = await page.url();
    console.log(url);
    expect(url).toContain('jctdiss-qs')
  }

  //verify if specific tab is active
  async verifyTabisActive(page, tabName) {
    const tab = await page.locator(this.shownTabs).filter({ hasText: tabName });
    await expect(tab).toHaveClass('ActiveTab');
  }

  //click on specific tab
  async clickSpecificTabAfterOpeningDissMonitorFromGrp(page, tabName) {
    const tab = await page.locator(this.shownTabs).filter({ hasText: tabName });
    await tab.click({ timeout: 5000 });
  }

  //check if given date is todays date
  async checkiftodaysdate(date) {
    const today = new Date().toISOString().split('T')[0];
    console.log(today, '<>', date);
    expect(date).toEqual(today);
  }
  //get the date in Kommunikationshistorie
  async getdateKommunikationshistorie(page) {
    const loc = await page.locator(this.tableHistorie).nth(0)
    const content = (await loc.textContent()).split(', ');
    console.log(content);
    return content;
  }

  //get the value of Rückinfozeit/feedback time From Anfrage Table
  async getFeedbackTimeValueFromAnfrageTable(page) {
    const labelLocator = await page.locator(this.anfrageTabelRows).filter({ hasText: 'Rückinfozeit:' })
    let actualValue = await (await labelLocator.locator('~td').textContent()).trim();
    actualValue = actualValue.replace(';', '').replace(/\+\d{2}:\d{2}/g, '').split(' ');
    console.log(actualValue);
    return actualValue;

  }

  //get time difference
  async getTimeDifference(time1, time2, expectedDifference) {
    const [h1, m1] = time1.split(':').map(Number);
    const [h2, m2] = time2.split(':').map(Number);
    let diff = Math.abs(h2 - h1) + Math.abs(m2 - m1) / 60;
    console.log(diff);
    expect(diff).toEqual(expectedDifference);
  }

  //check tab status
  async verifyTabStatus(page, tab, status) {
    const loc = await page.locator(this.shownTabs).filter({ hasText: tab });
    await expect(loc).toHaveClass(`${status}Tab`);
  }
}

export const EingangPage = new eingangPage();