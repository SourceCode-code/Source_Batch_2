const { test, expect, chromium } = require('@playwright/test');

class AdministrationPage {

    showntabs = '//div[@class="Tabs"][2]//a[not(contains(@class, "HiddenTab"))]';

    //This method will verify the url of the page
    async verifyPageUrl(page) {
        const url = await page.url();
        console.log(url);
        expect(url).toContain('config=ADMINISTRATION')
    }

    // this method verify the tab of Admin -->they must exist and be visible
    //tabName is the name of specific tab and is string
    //index start from 0
    async verifySpecificAdminTabStatusAfterOpeningDissMonitorFromGrp(page, tabName) {
        const tabs = await page.locator(this.showntabs).allTextContents();
        console.log(tabs);
        for (let i = 0; i < tabName.length; i++) {
            expect(tabs).toContain(tabName[i]);
        }
    }

  
}
export const administrationPage = new AdministrationPage(); 