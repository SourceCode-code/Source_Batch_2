import { env } from "../env";
import { crypt } from "../encryption";
const { headers } = require('../pageObjects/elsaPageObjects/headers');
const otplib = require('otplib'); // Ensure you install otplib via npm
const { test, expect, chromium } = require('@playwright/test');


class navigationToUrl {
  userNameTxtfield = 'input[id="username"]';
  passwordTxtfield = 'input[id="password"]';
  submitButton = 'button[type="submit"]'
  TOTPLoginButton = 'text=TOTP LOGIN'
  verifyButton = 'text=Verify'
  contextDropdown = 'li[id="mcontext"] a'
  logOutTitle = ".card-title > span";
  logOutSelector = 'a[href*="/web/logout"]';
  GRPUserNameDropdown = 'li[class="has-sub user-dropdown"]'
  entertotp = '[id="otp"]'
  overlayUIPreloader = '.preloader'
  dissPortalTab = 'a.PortalTab'

  // this method navigates to the baseURL in config.js
  async navigateToBaseUrl(page) {
    //this will navigate to baseURL inside playwright.config
    await page.goto('');
  }

  // this method logs in the user
  async loginWithCredentials(page, user) {
    let credentials = env.getCredentials(user);
    let decodedPassword = crypt.decode(credentials.password);
    await page.fill(this.userNameTxtfield, credentials.username); // Fill username input
    await page.fill(this.passwordTxtfield, decodedPassword); // Fill password input
    await page.click(this.submitButton);
    await page.waitForTimeout(2000)
    // Check if the element is visible
    const isVisible = await page.locator(this.TOTPLoginButton).isVisible();

    // If the element is visible, click on it
    if (isVisible) {
      console.log(`Element with selector "${this.TOTPLoginButton}" found. Clicking it.`);
      await page.locator(this.TOTPLoginButton).click();
      // Wait for TOTP field to be visible
      await page.waitForSelector(this.entertotp, { timeout: 5000 });
      let decodedSecret = crypt.decode(credentials.secret)
      // Generate TOTP dynamically using the decoded secret
      const token = otplib.authenticator.generate(decodedSecret);
      console.log(token)
      // Fill in the TOTP token
      await page.locator(this.entertotp).fill(token);
      // wait  for page to load
      await page.waitForTimeout(2000)
      // Click on verify
      await page.locator(this.verifyButton).click();
    } else {
      console.log(`Element with selector "${this.TOTPLoginButton}" not found.`);
    }

    // wait for Preloader to dissapear
    await this.checkPreloaderInvisible(page)
  }


  // change context from GRP page
  async GRP_Context(page, context) {
    const contextDropdownLocator = await page.locator(this.contextDropdown)
    await contextDropdownLocator.waitFor({ state: "attached", timeout: 10000 });
    await contextDropdownLocator.waitFor({ state: "visible", timeout: 10000 });
    await contextDropdownLocator.click({ delay: 2 });
    await page.locator('#header-fm\\:contextContent').locator(`text=${context}`).waitFor({ state: "attached", timeout: 10000 });
    await page.locator('#header-fm\\:contextContent').locator(`text=${context}`).waitFor({ state: "visible", timeout: 10000 });
    await page.locator('#header-fm\\:contextContent').locator(`text=${context}`).click({ delay: 2 });
    await page.locator('#header-fm\\:contextContent').locator(`text=${context}`).waitFor({ state: "hidden", timeout: 10000 });
    // wait for Preloader to dissapear
    await this.checkPreloaderInvisible(page)
  }

  // Click on specific Application 
  async goToApplication(page, app, user) {
    // wait for Preloader to dissapear
    await this.checkPreloaderInvisible(page)

    // get number of already opend tabs before click on App
    const numberOfTabsBeforeClickOnApp = await this.getNumberOfOpenTabs(page, await this.getCurrentBrowserContext(await page))


    await Promise.all([
      page.waitForNavigation(),
      await page.locator(`(//a[normalize-space()='${app}']/ancestor::div[@class='app-box-container ']//a[@class='ui-commandlink ui-widget app-box flex--vcenter flex--hcenter '])[1]`).click(),
    ])
    let startTime = Date.now();
    while ((await Date.now() - await startTime < 10000)) {
      if ((await (this.getNumberOfOpenTabs(page, await this.getCurrentBrowserContext(await page))) == numberOfTabsBeforeClickOnApp)) { }
      else {
        break;
      }
      await page.waitForTimeout(1000)
    }

    // selecting the new pages from page context
    const appPage = await ((await this.getCurrentBrowserContext(await page)).pages())[0]
    await appPage.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    await appPage.waitForLoadState("load")
    await appPage.waitForLoadState("domcontentloaded")

    // get credentials to use if the TOTP appears again in some rare cases
    let credentials = env.getCredentials(user);

    // Check if the TOTP Button is visible
    const isVisible = await appPage.locator(this.TOTPLoginButton).isVisible();

    // If the TOTP Button is visible, click on it and enter the OTP
    if (isVisible) {
      console.log(`Element with selector "${this.TOTPLoginButton}" found. Clicking it.`);
      await appPage.locator(this.TOTPLoginButton).click();
      // Wait for TOTP field to be visible
      await appPage.waitForSelector(this.entertotp, { timeout: 5000 });
      let decodedSecret = crypt.decode(credentials.secret)
      // Generate TOTP dynamically using the decoded secret
      const token = otplib.authenticator.generate(decodedSecret);
      console.log(token)
      // Fill in the TOTP token
      await appPage.locator(this.entertotp).fill(token);
      // wait  for appPage to load
      await appPage.waitForTimeout(5000)
      // Click on verify
      await appPage.locator(this.verifyButton).click();
    } else {
      console.log(`Element with selector "${this.TOTPLoginButton}" was not found after selecting the tile.`);
    }
  }

  // this method logs out of grp-prelive
  async logOutGRP(page) {
    // verify page loaded
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });

    // wait for Preloader to dissapear
    await this.checkPreloaderInvisible(page)
    // verify element visibility
    await page.locator(this.GRPUserNameDropdown).waitFor({ state: "attached", timeout: 10000 });
    await page.locator(this.GRPUserNameDropdown).waitFor({ state: "visible", timeout: 10000 });

    await page.locator(this.GRPUserNameDropdown).hover()
    await page.locator(this.logOutSelector).click({ force: true });
    console.log("logged out of grp-prelive");
  }

  // this method logs out from elsaPro and GRP
  async logOut(page) {
    //log out ElsaPro
    await headers.clickOnLogOutBtn(page);
    await page.waitForTimeout(2000)
    // log out grp prelive
    await this.logOutGRP(page);
    //verify log out grp prelive
    await expect(page.locator(this.logOutTitle)).toHaveText("LOGOUT");
  }

  // this method logs out from DISSM and GRP
  async logOutDISSM(page) {
    //log out ElsaPro
    await page.locator(this.dissPortalTab).click({ force: true });
    await page.waitForTimeout(2000)
    // log out grp prelive
    await this.logOutGRP(page);
    //verify log out grp prelive
    await expect(page.locator(this.logOutTitle)).toHaveText("LOGOUT");
  }

  async getNumberOfOpenTabs(page, context) {
    let startTime = Date.now();
    let numberOfTabs = 0
    while ((Date.now() - startTime) < 15000) {
      try {
        numberOfTabs = await context.pages().length
        break
      }
      catch (error) { await page.waitForTimeout(1000) }
    }
    return numberOfTabs
  }

  async getCurrentBrowserContext(page) {
    let currentContext = await page.context()
    return currentContext
  }

  // wait for Preloader to dissapear
  async checkPreloaderInvisible(page) {
    const preloaderLocator = await page.locator(this.overlayUIPreloader)
    const timeout = 15000
    const interval = 100
    const loopCondition = timeout / interval

    // wait for Preloader to dissapear
    for (let i = 0; i < loopCondition; i++) {
      // Check if Preloader exists
      if (await preloaderLocator.isVisible()) {
        await preloaderLocator.waitFor({ state: "attached", timeout: 10000 })
        console.log("Preloader appears");
      }
      else {
        await preloaderLocator.waitFor({ state: "hidden", timeout: 10000 });
        console.log("Preloader disappears or doesn't appear at first");
        break;
      }
      await page.waitForTimeout(interval);
    }
  }
}

export const navigation = new navigationToUrl();