const { test, expect, chromium } = require('@playwright/test');

class editpage {
    labelNameSelector = 'table[class="table8"] > tbody > tr'
    infomediaSelector = 'select[id="selection"]'
    infomediaIframe = 'iframe[name="frameCodeSelected"]'
    selectionColumnIframe = 'iframe[name="frameCodeSelection"]'
    thridtabeselectionframe = 'iframe[name="frameCodeSelectionSec"]'
    lagetableheader = '[class="table6 height90percent width100percent"]:nth-child(1) tbody tr:nth-child(1) td:nth-child(2)'
    lageinfomediaselector = '[class="table6 height90percent width100percent"]:nth-child(1) tbody tr td select'
    AllgRandbedingungenandinfomediaselector = '[class="height90percent"] td[class="norepeat height85percent valigntop"] [id="childSelection_11"] select'
    Addinfomediabtn = '[class="valignmiddle"] button[id="selectNewValues_BT"]'
    Übernehmenbtn = '[class="table3 width100percent"] [id="USE_TO_RETURN_BT"]'
    searchtextinputbox = '[id="textSearch"]'
    searchbtn = '[id="Btn_textSearch"]'
    searchpart = '[id="Btn_tnrSearch"]'
    frameSearch = '[name="frameSearch"]'
    resultframe = '[id="frameResultSet"]'
    tabSelector = '[id="tabbedheader"]> ul>li>a:text-is("stringText")'
    tabbedHeaderFrame = 'iframe[name="frameTabbedHeader"]'
    selectDoubleArrowButton = '[id="selectNewValues_BT"]'
    unselectDoubleArrowButton = '[id="deselectOldValues_BT"]'
    childOptionsLocator = '[id^="childSelection"][class="show"]>select>option'
    VorläufigÜbernehmenBtn = '[class="table3 width100percent"] [id="USE_TEMP_TO_RETURN_BT"]'


    // the method verifys the label name and selects the infomedia value for it from primary column (first coulmn from left to right)
    async verifyTheLabelAndSelectInfomedia(page, labelName, infomedia) {
        // Iterate through both arrays
        for (let i = 0; i < labelName.length; i++) {
            await page.waitForTimeout(1000)
            // await page.frameLocator(this.selectionColumnIframe).locator('option[id="selectionId11"]').click()
            // Verify the label name
            const labelSelector = `${this.infomediaIframe} >> text=${labelName[i]}`;
            await page.frameLocator(this.infomediaIframe).locator(this.labelNameSelector).locator(labelSelector).isVisible();

            // select the value to be selected for that label
            await page.frameLocator(this.selectionColumnIframe).locator(this.infomediaSelector).locator(`text=${infomedia[i]}`).nth(0).click();
        }
    }

    // the method click on label 
    async clickOnTheLabel(page, labelName) {
        await page.waitForLoadState("networkidle")
        // Iterate through both arrays
        for (let i = 0; i < labelName.length; i++) {
            await page.waitForTimeout(1000)
            await page.frameLocator(this.infomediaIframe).locator(`input[value=${labelName}]`).click();
        }
    }

    // Click on Übernehmen button
    async clickÜbernehmenButton(page) {
        // await page.waitForSelector(this.Übernehmenbtn, { state: 'visible' });
        await page.waitForLoadState("load")
        await page.frameLocator(this.infomediaIframe).locator(this.Übernehmenbtn).scrollIntoViewIfNeeded()
        await page.frameLocator(this.infomediaIframe).locator(this.Übernehmenbtn).click({ force: true, clickCount: 3, delay: 2 })
    }
    //can be used only when partical feilds are to be selected
    // Click on Vorläufig Übernehmen button 
    async clickVorläufigÜbernehmenButton(page) {
        await page.waitForLoadState("networkidle")
        await page.frameLocator(this.infomediaIframe).locator(this.VorläufigÜbernehmenBtn).scrollIntoViewIfNeeded()
        await page.frameLocator(this.infomediaIframe).locator(this.VorläufigÜbernehmenBtn).click({ force: true, clickCount: 3, delay: 2 })
    }

    //enter the search text
    async enterSearchText(page, text) {
        await page.waitForLoadState("networkidle")
        await page.frameLocator(this.frameSearch).locator(this.searchtextinputbox).fill(text)
    }

    //click on search btn for search text box
    async ClickonSearchforsearchtextbox(page) {
        await page.waitForLoadState("networkidle")
        await page.frameLocator(this.frameSearch).locator(this.searchbtn).click()
    }

    //select the entry form the search table 
    async SelectThecorrectEntry(page, rowText) {
        await page.waitForLoadState("networkidle")
        await page.frameLocator(this.frameSearch).frameLocator(this.resultframe).locator(`.elementColorB:has-text("${rowText}")`).click({ force: true })

    }


    //click on search btn for part number box 
    async ClickonSearchfornumberbox(page) {
        await page.waitForLoadState("networkidle")
        await page.frameLocator(this.frameSearch).locator(this.searchpart).click()
    }

    // select tab from the tab hearder in edit pop up
    // tab is the tab name
    async selectTab(page, tab) {
        // let tabString = tab.replace("", /\u00A0/g,);
        await page.waitForLoadState("load")
        const locator = await page.frameLocator(this.tabbedHeaderFrame).locator(this.tabSelector.replace("stringText", tab));
        await locator.waitFor({ state: "attached", timeout: 10000 });
        await locator.waitFor({ state: "visible", timeout: 10000 });
        await locator.click();
        await page.waitForLoadState("load")
    }

    // the method verifys the label name and selects the infomedia value for it from secondary column (second coulmn from left to right)
    async verifyTheLabelAndSelectInfomediaSecondary(page, labelName, infomedia) {
        // Iterate through both arrays
        for (let i = 0; i < labelName.length; i++) {
            await page.waitForTimeout(1000)
            // Verify the label name
            const labelSelector = `${this.infomediaIframe} >> text=${labelName[i]}`;
            await page.frameLocator(this.infomediaIframe).locator(this.labelNameSelector).locator(labelSelector).isVisible();

            // select the value to be selected for that label
            await page.frameLocator(this.thridtabeselectionframe).locator(this.infomediaSelector).locator(`text=${infomedia[i]}`).nth(0).click();
        }
    }

    // this method select position on the car body when you click on "Positionen" tab
    // positionNumber is a string list contains the position number need to be selected ['1','15',...etc.]
    async selectBodyPositions(page, positionNumber) {
        await page.waitForLoadState("load")
        for (let i = 0; i < positionNumber.length; i++) {
            await page.frameLocator(this.selectionColumnIframe).locator(`[id="pictureBackground"]>div[id="selectionPopup_${positionNumber[i]}"]`).nth(0).click({ force: true });
            await page.waitForLoadState("load")
            await page.waitForTimeout(1000)
        }
        await page.waitForLoadState("load")
        await this.clickOnSelectDoubleArrowButton(page)
        await page.waitForLoadState("load")
        await page.waitForTimeout(2000)
    }

    // click on select double arrow "◄◄" to select from child lists
    async clickOnSelectDoubleArrowButton(page) {
        await page.waitForLoadState("networkidle")
        await page.frameLocator(this.selectionColumnIframe).locator(this.selectDoubleArrowButton).nth(0).click({ force: true });
    }

    // click on unselect double arrow "►►" to unselect from child lists
    async clickOnUnselectDoubleArrowButton(page) {
        await page.waitForLoadState("networkidle")
        await page.frameLocator(this.selectionColumnIframe).locator(this.unselectDoubleArrowButton).nth(0).click({ force: true });
    }

    // select option from the child table (table appears under main table like when selecting from "Allg. Randbedingungen" tab a child table appears below)
    // childOption is list contains the required childs to be selected
    async selectOptionFromChildSelection(page, childOption) {
        await page.waitForLoadState("networkidle")
        for (let i = 0; i < childOption.length; i++) {
            let locator = await page.frameLocator(this.selectionColumnIframe).locator(this.childOptionsLocator).locator(`text=${childOption[i]}`).nth(0)
            let value = await locator.getAttribute('value')
            let id = await locator.getAttribute('id')
            await expect(locator).toBeVisible({ timeout: 10000 })
            await locator.click();
            await page.waitForLoadState("networkidle")
            await this.clickOnSelectDoubleArrowButton(page)
            await page.waitForLoadState("networkidle")
            await expect(await page.frameLocator(this.infomediaIframe).locator(`[class="alignleft valigntop"]>#GENERAL_CONDITION_LEVEL>option[value="${value}"]`).nth(0)).toBeVisible({ timeout: 10000 })
            await expect(await page.frameLocator(this.selectionColumnIframe).locator(this.childOptionsLocator).locator(`option[id="${id}"]`).nth(0)).not.toBeVisible({ timeout: 10000 })
        }
    }

    // the method verifys the label name and infomedia value
    async verifyLabelAndInfomedia(page, labelName, infomedia) {
        let actualLabelName = ""
        let actualInfomediaValue = ""
        // Iterate through both arrays
        for (let i = 0; i < labelName.length; i++) {
            await page.waitForTimeout(1000)
            // get the label name
            actualLabelName = await page.frameLocator(this.infomediaIframe).locator(`table>tbody>tr>td[class="alignleft valigntop"]>input[class="buttonSelection"][value="${labelName[i]}"]`).getAttribute('value');

            // get the infomedia value
            actualInfomediaValue = await page.frameLocator(this.infomediaIframe).locator(`table>tbody>tr>td[class="alignleft valigntop"]>input[class="buttonSelection"][value="${labelName[i]}"]`).locator('xpath=..').locator('xpath=..').locator('td[class="alignleft valigntop"]>input[class="selectionData"]').getAttribute('value');

            // verify the label name
            // replace here used for replacing &nbsp in attribute value
            await expect(actualLabelName.replace(/\u00A0/g, " ").trim()).toEqual(labelName[i].trim())

            // verify the infomedia value
            // replace here used for replacing &nbsp in attribute value
            await expect(actualInfomediaValue.replace(/\u00A0/g, " ").trim()).toEqual(infomedia[i].trim())
        }
    }

    // the method verifys Body Positions
    async verifyBodyPositions(page, infomedia) {
        const labelName = "Positionen"
        const actualLabelName = await page.frameLocator(this.infomediaIframe).locator('table>tbody>tr>td[class="alignleft valigntop"]>input[class="buttonSelection"][value="Positionen"]').getAttribute('value');
        let actualInfomediaValue = ""

        // verify the label name
        // replace here used for replacing &nbsp in attribute value
        await expect(actualLabelName.replace(/\u00A0/g, " ").trim()).toEqual(labelName.trim())

        for (let i = 0; i < infomedia.length; i++) {
            await page.waitForTimeout(1000)
            // get the infomedia value
            actualInfomediaValue = await page.frameLocator(this.infomediaIframe).locator('[id="EO_POSITION"][size]>option').nth(i).textContent();

            // verify the infomedia value
            // replace here used for replacing &nbsp in attribute value
            await expect(actualInfomediaValue.replace(/\u00A0/g, " ").trim()).toEqual(infomedia[i].trim())
        }
    }

    // the method verifys General Condition
    async verifyGeneralCondition(page, infomedia) {
        const labelName = "Allg. Randbedingungen"
        const actualLabelName = await page.frameLocator(this.infomediaIframe).locator('table>tbody>tr>td[class="alignleft valigntop"]>input[id="GENERAL_CONDITION_LEVEL_BT"]').getAttribute('value');
        let actualInfomediaValue = ""

        // verify the label name
        // replace here used for replacing &nbsp in attribute value
        await expect(actualLabelName.replace(/\u00A0/g, " ").trim()).toEqual(labelName.trim())

        for (let i = 0; i < infomedia.length; i++) {
            await page.waitForTimeout(1000)
            // get the infomedia value
            actualInfomediaValue = await page.frameLocator(this.infomediaIframe).locator('[id="GENERAL_CONDITION_LEVEL"][size]>option').nth(i).textContent();

            // verify the infomedia value
            // replace here used for replacing &nbsp in attribute value
            await expect(actualInfomediaValue.replace(/\u00A0/g, " ").trim()).toEqual(infomedia[i].trim())
        }
    }
}

export const Editpage = new editpage()