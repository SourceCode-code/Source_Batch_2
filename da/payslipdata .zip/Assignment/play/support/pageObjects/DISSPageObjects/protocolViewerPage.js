const { test, expect, chromium } = require('@playwright/test');

class ProtocolViewer{
    pageTitle = '[class="row header"] div';
    protocolType = 'select[name="SelectedType"]';
    systemSorting = '[title="System"] .grid-header-title';
    fahrzeugidentNrField = 'input[name="VIN"]';
    searchBtn = '[value="Suchen"]';
    systemTds = '[data-name="System"]';

     // This method verifies the url of the page and its title
     async verifyPageTitle(page) {
        await expect(await page.locator(this.pageTitle)).toContainText('Protocol Viewer', {timeout:50000});
     }

     //This method verify FAhrzeugidentifikation number/FIN
    //vin is a string including number and alphabet
    //Input is string
    async verifyFahrzeugidentNr(page,vin){
        await expect(await page.locator(this.fahrzeugidentNrField)).toHaveValue(vin, {timeout:10000});
    }

     // This method verifies all protocol types in dropdown
    // option is the option of dropdown: for instance "Geführte Fehlersuche" 
    // Input is an array of strings
    async verifyProtocolTypes(page,options){
        const dropdown = await page.locator(this.protocolType);
        for (let index = 0; index < options.length; index++) {
            await expect(await dropdown.locator('option').nth(index)).toHaveText(options[index], {timeout:5000});
        }
    }
     // This method sort the system column in the table via clicking on system 
    // and verify it has been sorted: asc
    async sortAndVerifySystemInTheTable(page){
        const systembtn = await page.locator(this.systemSorting);
        const systemLoc = await page.locator(this.systemTds);
        await systembtn.click({timeout:2000});
        let previousText="";
        for(let i=0; i<await systemLoc.count(); i++){
            const currenttext = (await systemLoc.nth(i).textContent()).trim();
            if(i>0){
                expect(currenttext.localeCompare(previousText)).toBeGreaterThanOrEqual(0);
                console.log(currenttext);
            }
            previousText=currenttext;
        }
        expect(await systembtn.getAttribute('class')).toContain('sorted-asc sorted');

    }

    // This method selects an specific protocol type 
    // and verifies the specific protocol type has been selected
    async selectAndVerifySpecificOptionInProtocolTypeDropdown(page,option){
        const dropdown = await page.locator(this.protocolType);
        await dropdown.selectOption(option);
        console.log(await dropdown.locator('option:checked').textContent());
        expect(await dropdown.locator('option:checked').textContent()).toBe(option);
        

    }
}
export const protocolViewer = new ProtocolViewer();