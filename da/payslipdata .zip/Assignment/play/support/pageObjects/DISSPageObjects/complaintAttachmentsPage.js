const { test, expect, chromium } = require('@playwright/test');

class complaintAttachmentsPage {
    uploadManagerBtn = '#media-hub-button'
    closeAttachmentManagementBtn = '#BnClose'


    // click on the Open Upload Manager / Upload Manager öffne
    async clickOnOpenUploadManager(page) {
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        const uploadManagerBtnLocator = await page.locator(this.uploadManagerBtn)
        await uploadManagerBtnLocator.waitFor({ state: "visible", timeout: 10000 });
        await uploadManagerBtnLocator.click()
    }

    // click on close/Schliessen
    async clickCloseAttachmentManagement(page) {
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        const closeAttachmentManagementBtnLocator = await page.locator(this.closeAttachmentManagementBtn)
        await closeAttachmentManagementBtnLocator.waitFor({ state: "visible", timeout: 15000 });
        await closeAttachmentManagementBtnLocator.click()
    }
}
export const complaintAttachments = new complaintAttachmentsPage();