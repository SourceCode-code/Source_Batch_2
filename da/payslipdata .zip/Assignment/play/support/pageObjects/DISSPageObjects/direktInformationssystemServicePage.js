const { test, expect, chromium } = require('@playwright/test');
const { common } = require('../../../support/common');

class direktInformationssystemServicePage {

  mainIframe = "#mainFs";
  pageTitle = "span#infomedia.infoBarText";
  infoFrame = 'iframe[id="infoFrID"]';
  contentIFrame = 'iframe[id="dissProcessID"]'
  infomediaIframe = 'iframe[id="infomediaFrID"]'
  lackkalkulationZurKundencodierungPopUpIframe = 'iframe[src^="PaintCalculation.aspx"]'
  systemInfoIframe = 'iframe[id="systemsInfoId"]'
  systemLinksIframe = 'iframe[id="systemLinksID"]'
  systemLinksIDIframe = 'iframe[id="systemLinksId"]'
  newOrderBtn = '[id="BtnNeu"]';
  textAreaOfBeanstandungDesKunden = 'textarea[id="K_TbBeaText"]';
  diagnoseProtokollIcon = 'img[title="Öffnen der Online-Diagnoseprotokolle"]';
  customerComplaintField = '#K_TbBeaText';
  jaInAutoLiegenblieberSelection = '#K_RblFahrb_0'
  jaInWerkstatSelection = '#K_RblWerkBes_0'
  bearbeitenbtn = '#IbEditKCode, #T_IbTWCode'
  ComplaintTextBox = 'textarea[id="K_TbBeaText"]'
  kundensichtCodieren = 'textarea[id="K_TbKCode"], textarea[id="W_TbWCode"], textarea[id="R_TbWCode"], textarea[name="T$TbWCode"]'
  popupOkButton = 'input[id="BtOk"]'
  hstButtonSelector = '#td_403'
  contentFsIDIframe = 'iframe[id="contentFsID"]'
  nextproceedbtn = 'input[id="B_BtnProceed"]'
  messageBelowSelector = 'div[class="ErrorBar"]'
  Mileagefeildinputbox = 'input[id="A_TbKmStand"]'
  auftragsnummerTextBox = 'input[name="A$TbAuftrNr"]'
  abschliessenBtn = 'td[id="td_379"]'
  savebtnselector = 'input[id="B_BtnApply"]'
  damagerectifyinggenuinepartInput = '[id="td_560"] input'
  endbuttonselector = '[id="td_379"] button'
  popupframe = '[id="whr"]>iframe'
  applybtn = '[id="BtOk"]'
  addtionalinfoinput = 'textarea[name="W$TbWFeststellung"]'
  feedbackbtn = '[name="BtnOpenFeedback"]'
  popHSTbtn = '[name="BtnOpenHst"]'
  okbtninpopup = '[name="BtnOk_PlWithoutPaint"]'
  closedissinfomedia = '[id="infomedia.DISS.close"]'
  additionalInformationTextFieldSelector = 'textarea[id="W_TbWFeststellung"]'
  EnterOptionalInformationBtn = 'input[value="Optionale Angaben erfassen"]'
  modalCircle = 'circle[class="checkmark__circle"]'
  speichernBtn = 'input[value="Speichern"]'
  documentID = 'input[name="K$TbTplNr"]'
  documentDescription = 'input[name="K$TbTplTitel"]'
  werkstattfeststellungDocumentID = 'input[name="W$TbTplNr"]'
  werkstattfeststellungDocumentDescription = 'input[name="W$TbTplTitel"]'
  tabText = '#BeaTabs_div>a'
  lowerHSTTitleField = '[id="W_RepTbTpiTitel"], [id="K_TbTplTitel"]'
  lowerHSTNumberField = '[id="W_RepTbTpiNr"], [id="K_TbTplNr"]'
  randbedingungenTextArea = 'textarea[id="K_TbRandb"]'
  hstButtonSelector2 = '#td_520'
  weitereWorkshopErgebnisse = 'input[id="B_IAddWorkShop"]'
  popupAfterClickingOnWeitereWorkshopErgebnisseButtonIFrame = 'iframe[src^="MWerkstattfeststellung.aspx"]'
  newComplaintBtn = '[id="BtnNeu"][onclick]'
  ListederBeanstandungenBtn = '[id="B_BtnListe"]'
  beanstandungsdatenTableLabels = '#ta_94 tbody tr td[class="RLabel"]'
  beanstandungsdatenTableValues = '#ta_94 tbody tr[class^=Row] td:last-child'
  auftragsdatenTableLabels = '#ta_47 tbody tr td[class="RLabel"], #ta_49 tbody tr td[class="RLabel"]'
  auftragsdatenTableValues = '#ta_47 tbody tr td[class="RLabel"] + td, #ta_49 tbody tr td[class="RLabel"] + td'
  listederBeanstandungenTableRows = '#GridBeaList tr[class^="Row"]'
  newComplaintBtnAfterChanges = '[id="B_BtnNew"]';
  paintComplaintField = '#K_RblLackBeanstandung';
  abbrechennBtn = 'input[value="Abbrechen"]'
  ElsaProAuftragsdatenbtn = '[id="W_BtnElsaAuftrag"]'
  popUpframekocator = '[src^="ElsaProOrderData.aspx?"]'
  okbtn = '[id="BtnOk"]'
  numberOfWorkItem = 'input[id="W_LaborOperation"]'
  freigabeLackanfrageMitKalkulationSelector = 'td[title="Neue Schichtstärke auswählen und hinzufügen"]'
  schichtstärkeSelector = 'input[id="TbThickness"]'
  beschädigtesBauteilSelector = 'input[id="TbDesc"]'
  beschädigtesBauteilÜbernehmenBtnSelector = 'input[value="Übernehmen"]'
  beschädigtesBauteilAbbrechenBtnSelector = 'input[value="Abbrechen"]'
  lackkalkulationZuDieserBeanstandungSelector = 'td[title="Lackkalkulation zu dieser Beanstandung öffnen"]'
  KDNummerInLackkalkulationZurKundencodierungTextFieldSelector = 'input[id="TxtKDNumber"]'
  schadensartInLackkalkulationZurKundencodierungTextFieldSelector = 'input[id="TxtDamageType"]'
  schadensortInLackkalkulationZurKundencodierungTextFieldSelector = 'input[id="TxtDamagePlace"]'
  arbeitspositionInLackkalkulationZurKundencodierung = 'input[name$="txtLabourOperationNumber"]'
  ETNummerInLackkalkulationZurKundencodierung = 'input[name$="txtPartNumber"]'
  ETNummerCheckBoxInLackkalkulationZurKundencodierung = 'input[type="checkbox"][id^="DataGridSparepart_ct"]'
  anzahlInLackkalkulationZurKundencodierung = 'input[name$="txtQuantity"]'
  speichernBtnInLackkalkulationZurKundencodierung = 'input[name="B$BtnApply"]'
  ZEInLackkalkulationZurKundencodierung = 'input.textAlignment[title="Zeiteinheiten"]:last-of-type'
  PlausibilitätsprüfungBtnInLackkalkulationZurKundencodierung = 'input[name="BtnPlausibilityCheck"]'
  ETNummerLöchenBtnInLackkalkulationZurKundencodierung = 'input[id="BtnDeleteSparepart"]'
  verdachtAufWiederholreparaturIframe = 'iframe[src^="Wiederholreparatur"]'
  diagnoseergebnisTextArea = 'textarea[id="R_TbAnmDiagnose"]'
  sendenButton = '#ButtonBar button:text-is("Senden")'
  hintMessage = '#B_LitHintAnfrage'
  editThisComplaintButton = 'input[id="GridBeaList_ctl02_IbEdit"]'
  warningIcon = '#K_PnDoppelteTPIAnwendung'
  systemAnzeigenSelector = 'img[id="search.hidetoc"]'
  systemeVerbergenSelector = '[id="systems.hidelinks"]'
  dissLinkSelector = 'a[id="vaws.sys.diss"]'
  dissMLinkSelector = 'a[id="vaws.sys.diss.monitor"]'
  recordAdditionalPaintComplaintsButton = '#K_IAddPaintWorkShop'
  elsaProAuftragsdatenIframe = '[src^="PaintCalculationOrderData.aspx?"]'
  elsaProAuftragsdatenTab = '#MnuOrderData ul li a:text-is("stringText")'
  elsaProAuftragsdatenETNummerCheckBox = '//table[starts-with(@class,"ListContentOrderData")]//td[text()="ET-Nummer"]/../td//input[@type="checkbox"]'
  elsaProAuftragsdatenUbernehmen = '#BtnUbernehmen'
  lackkalkulationElsaProAuftragsdatenBtn = '#BtnAuftrgsDaten'
  aposTableArbeitsposition = '//table[@id="DataGridLabourOperation"]//span[contains(@id,"OperationNumber")][text()]'
  teileTableETNummer = '//table[@id="DataGridSparepart"]//span[contains(@id,"PartNumber")][text()]'
  attachmentManagementBtn = '#B_IAnhList'
  openPDFViewCopyWithAttachmentsBtn = '#B_ICopyAttachment'
  achtungWiederholreparatur = 'a[id="A_HlWhr"] img';
  valueInKundenbeanstandungTable = '//div[@class="SummaryDiv"]//td[@class="RLabel"][text()="label"]/following-sibling::td';
  allAvailableBAIDs = '//td[contains(@onclick, "goToMultiBeaTab")]//..//td[contains(@class,"Tab")]';
  currentActiveBAID = '//td[contains(@onclick, "goToMultiBeaTab")]//..//td[contains(@class, "ActiveTab")][not(contains(@class, "InActiveTab"))]';
  activeBAID = '//td[contains(@onclick, "goToMultiBeaTab")]//..//td[contains(@class, "ActiveTab")][not(contains(@class, "InActiveTab"))][text()="BAID"]';
  BAIDTab = '//td[contains(@onclick, "goToMultiBeaTab")]//..//td[contains(@class,"Tab")][text()="BAID"]';
  HSTAufrufenNumber = '//*[normalize-space(text()) = "HST aufrufen:"]/following-sibling::td//input[@id="W_TbTplNr"]'
  HSTAufrufenTitle = '//*[normalize-space(text()) = "HST aufrufen:"]/following-sibling::td//input[@id="W_TbTplTitel"]'
  lackKalkulationsStatus = '//span[contains(@id,"LackKalkulationsStatus")]'
  editIconForSpecificOrderNumber = "//table[@id='GridAuftrList']//tr[starts-with(@class,'Row')]/td[text()='order-num']/..//input[contains(@src,'edit')]"
  editIconForSpecificBAID = "//table[@id='GridBeaList']//tr[starts-with(@class,'Row')]/td[text()='BAID']/..//input[contains(@src,'edit')]"
  systemAndUserInformation = "#AuftrCtrl_IbInfo"
  fieldsInSystemAndUserInformation = "//table[@class='ListContent']//tr[starts-with(@class,'row')]/td[text()='field_label']/following-sibling::td"
  dateFieldSelector = 'div[id="A_PnVisible"] tr td > span[id="A_IsoDate"] > input'
  editOrderDataSelector = '//table[@class="OrderData"]//tr[@class="ListHeader"]//td[@class="nowrap align_right"]/input[@id="A_IbEdit"]'
  fieldValueForBAIDInsideOrder = '(//table[@id="GridBeaList"]//tr[starts-with(@class,"Row")]/td[text()="BAID"]/../td)[count(//table[@id="GridBeaList"]//tr[@class="ListHeader"]/td[text()="fieldLabel"]//preceding-sibling::td)+1]'
  eventListIcon = '#B_IEventLog'
  eventTableValue = '((//table[@id="GridEvents"]/tbody/tr[starts-with(@class,"Row")])[rowIndex]/td)[count(//table[@id="GridEvents"]/tbody/tr[@class="ListHeader"]/td[text()="columnHeaderName"]//preceding-sibling::td)+1]'
  eventTableIframe = 'iframe[src^="EventListe.aspx"]'
  headersList = 'table[id="GridBeaList"] > tbody'
  complaintsForOrderTable = '#GridBeaList'


  // click on "Neue Beanstandung" / "New Complaint"button
  // this is used to add Complaint to already creatde order (Old order)
  async clickNeueBeanstandung(page) {
    await page.waitForLoadState("networkidle")
    const newComplaintBtnLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.newComplaintBtn)
    await newComplaintBtnLocator.waitFor({ state: 'visible', timeout: 10000 });
    await newComplaintBtnLocator.click()
    console.log('✅ Clicked on New Complaint/Beanstandung.')
  }

  // click on "Neuen Auftrag Anlegen" button
  // skipIfButtonNotVisible is false by default it's used when there're no complaint saved (after deployments) so this workaorund to avoid test case failure in this case
  async clickNeuenAuftragAnlegen(page, skipIfButtonNotVisible = false) {
    await page.waitForLoadState("networkidle")
    const newOrderBtnLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.newOrderBtn)
    try {
      await newOrderBtnLocator.waitFor({ state: 'visible', timeout: 10000 });
      await newOrderBtnLocator.click()
      console.log('✅ Clicked on New Order/Auftrag.')
    }
    catch (error) {

      if (skipIfButtonNotVisible) {
        // in case we need to skip the button visiblity assertion
        console.log('⚠️ Skip New Order/Auftrag. button clicking')
      }
      else {
        throw error;
      }
    }
  }

  // click on "Bearbeiten" button
  async clickBearbeitenButton(page) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.bearbeitenbtn)
      .click();
    console.log(`✅ clicked "Bearbeiten" button`)
  };

  // Verify that the "Bearbeiten" button is clickable
  async verifyBearbeitenButtonClickable(page) {
    const button = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.bearbeitenbtn);

    // Check if the button is visible
    const isVisible = await button.isVisible();
    expect(isVisible).toBe(true);

    // Check if the button is enabled
    const isEnabled = await button.isEnabled();
    expect(isEnabled).toBe(true);

    console.log(`✅ "Bearbeiten" button is clickable`);
  };

  // click on "HST" button
  async clickHstButton(page) {
    await page.waitForLoadState("load")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.hstButtonSelector)
      .click();
    console.log(`✅ clicked "HST" button`)

  };

  // click on "HST" button
  // when Next Process Button is clicked, the locators for the HST Button change
  // this function is for clicking HST Button after Next Process Button is clicked
  async clickHstButtonSecondState(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.hstButtonSelector2)
      .click();
    console.log(`✅ clicked "HST" button`)

  };

  // verify "Bitte die Situation aus Kundensicht codieren:" text area
  async verifyKundensichtCodierenTextArea(page, text) {
    await page.waitForLoadState("load")
    const textArea = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.kundensichtCodieren)
    const textAreaText = await textArea.inputValue()
    // Assert that the text area contains the expected text
    await expect(textAreaText.trim()).toEqual(text.trim())
  }

  // click "OK" in Popup
  async clickOkInPopup(page, skipIfButtonNotVisible = false) {
    await page.waitForLoadState("networkidle")
    const okInPopUp = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.verdachtAufWiederholreparaturIframe)
      .locator(this.popupOkButton)
    await page.waitForLoadState("load")
    try {
      await okInPopUp.waitFor({ state: "visible", timeout: 10000 });
      await okInPopUp.click()
      await page.waitForLoadState("load")
    }
    catch (error) {

      if (skipIfButtonNotVisible) {
        // in case we need to skip the button visiblity assertion
        console.log('⚠️ Skip Click on Popup')
      }
      else {
        throw error;
      }
    }
  }

  //enter text in Customer Complaint box
  async enterCustomerComplaint(page, text, clear = false) {
    await page.waitForLoadState("load")
    const textAreaLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.ComplaintTextBox)
    if (clear) {
      // Clear the text box
      await textAreaLocator.clear(); // Clears existing text
    }
    await textAreaLocator.fill(text, { timeout: 10000 })
  }

  //verify text in Customer Complaint box
  async verifyCustomerComplaintText(page, expectedText) {
    await page.waitForLoadState("networkidle")
    const textAreaLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.ComplaintTextBox)
    const textAreaValue = await textAreaLocator.inputValue();
    expect(await textAreaValue.trim()).toBe(await expectedText);
  }


  //enter text in "Additional Information"/"Zusatzinformationen zur Werkstattfeststellung:" text field
  async clearAndEnterAdditionalInformation(page, text) {
    // Wait for the page to stabilize
    await page.waitForLoadState("load");
    // Locate the target textarea inside nested iframes
    const textAreaLocator = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.additionalInformationTextFieldSelector);
    // Wait for the textarea to be visible
    await textAreaLocator.waitFor({ state: "visible", timeout: 10000 });
    // Clear the text box
    await textAreaLocator.clear(); // Clears existing text
    // Enter new text
    await textAreaLocator.fill(text); // Fills with the provided text
  }


  // verify verifyAdditionalInformation text lenght NotEqual to expectedLength
  async checkTextareaLengthDoesNotMatch(page, expectedLength) {
    await page.waitForLoadState("networkidle");
    const textAreaLocator = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.additionalInformationTextFieldSelector);
    await textAreaLocator.waitFor({ state: "visible", timeout: 10000 });
    const actualValue = await textAreaLocator.inputValue();
    expect(actualValue.length).not.toBe(expectedLength);
  }

  //enter random number in auftragsnummer box
  //Text in das Feld für die Bestellnummer eingeben
  async enterAuftragsnummer(page) {
    let randomNumber = await common.generateRandomOrderNumber()
    await page.waitForLoadState("networkidle")
    const auftragsnummerTextBoxLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.auftragsnummerTextBox)
    await auftragsnummerTextBoxLocator.waitFor({ state: 'visible', timeout: 10000 });
    await auftragsnummerTextBoxLocator.fill(`${randomNumber}`, { timeout: 10000 })
    console.log(`✅ Typed "${randomNumber}" into the auftragsnummer box`);
    return randomNumber
  }

  //click on next process step button
  async clickonNextprocessStepdBtn(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.nextproceedbtn).click({ force: true })
  }

  //click on Abschliessen/finish button
  async clickonAbschliessenBtn(page) {
    await page.waitForLoadState("load")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.abschliessenBtn).click({ force: true })
    // verify that modal icon is visible
    await this.verifyModalVisibility(page, true)
    // verify that modal icon is invisible
    await this.verifyModalVisibility(page, false)
  }

  //verify text, color & background color of the end of page message box
  async verifyMessageTextAndColor(page, text) {
    await page.waitForLoadState("networkidle")
    const messageLocator = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.messageBelowSelector)
    //verify text 
    await expect(messageLocator).toHaveText(text, { timeout: 10000 });
    //verify text color is Red
    await expect(messageLocator).toHaveCSS("color", "rgb(255, 0, 0)");
    //verify background color is Yellow
    await expect(messageLocator).toHaveCSS("background-color", "rgb(255, 255, 227)");
  }

  //select yes or no radio button in 	Has the car broken down
  //btn option should be ja or nein
  async selectRadioBtninCarBrokenDown(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`[name="K$RblFahrb"][value="${btn}"]`).click();

    // this modification to ensure that popup dissapear and the refresh is completed successfully
    await page.waitForTimeout(2000);
    this.verifySaveButtonIsEnabled(page)
    await page.mouse.move(0, 0);
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator("#popup")
      .waitFor({ state: "hidden", timeout: 10000 });
  }

  // the method below select (Yes, in our workshop)	(Yes, in a different workshop)	(No) radio button in 	"Were you in our workshop because of this complaint?"
  //btn option should be jaeigene , jaandere , nein
  // jaeigene option for Yes, in our workshop
  // jaandere for Yes, in a different workshop
  // nein option for no
  async selectRadioBtnInAlreadyVisitInWorkshop(page, btn) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`[name="K$RblWerkBes"][value="${btn}"]`).click({ force: true })
  }

  // the method below select (Yes) or (No) radio button in 	"Would you like to make a request?"
  // btn option should be 1 , 2.
  // 1 for "yes" and 2 for "no"
  // Bei der folgenden Methode wählen Sie die Optionsschaltfläche (Ja) oder (Nein) bei „Möchten Sie eine Anfrage stellen?“
  // btn Option sollte 1 , 2 sein. 1 für "Ja“ und 2 für "Nein“
  async selectRadioBtnInMakeRequest(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`input[id="K_RblHcAnfrage_${btn}"]`).click()
  }

  // the method below select (Yes) or (No) radio button in 	"Paint Complaint with Release Costing"
  // btn option should be 0 ,1.
  // 0 for "yes" and 1 for "no"
  // Bei der folgenden Methode wählen Sie die Optionsschaltfläche (Ja) oder (Nein) bei "Lackbeanstandung mit Freigabekalkulation"
  // btn Option sollte 0 , 1 sein. 0 für "Ja“ und 1 für "Nein“
  async selectRadioBtnInPaintComplaint(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`input[id="K_RblLackBeanstandung_${btn}"]`).click()
  }
  //verify the status of top DISS page tabs 
  //tab is a string of 4 options --> Beanstandungs-Erfassung/Werkstattfeststellung/Zusammenfassung/Meldepflicht lt HST/Freigabe Lackanfrage mit Kalkulation
  //status is a string of 3 options --> Active/Enabled/Disabled 
  async verifyTabStatus(page, tab, status) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    let tabSelector;
    if (tab === 'Beanstandungs-Erfassung') {
      tabSelector = 'N_BeaTabs_ctl00_hl'
    } else if (tab === 'Werkstattfeststellung') {
      tabSelector = 'N_BeaTabs_ctl01_hl'
    } else if (tab === 'Zusammenfassung') {
      tabSelector = 'N_BeaTabs_ctl06_hl'
    } else if (tab === 'Meldepflicht lt HST') {
      tabSelector = 'N_BeaTabs_ctl04_hl'
    }
    else if (tab === 'Freigabe Lackanfrage mit Kalkulation') {
      tabSelector = 'N_BeaTabs_ctl05_hl'
    }
    else if (tab === 'Technische Reparaturanfrage') {
      tabSelector = 'N_BeaTabs_ctl02_hl'
    }
    const locator = await page.frameLocator(this.mainIframe).frameLocator(this.contentIFrame).frameLocator(this.infomediaIframe)
      .locator(`a[id="${tabSelector}"]`)
    //verify tab have the expected status class
    await expect(locator).toHaveAttribute('class', `${status}Tab`, { timeout: 10000 })
  }

  //verify if the radio buttons in Art der Reparatur are enabled or disabled
  //btn is a string of 6 options --> Reparatur mit Teiletausch/Reparatur ohne Teiletausch/Lackreparatur/Keine Reparatur durchgeführt/Reparatur nach TPI mit Teiletausch/Reparatur nach TPI ohne Teiletausch
  //status is a string of 2 options --> enabled/disabled 
  async verifyRadioButtonArtDerReparaturStatus(page, btn, status) {
    await page.waitForLoadState("networkidle")
    let btnSelector;

    switch (btn) {
      case 'Reparatur mit Teiletausch':
        btnSelector = 'W_RblBeaArt_0'
        break;
      case 'Reparatur ohne Teiletausch':
        btnSelector = 'W_RblBeaArt_1'
        break;
      case 'Lackreparatur':
        btnSelector = 'W_RblBeaArt_2'
        break;
      case 'Keine Reparatur durchgeführt':
        btnSelector = 'W_RblBeaArt_3'
        break;
      case 'Reparatur nach TPI mit Teiletausch':
        btnSelector = 'W_RblBeaArt_4'
        break;
      case 'Reparatur nach TPI ohne Teiletausch':
        btnSelector = 'W_RblBeaArt_5'
        break;
    }
    const locator = await page.frameLocator(this.mainIframe).frameLocator(this.contentIFrame).frameLocator(this.infomediaIframe)
      .locator(`input[id="${btnSelector}"]`)

    //verify tab have the expected status class
    if (status == 'enabled') {
      await expect(locator).not.toHaveAttribute('disabled', 'disabled', { timeout: 10000 });
    } else if (status == 'disabled') {
      await expect(locator).toHaveAttribute('disabled', `disabled`, { timeout: 10000 })
    }
  }


  //enter the mileage in mileage feild
  async enterMileage(page, text, clear = false) {
    await page.waitForLoadState('load')
    const textInputLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.Mileagefeildinputbox)
    if (clear) {
      // Clear the text box
      await textInputLocator.clear(); // Clears existing text
    }
    await textInputLocator.fill(text, { timeout: 10000 })
  }

  // the method below select (ja, Meldepflicht laut HST)	(ja, es liegt einer der Fälle Brand, Airbag oder Unfall vor (Sicherheitsrelevante Anfrage))	(nein) radio button in 	do you want to send query
  //btn option should be ja, Meldepflicht laut HST , ja, es liegt einer der Fälle Brand, Airbag oder Unfall vor (Sicherheitsrelevante Anfrage) , nein
  // R, option for ja, Meldepflicht laut HST
  //S, option for ja, es liegt einer der Fälle Brand, Airbag oder Unfall vor (Sicherheitsrelevante Anfrage)
  // K option for no
  //T option for ja, Technische Reparaturanfrage stellen
  async selectSendingQueryRadioBtn(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`[id="K_RblHcAnfrage_2"][value="${btn}"]`).click({ force: true })
  }


  //click on save btn 
  async clickonSaveBtn(page) {
    await page.waitForLoadState('load')
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.savebtnselector).click({ force: true })
    await page.waitForLoadState('load');
    await page.waitForLoadState('domcontentloaded')
  }

  // select  yes or no option for Has the complaint been rectified?/Ist die Beanstandung behoben?
  async selectComplaintreslovedRadioBtn(page, btn) {
    await page.waitForLoadState('load')
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`[name="W$RblBehoben"][value="${btn}"]`).click({ force: true })
  }

  // select type of repair  Radio btn 
  // enter value "mitteil" for option --> Reparatur mit Teiletausch
  // enter value "ohneteil" for option --> Reparatur ohne Teiletausch
  // enter value "lack" for option --> Lackreparatur
  // enter value "keine" for option --> Keine Reparatur durchgeführt
  // enter value "mitteiltpl " for option --> Reparatur nach TPI mit Teiletausch	
  // enter value "ohneteiltpl" for option --> Reparatur nach TPI ohne Teiletausch

  async selectTypeOfRepairRadioBtn(page, btn) {
    const radioButtonLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(`[name="W$RblBeaArt"][value="${btn}"]`)
    // Wait for the radio button to be visible
    await radioButtonLocator.waitFor({ state: "attached", timeout: 10000 });
    await radioButtonLocator.waitFor({ state: "visible", timeout: 10000 });
    await radioButtonLocator.scrollIntoViewIfNeeded()

    // click on the radio button
    await radioButtonLocator.click({ clickCount: 3, delay: 2 })
    // await radioButtonLocator.evaluate((element) => element.click());
  }

  // enter number in  Nummer des schadensbehebenden Originalteils: in the 5 input boxes
  // the attribute textsArray is an array of strings that are put with the same order in the text boxes
  async enterNumberinNummerDesSchadensbehebenden(page, textsArray) {
    for (let i = 1; i <= 5; i++) {
      await page.frameLocator(this.mainIframe)
        .frameLocator(this.contentIFrame)
        .frameLocator(this.infomediaIframe).locator(`input[id="W_PartNumber_p${i}"]`).fill(textsArray[i - 1])
    }
  }

  //click on end btn 
  async ClickonEndBtn(page) {
    await page.waitForLoadState('networkidle')
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.endbuttonselector).click({ force: true })
  }


  // the method below select (ja, Meldepflicht laut HST)	(ja, es liegt einer der Fälle Brand, Airbag oder Unfall vor (Sicherheitsrelevante Anfrage))	(nein) radio button in 	do you want to send query
  //btn option should be ja, Meldepflicht laut HST , ja, es liegt einer der Fälle Brand, Airbag oder Unfall vor (Sicherheitsrelevante Anfrage) , nein
  // R, option for ja, Meldepflicht laut HST
  //S, option for ja, es liegt einer der Fälle Brand, Airbag oder Unfall vor (Sicherheitsrelevante Anfrage)
  // K option for no
  //T option for ja, Technische Reparaturanfrage stellen
  async selectSendingQueryRadioBtnInPage2(page, btn) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`[name="W$RblHcAnfrage"][value="${btn}"]`).click({ force: true }, { timeout: 10000 })
  }

  //this method is used to select option in "Haben Sie entsprechend der vorliegenden TPI gearbeitet?"/"Have you worked according to the present TPI" popup
  //btn should be one of those below
  //TPIReparaturJ for option 	Ja, TPI übernehmen
  //TPIReparaturN for option Nein, keine Übernahme
  async selectOptionInHaveYouWorkedAccordingToTPIPopup(page, btn) {
    // Locate the radio button
    const radioButtonFramesLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.popupframe)
      .last()
    const radioButtonLocator = await radioButtonFramesLocator.locator(`input[id="TPIReparaturJ"][value="${btn}"]`)
    // Wait for the radio button to be visible
    await radioButtonLocator.waitFor({ state: "attached", timeout: 10000 });
    await radioButtonLocator.waitFor({ state: "visible", timeout: 10000 });
    await radioButtonLocator.scrollIntoViewIfNeeded()
    await radioButtonLocator.click({ clickCount: 3, delay: 2 });
  }

  //this method is used to clicks"Auswahl übernehmen"/"Apply selection" in "Haben Sie entsprechend der vorliegenden TPI gearbeitet?"/"Have you worked according to the present TPI" popup
  async clickApplySelectionInHaveYouWorkedAccordingToTPIPopup(page) {
    // Locate the radio button
    const radioButtonLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.popupframe)
      .last()
      .locator(this.applybtn)

    // Wait for the radio button to be visible
    await radioButtonLocator.waitFor({ state: "attached", timeout: 10000 });
    await radioButtonLocator.waitFor({ state: "visible", timeout: 10000 });
    await radioButtonLocator.scrollIntoViewIfNeeded()
    await radioButtonLocator.click({ clickCount: 3, delay: 2 });
  }


  async fillPartNumberInputs(page, number) {
    await page.waitForLoadState('networkidle')
    // Split the number into segments based on input requirements
    const segments = [
      number.substring(0, 3), // First input
      number.substring(3, 6), // Second input
      number.substring(6, 9), // Third input

    ];

    // Fill each input field within the container
    for (let i = 1; i <= 3; i++) {

      await page.frameLocator(this.mainIframe)
        .frameLocator(this.contentIFrame)
        .frameLocator(this.infomediaIframe).locator(`#W_PartNumber_p${i}`).fill(segments[i - 1]);
    }
  }

  //eneter text in	Additional information on workshop inspection:
  async enterTextinAdditionalinformationonworkshopinspection(page, text) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.addtionalinfoinput).fill(text)
  }

  //click on feedback btn in popup
  async clickonFeedbackoption(page) {
    await page.waitForLoadState('networkidle')
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).frameLocator('iframe[src^="FeedbackAktivierung.aspx"]')
      .locator(this.feedbackbtn).click()
  }
  //click on HST btn in popup
  async clickonHSTButtonInPopup(page) {
    await page.waitForLoadState('networkidle')
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).frameLocator('iframe[src^="FeedbackAktivierung.aspx"]')
      .locator(this.popHSTbtn).click({ force: true })
  }


  //click on feedback btn in popup
  //this method click on popup after click on Abschliessen/finish button
  async clickonOKoption(page) {
    await page.waitForLoadState('load')
    const locator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).frameLocator('iframe[src^="Abschluss.aspx"]')
      .locator(this.okbtninpopup)
    await locator.waitFor({ state: "attached", timeout: 10000 });
    await locator.waitFor({ state: "visible", timeout: 10000 });
    await locator.click()
    await locator.waitFor({ state: "hidden", timeout: 10000 });
  }

  //click on close infomedia 
  async closeDissinfomediabtn(page) {
    await page.waitForLoadState('networkidle')
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infoFrame).locator(this.closedissinfomedia).click({ force: true })
  }

  //verify if the radio buttons in Bezieht sich die Beanstandung auf ein Originalzubehör (VWN: Auf- und Ausbauten)?/ Does the complaint refer to an original
  // accessory (VWN: Bodies and Conversions)?/ are enabled or disabled
  //tab is a string of 2 options --> ja or nein
  //status is a string of 2 options --> enabled/disabled 
  async verifyRadioButtonBeanstandungAufEinOriginalzubehör(page, tab, status) {
    await page.waitForLoadState("networkidle")
    let tabSelector;

    switch (tab) {
      case 'ja':
        tabSelector = 'W_RblOriginalZubehoer_0'
        break;
      case 'nein':
        tabSelector = 'W_RblOriginalZubehoer_1'
        break;

    }
    const locator = await page.frameLocator(this.mainIframe).frameLocator(this.contentIFrame).frameLocator(this.infomediaIframe)
      .locator(`input[id="${tabSelector}"]`)

    //verify tab have the expected status class
    if (status == 'enabled') {
      await expect(locator).not.toHaveAttribute('disabled', 'disabled', { timeout: 10000 });
    } else if (status == 'disabled') {
      await expect(locator).toHaveAttribute('disabled', `disabled`, { timeout: 10000 })
    }
  }

  //verify if the radio buttons in 	Ist die Beanstandung behoben? / Has the complaint been resolved?/ are enabled or disabled
  //tab is a string of 2 options --> ja or nein
  //status is a string of 2 options --> enabled/disabled 
  async verifyRadioButtonBeanstandungBehoben(page, tab, status) {
    await page.waitForLoadState("networkidle")
    let tabSelector;

    switch (tab) {
      case 'ja':
        tabSelector = 'W_RblBehoben_0'
        break;
      case 'nein':
        tabSelector = 'W_RblBehoben_1'
        break;

    }
    const locator = await page.frameLocator(this.mainIframe).frameLocator(this.contentIFrame).frameLocator(this.infomediaIframe)
      .locator(`input[id="${tabSelector}"]`)

    //verify tab have the expected status class
    if (status == 'enabled') {
      await expect(locator).not.toHaveAttribute('disabled', 'disabled', { timeout: 10000 });
    } else if (status == 'disabled') {
      await expect(locator).toHaveAttribute('disabled', `disabled`, { timeout: 10000 })
    }
  }

  //verify if the radio buttons in 	Nummer des schadensbehebenden Originalteils / Nummer der schadensbehebenden Arbeitsposition
  //position are enabled or disabled
  //tab is a string of 2 options --> Nummer des schadensbehebenden Originalteils/Nummer der schadensbehebenden Arbeitsposition
  //status is a string of 2 options --> enabled/disabled 
  async verifyRadioButtonOriginalteilsOrArbeitsposition(page, button, status) {
    await page.waitForLoadState("load")
    let buttonSelector;

    switch (button) {
      case 'Nummer des schadensbehebenden Originalteils':
        buttonSelector = 'W_RblAuftragsDaten_0'
        break;
      case 'Nummer der schadensbehebenden Arbeitsposition':
        buttonSelector = 'W_RblAuftragsDaten_1'
        break;

    }
    const locator = await page.frameLocator(this.mainIframe).frameLocator(this.contentIFrame).frameLocator(this.infomediaIframe)
      .locator(`input[id="${buttonSelector}"]`)

    //verify button have the expected status class
    if (status == 'enabled') {
      await expect(locator).not.toHaveAttribute('disabled', 'disabled', { timeout: 10000 });
    } else if (status == 'disabled') {
      await expect(locator).toBeDisabled()
    }
  }

  // verify additional information field is empty 
  async verifyAdditionalInformationIsEmpty(page) {
    // Wait for the page to stabilize
    await page.waitForLoadState("networkidle");

    // Locate the target textarea inside nested iframes
    const textAreaLocator = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.additionalInformationTextFieldSelector);

    // Wait for the textarea to be visible
    await textAreaLocator.waitFor({ state: "visible", timeout: 10000 });

    // Assert that the textarea is empty
    const value = await textAreaLocator.inputValue();
    expect(value.trim()).toBe("")
  }

  //click on "Optionale Angaben erfassen" / "Enter optional information" button
  async clickEnterOptionalInformationButton(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.EnterOptionalInformationBtn).click({ force: true })
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    this.verifySaveButtonIsEnabled(page)
  }

  // this verify that Save button is enabled
  async verifySaveButtonIsEnabled(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    await expect(page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.savebtnselector)).toBeEnabled({ timeout: 10000 })
    await page.waitForLoadState("load")
  }

  // this verify that Save button is disabled
  async verifySaveButtonIsDisabled(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    await expect(page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.savebtnselector)).toBeDisabled({ timeout: 10000 })
    await page.waitForLoadState("load")
  }

  // verify selection of type of repair  Radio btn 
  // enter value "mitteil" for option --> Reparatur mit Teiletausch
  // enter value "ohneteil" for option --> Reparatur ohne Teiletausch
  // enter value "lack" for option --> Lackreparatur
  // enter value "keine" for option --> Keine Reparatur durchgeführt
  // enter value "mitteiltpl " for option --> Reparatur nach TPI mit Teiletausch	
  // enter value "ohneteiltpl" for option --> Reparatur nach TPI ohne Teiletausch

  async verifySelectionTypeOfRepairRadioBtn(page, btn) {
    await expect(await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`[name="W$RblBeaArt"][value="${btn}"]`)).toBeChecked({ timeout: 10000 })
  }

  //verify that modal (Check mark inside circle that appears after click on End/Abschliessen) visibility
  //visibility is boolean "true" for visible and "false" for invisible
  async verifyModalVisibility(page, visibility) {
    if (visibility) {
      await expect(await page.frameLocator(this.mainIframe)
        .frameLocator(this.contentIFrame)
        .frameLocator(this.infomediaIframe).locator(this.modalCircle)).toBeVisible({ timeout: 20000 })
    }
    else if (!visibility) {
      await expect(await page.frameLocator(this.mainIframe)
        .frameLocator(this.contentIFrame)
        .frameLocator(this.infomediaIframe).locator(this.modalCircle)).not.toBeVisible({ timeout: 20000 })
    }
  }

  // click on Number of damage-rectifying (Nummer des schadensbehebenden) radio btns
  // btn has two values
  // PartNumber for selecting Nummer des schadensbehebenden Originalteils
  // LabourOperations for selecting Nummer der schadensbehebenden Arbeitsposition
  async clickOnNumberOfDamageRectifyingRadionBtn(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`[name="W$RblAuftragsDaten"][value="${btn}"]`).click({ force: true, clickCount: 3, delay: 2 })
    // try clicking with JS as it's flaky sometimes
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`[name="W$RblAuftragsDaten"][value="${btn}"]`).evaluate((element) => element.click());

  }

  //verify text contains (partial), color & background color of the end of page message box
  async verifyMessageContainsTextAndVerifyColor(page, text) {
    await page.waitForLoadState("networkidle")
    const messageLocator = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.messageBelowSelector)
    //verify text 
    await expect(messageLocator).toContainText(text, { timeout: 10000 });
    //verify text color is Red
    await expect(messageLocator).toHaveCSS("color", "rgb(255, 0, 0)");
    //verify background color is Yellow
    await expect(messageLocator).toHaveCSS("background-color", "rgb(255, 255, 227)");
  }

  // click on "Speichern"/ "Save" button
  async clickSpeichernButton(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.speichernBtn)
      .click()
  }

  //Verify document ID on Beanstandungs-Erfassung tab
  //documentID is the expected doc ID
  async verifyDocumentID(page, documentID) {
    await page.waitForLoadState("networkidle")
    let actualDocumentID = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.documentID)
    await expect(actualDocumentID).toHaveAttribute('value', documentID, { timeout: 10000, ignoreCase: true });
  }

  //Verify document Description on Beanstandungs-Erfassung tab
  //documentDescription is the expected doc Description
  async verifyDocumentDescription(page, documentDescription) {
    await page.waitForLoadState("networkidle")
    let actualdocumentDescription = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.documentDescription)
    await expect(actualdocumentDescription).toHaveAttribute('value', documentDescription, { timeout: 10000, ignoreCase: true });
  }

  // the method below verify specific radio button is enabled in "Type of repair"
  // btn option should the radio btn text or part of the text
  async verifyRadioBtnInTypeOfRepairIsEnabled(page, btn) {
    await page.waitForLoadState("networkidle")
    let radioBtn = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('label')
      .filter({ hasText: btn })
    let radioBtnID = await radioBtn.getAttribute('for');

    let radioBtnLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(`input[id="${radioBtnID}"]`)

    await expect(radioBtnLocator).toBeEnabled({ timeout: 10000 });
  }

  //Verify document ID on Werkstattfeststellung tab
  //documentID is the expected doc ID
  async verifyDocumentIDOnWerkstattfeststellungTab(page, documentID) {
    await page.waitForLoadState("networkidle")
    let actualDocumentID = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.werkstattfeststellungDocumentID)
    await expect(actualDocumentID).toHaveAttribute('value', documentID, { timeout: 10000, ignoreCase: true });
  }

  //Verify document Description on Werkstattfeststellung tab
  //documentDescription is the expected doc Description
  async verifyDocumentDescriptionOnWerkstattfeststellungTab(page, documentDescription) {
    await page.waitForLoadState("networkidle")
    let actualdocumentDescription = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.werkstattfeststellungDocumentDescription)
    await expect(actualdocumentDescription).toHaveAttribute('value', documentDescription, { timeout: 10000, ignoreCase: true });
  }

  // the method below verify specific radio button is disabled in "Would you like to make a request?"
  // btn option should the radio btn text or part of the text
  async verifyRadioBtnInMakeRequestIsDisabled(page, btn) {
    await page.waitForLoadState("networkidle")
    let radioBtn = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('td')
      .filter({ hasText: "Möchten Sie eine Anfrage stellen?" })
      .locator('xpath=..')
      .locator('label')
      .filter({ hasText: btn })
      .locator('xpath=..')
      .locator('input')
    await expect(radioBtn).toBeDisabled({ timeout: 10000 });
  }

  // verify "Auftragsnummer" is read only
  async verifyAuftragsnummerIsReadOnly(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('td')
      .filter({ hasText: "Auftragsnummer:" })
      .locator("+ td")
      .filter({ hasText: "-" })
  }

  // verify tab text color is as "expectedColor"
  async verifyTabTextColor(page, tabName, expectedColor) {
    await page.waitForLoadState("networkidle")
    let tabText = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.tabText)
      .filter({ hasText: tabName })
    await expect(tabText).toHaveCSS("color", expectedColor);
  }

  // the method below verify specific radio button is enabled in "Would you like to make a request?"
  // btn option should the radio btn text or part of the text
  async verifyRadioBtnInMakeRequestIsEnabled(page, btn) {
    await page.waitForLoadState("networkidle")
    let radioBtn = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('label')
      .filter({ hasText: btn })
    let radioBtnID = await radioBtn.getAttribute('for');

    let radioBtnLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(`input[id="${radioBtnID}"]`)

    await expect(radioBtnLocator).toBeEnabled({ timeout: 10000 });
  }

  // the method below verify specific radio button is checked in "Would you like to make a request?"
  // btn option should the radio btn text or part of the text
  async verifyRadioBtnInMakeRequestIsChecked(page, btn) {
    await page.waitForLoadState("networkidle")
    let radioBtn = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('label')
      .filter({ hasText: btn })
    let radioBtnID = await radioBtn.getAttribute('for');

    let radioBtnLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(`input[id="${radioBtnID}"]`)
    await expect(radioBtnLocator).toBeChecked({ timeout: 10000 });
  }

  async selectTab(page, tabName) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator("#BeaTabs_div>a")
      .filter({ hasText: tabName })
      .click({ force: true })
  }

  // verify lower HSt field number (first one from left to the right)
  // numberText is the expected number
  async verifyLowerHSTNumberField(page, numberText) {
    await page.waitForLoadState("networkidle");

    const hstField = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.lowerHSTNumberField);

    // Check if the value attribute matches the expected value
    const value = await hstField.getAttribute('value');
    expect(value).toEqual(numberText);
  }

  async verifyLowerHSTNumberFieldIsEmpty(page) {
    await page.waitForLoadState("networkidle");

    const textBox = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('#W_TbTplTitel, [id="K_TbTplTitel"]');

    const value = await textBox.getAttribute('value');
    expect(value === '' || value === null).toBe(true);
  }

  // verify lower HSt field title (second one from left to the right)
  // titleText is the expected text
  async verifyLowerHSTTitleField(page, titleText) {
    await page.waitForLoadState("networkidle");

    const hstField = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.lowerHSTTitleField);

    // Check if the value attribute matches the expected value
    const value = await hstField.getAttribute('value');
    expect(value).toEqual(titleText);
  }

  async verifyLowerHSTTitleFieldIsEmpty(page) {
    await page.waitForLoadState("networkidle");

    const textBox = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.lowerHSTTitleField);

    const value = await textBox.getAttribute('value');
    expect(value === '' || value === null).toBe(true);
  }

  //verify that "Optionale Angaben erfassen" / "Enter optional information" button is invisible
  async verifyEnterOptionalInformationButtonIsInvisible(page) {
    await expect(await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.EnterOptionalInformationBtn)).not.toBeVisible({ timeout: 20000 })
  }

  //this method is used to click on poup up appeas after click on Abschliessen/finish button
  //btn should be one of those below
  //Ok for click on OK button
  //Abbrechen for click on Abbrechen/Cancel button
  async clickButtonInPopupAfterClickOnAbschliessen(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).frameLocator(this.popupframe).first().locator(`[id="ButtonBar"]>tbody>tr>td>input[value="${btn}"]`).click({ force: true })
  }

  // verify "Randbedingungen" text area
  async verifyRandbedingungenTextArea(page, text) {
    await page.waitForLoadState("networkidle")
    const textArea = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.randbedingungenTextArea)
    const textAreaText = await textArea.inputValue()
    // Assert that the text area contains the expected text
    await expect(textAreaText.trim()).toEqual(text.trim())
  }

  // Type order number in the search field
  async typeTextInSearchField(page, searchLabel, searchText) {
    let allFieldsHeaderLabels = []
    await page.waitForLoadState("networkidle")

    const frames = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
    await frames.locator('[class="ListHeader"] td').nth(0).waitFor({ state: 'visible', timeout: 5000 });

    const allFieldsHeaderLabelsLocators = await frames.locator('[class="ListHeader"] td').all()
    const allFieldsQueryLabelsLocators = await frames.locator('[class="ListQuery"] td').all()

    await allFieldsHeaderLabelsLocators[0].waitFor({ state: 'visible', timeout: 5000 });
    await allFieldsQueryLabelsLocators[0].waitFor({ state: 'visible', timeout: 5000 });

    for (let i = 0; i < await allFieldsHeaderLabelsLocators.length; i++) {
      await allFieldsHeaderLabels.push(await allFieldsHeaderLabelsLocators[i].first().textContent())
    }
    const searchInputField = await allFieldsQueryLabelsLocators[allFieldsHeaderLabels.indexOf(searchLabel)].locator("input")
    await searchInputField.fill(searchText, { timeout: 10000 })
    console.log(`✅ Typed "${searchText}" into the "${searchLabel}" search field`);
  }

  //click on list of complaint symbol/Beanstandungen zu Auftrag auflisten (Edit symbol)
  async clickOnListOfComplaints(page) {
    await page.waitForLoadState("networkidle");
    const complaintsButton = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('input[id="GridAuftrList_ctl03_IbBeaList"]');
    await complaintsButton.waitFor({ state: "visible" });
    await complaintsButton.click();
    console.log("✅ Clicked on the list of complaints");
  }

  //click on list of complaint symbol/Beanstandungen zu Auftrag auflisten (Edit symbol) for specific order
  async clickOnListOfComplaintsForOrder(page, orderNumber) {
    await page.waitForLoadState("networkidle");
    const complaintsButton = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.editIconForSpecificOrderNumber.replace("order-num", orderNumber));
    await complaintsButton.waitFor({ state: "visible" });
    await complaintsButton.click();
    await complaintsButton.waitFor({ state: "hidden", timeout: 10000 });
    console.log(`✅ Clicked on the list of complaints for order ${orderNumber}`);
  }

  // Click on the "Search" button
  async clickOnSearchField(page) {
    const searchField = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('input[title="Suchen"]');
    await searchField.waitFor({ state: 'visible', timeout: 5000 });
    await searchField.click();
    console.log(`✅ Clicked on the SearchField`);
  }

  // Verify additional information field is visible or visibility
  //visibility is boolean "true" for visible and "false" for invisible
  async verifyAdditionalInformationFieldVisibility(page, visibility) {
    await page.waitForLoadState("networkidle");
    if (visibility) {
      await expect(await page
        .frameLocator(this.mainIframe)
        .frameLocator(this.contentIFrame)
        .frameLocator(this.infomediaIframe)
        .locator(this.additionalInformationTextFieldSelector)).toBeVisible({ timeout: 20000 })
    }
    else if (!visibility) {
      await expect(await page
        .frameLocator(this.mainIframe)
        .frameLocator(this.contentIFrame)
        .frameLocator(this.infomediaIframe)
        .locator(this.additionalInformationTextFieldSelector)).not.toBeVisible({ timeout: 20000 })
    }
  }
  //enter order number in search for it
  //Auftragsnummer in die Suche eingeben
  async enterOrderNumberAndClickSearch(page, orderNumber) {
    // Type ordernumber in seach field 
    await this.typeTextInSearchField(page, "Auftragsnummer", orderNumber)
    // cleck on search filed
    await this.clickOnSearchField(page)
  }


  // this method is to clicks on "Über diese Schaltfläche können Sie weitere Werkstattfeststellungen...
  //  zur Kundenbeanstandung hinzufügen, die unmittelbar im Zusammenhang mit dieser stehen." button
  async clickOnWeitereWorkshopErgebnisseButton(page) {
    const locator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.weitereWorkshopErgebnisse).click({ force: true })
  }

  // this method is to clicks on "Ja" or "Abbrechen" in the popup that appears after clicking on
  // "Über diese Schaltfläche können Sie weitere Werkstattfeststellungen...
  // zur Kundenbeanstandung hinzufügen, die unmittelbar im Zusammenhang mit dieser stehen." button
  // "ja" or "abbrechen" are the options for the buttons
  async clickOnButtonInKundenbeanstandungErfassenPopup(page, btn) {
    let buttonSelector; // Declare buttonSelector variable

    if (btn === "ja") {
      buttonSelector = 'input[id="BtnYes"]';
    } else if (btn === "abbrechen") {
      buttonSelector = 'input[id="BtnCancel"]';
    } else {
      throw new Error('Invalid button specified: ' + btn);
    }

    const locator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.popupAfterClickingOnWeitereWorkshopErgebnisseButtonIFrame)
      .locator(buttonSelector)
    await locator.waitFor({ state: "attached", timeout: 10000 });
    await locator.waitFor({ state: "visible", timeout: 10000 });
    await locator.click();
    await locator.waitFor({ state: "hidden", timeout: 10000 });
  }

  // this method verifies if the book icon in the HST button is open or closed
  async verifyHSTBookStatus(page, expectedStatus) {

    // Define the expected image source based on the status
    const expectedSrc = (expectedStatus === "open") ? "img/tpl_opened.gif" : "img/tpl_closed.gif";

    // Locate the image element based on the expected source
    const locator = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`img[src='${expectedSrc}']`);

    try {
      // Check if the image element exists
      const count = await locator.count();

      // Assert that the count matches what we expect
      if (count > 0) {
        console.log(`Assertion Passed: The book is ${expectedStatus}.`);
      } else {
        throw new Error(`Assertion Failed: The book is not ${expectedStatus}.`);
      }

    } catch (error) {
      console.error("Error while verifying the book status:", error);
      throw error; // Rethrow the error to fail the test case
    }
  }

  //verify that "Optionale Angaben erfassen" / "Enter optional information" button is visible
  async verifyEnterOptionalInformationButtonIsVisible(page) {
    await expect(await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.EnterOptionalInformationBtn)).toBeVisible({ timeout: 20000 })
  }

  // this method to verify the text in any row in Beanstandungsdaten  when the Zusammenfassung tab is active
  async checkTextsInBeanstandungsdatenTable(page, rowLabels, expectedTexts) {
    const frame = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe);

    const rows = frame.locator('#ta_94 tbody tr');

    for (let i = 0; i < rowLabels.length; i++) {
      const label = rowLabels[i];
      const expectedText = expectedTexts[i].toLowerCase().trim(); // Normalize the expected text

      console.log(`Looking for label: '${label}'`); // Log the expected label

      // Log available text for debugging
      const allTexts = await rows.evaluateAll(elements => elements.map(el => el.innerText));
      console.log(`Available texts in the table: ${JSON.stringify(allTexts)}`);

      // Find the row that contains the desired label
      const labelRow = rows.locator(`td:has-text("${label}")`).first();

      if (await labelRow.count() > 0) {
        await labelRow.waitFor({ state: 'visible', timeout: 5000 });

        const rowHandle = await labelRow.evaluateHandle(cell => cell.parentElement);
        const cells = await rowHandle.$$('td');
        const cellTexts = await Promise.all(cells.map(cell => cell.innerText()));

        const actualText = (cellTexts[1] || '').toLowerCase().trim(); // Normalize the actual text

        // Check if the actual text matches the expected text
        if (!actualText.includes(expectedText)) {
          throw new Error(`Test Case Failed: Expected '${expectedText}' for '${label}', but found '${actualText}'`);
        }
      } else {
        throw new Error(`Test Case Failed: '${label}' not found in the table`);
      }
    }

    console.log("All checks passed successfully.")
  }

  //click on list of comaplaint btn 
  async clickonListederBeanstandungen(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.ListederBeanstandungenBtn)
      .click()

  }

  // delete complaint with specific BA ID
  // BA_ID is the BA ID of the complaint need to be deleted
  async deleteComplaintWithBAID(page, BA_ID) {
    await page.waitForLoadState("networkidle")

    let allRowsBAID = await []
    const frame = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
    const dialogHandler = async dialog => {
      expect(dialog.type()).toContain('confirm')
      await page.waitForTimeout(1000);
      await page.waitForLoadState("networkidle")
      await dialog.accept()
      await page.waitForTimeout(1000);
    }
    // turn on dialog listener
    await page.on('dialog', dialogHandler)
    await expect(await frame.locator(this.listederBeanstandungenTableRows).first()).toBeVisible({ timeout: 20000 })
    let allRowsElements = await frame.locator(this.listederBeanstandungenTableRows).all()

    for (let i = 0; i < allRowsElements.length; i++) {
      await allRowsBAID.push(await allRowsElements[i].locator("td").first().textContent())
    }

    await allRowsElements[await allRowsBAID.indexOf(BA_ID)].locator("td input[name$='Del']").click()
    await expect(await allRowsElements[await allRowsBAID.indexOf(BA_ID)].locator("td input[name$='Del']")).not.toBeVisible({ timeout: 20000 })

    // remove dialog listener
    await page.off('dialog', dialogHandler)
  }

  // get value of attribute from Beanstandungsdaten Table when the Zusammenfassung tab is active
  // attribute is the row attribut label (i.e. BA-ID:, Kann die Kundenbeanstandung nachvollzogen werden?, .... etc.)
  async getValueFromBeanstandungsdatenTable(page, attribute) {
    await page.waitForLoadState("networkidle")
    let allRowsLabels = await []
    let allRowsValues = await []
    const frame = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe);

    const rowsLabelsElements = await frame.locator(this.beanstandungsdatenTableLabels).all()
    const rowsValuesElements = await frame.locator(this.beanstandungsdatenTableValues).all()

    for (let i = 0; i < rowsLabelsElements.length; i++) {
      await allRowsLabels.push(await rowsLabelsElements[i].textContent())
    }

    for (let i = 0; i < rowsValuesElements.length; i++) {
      await allRowsValues.push(await rowsValuesElements[i].textContent())
    }
    return await allRowsValues[allRowsLabels.indexOf(attribute)]
  }

  // verify deleted complaint is deleted successfully with specific BAID
  // BA_ID is the BA ID of the complaint need to be verified 
  async verifyComplaintWithBAIDNotExist(page, BA_ID) {
    await page.waitForLoadState("networkidle")
    let allRowsBAID = await []
    const frame = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe);

    const allRowsElements = await frame.locator(this.listederBeanstandungenTableRows).all()

    for (let i = 0; i < allRowsElements.length; i++) {
      await allRowsBAID.push(await allRowsElements[i].locator("td").first().textContent())
    }
    await expect(allRowsBAID.indexOf(BA_ID)).toEqual(-1);
  }

  // click on "Neuen Auftrag Anlegen" button after making changes
  async clickNeueBeanstandungInsideComplaint(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.newComplaintBtnAfterChanges)
      .click()
    console.log('✅ Clicked on New Complaint.')
  }

  // the method below check	"Paint Complaint with Release Costing" radio btns and field status
  // status should be enabled or disabled
  async verifyPaintComplaintFieldAndRadioBtnsDisabled(page, status) {
    const fieldLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.paintComplaintField)

    const fieldYesLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator('input[id="K_RblLackBeanstandung_0"]')

    const fieldNoLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator('input[id="K_RblLackBeanstandung_1"]')

    //verify tab have the expected status class
    if (status == 'enabled') {
      await expect(fieldLocator).not.toHaveAttribute('disabled', 'disabled', { timeout: 10000 });
      await expect(fieldYesLocator).not.toHaveAttribute('disabled', 'disabled', { timeout: 10000 });
      await expect(fieldNoLocator).not.toHaveAttribute('disabled', 'disabled', { timeout: 10000 });
    } else if (status == 'disabled') {
      await expect(fieldLocator).toHaveAttribute('disabled', `disabled`, { timeout: 10000 })
      await expect(fieldYesLocator).toHaveAttribute('disabled', `disabled`, { timeout: 10000 })
      await expect(fieldNoLocator).toHaveAttribute('disabled', `disabled`, { timeout: 10000 })
    }
  }

  //click on Abbrechen/Cancel button
  async clickonAbbrechennBtn(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.abbrechennBtn).click({ force: true })
  }

  // this method click on VIN link in Suspicion of repeat repair/Verdacht auf Wiederholreparatur window
  async cliclOnVINLinkInInSuspectedRepeatRepair(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.verdachtAufWiederholreparaturIframe)
      .locator('a[id="HlFish"]')
      .click()
  }

  //click on list of ElsaPro Auftragsdaten btn
  async clickonElsaProAuftragsdaten(page) {
    await page.waitForLoadState("load")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.ElsaProAuftragsdatenbtn)
      .click()
  }

  // click on OK on Popup after click on list of ElsaPro Auftragsdaten btn
  async clickonOKbtninElsaProAuftragsdatenPopUp(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).frameLocator(this.popUpframekocator).locator(this.okbtn).click()
  }

  // this method used to Enter Number of work Item / Nummer der schadensbehebenden Arbeitsposition
  // number is the string number number to be written inside field
  async enterNumberOfWorkItem(page, number) {
    // Wait for the page to stabilize (no ongoing network activity)
    await page.waitForLoadState("networkidle");

    // Locate the input field within nested iframes
    const locator = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.numberOfWorkItem); // Target the input field

    // Ensure the input field is visible before interaction
    await locator.waitFor({ state: 'visible' });

    // Fill the input field with the provided text
    await locator.fill(number);
  }

  //click on link showing in the section of HST Vorgangs-Nr. on BeanstandungsdatenTable
  async clickonHSTTransactionLinkInBeanstandungsdatenTable(page) {
    const link = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('tr td:text-is("HST Vorgangs-Nr.:")')
      .locator('xpath=..')
      .locator('a')
    await link.click();
  }

  // Verify that the correct transaction no. is displayed on new page 
  async verifyTextAfterClickOnHSTTransactionLinkInBeanstandungsdatenTable(page, text) {
    const element = page
      .frameLocator(this.contentFsIDIframe)
      .frameLocator(this.infomediaIframe)
      .frameLocator('iframe[name="docContent0"]')
      .locator('div.inst-number');

    // Verify the element contains the expected text
    await expect(element).toHaveText(text);
  }


  //click on "Optionale Angaben löschen" / "Delete optional information" button
  async clickOptionaleAngabenlöschenButton(page) {
    const dialogHandler = async dialog => {
      expect(dialog.type()).toContain('confirm')
      await page.waitForTimeout(1000);
      await page.waitForLoadState("load")
      await dialog.accept()
      await page.waitForTimeout(1000);
    }
    // turn on dialog listener
    await page.on('dialog', dialogHandler)
    await page.waitForLoadState("load")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.EnterOptionaleAngabenlöschenBtn).click({ force: true })
    await page.waitForLoadState("load")

    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    this.verifySaveButtonIsEnabled(page)
    // remove dialog listener
    await page.off('dialog', dialogHandler)
  }
  // click on "Neue Schichtstärke auswählen und hinzufügen" symbol
  async clickFreigabeLackanfrageMitKalkulationSelector(page) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.freigabeLackanfrageMitKalkulationSelector)
      .click()
  }

  // Fill in Schichtstärke
  async fillSchichtstärke(page, number) {
    await page.waitForLoadState("networkidle")
    await page.locator(this.schichtstärkeSelector)
      .fill(number)
  }


  // Fill in Beschädigtes Bauteil
  async fillBeschädigtesBauteil(page, number) {
    await page.waitForLoadState("networkidle")
    await page.locator(this.beschädigtesBauteilSelector)
      .fill(number)
  }

  // Click Übernehmen or Abbrechen in "Neue Schichtstärke auswählen und hinzufügen" popup
  async clickÜbernehmenOrAbbrechenInBeschädigtesBauteilPopUp(page, btn) {
    await page.waitForLoadState("networkidle");
    if (btn == "Übernehmen") {
      await page.locator(this.beschädigtesBauteilÜbernehmenBtnSelector).click()
    }
    else if (btn == "Abbrechen") {
      await page.locator(this.beschädigtesBauteilAbbrechenBtnSelector).click()
    }
  }

  // Click on Lackkalkulation zu dieser Beanstandung öffnen
  // Note: this symbol's icon is calle "Bearbeiten in the UI"
  // BAID is used for specific BAID in case of multible BAID(s) ..
  // (i.e. clicks on "Record additional paint complaints" / "Zusätzliche Lackbeanstandung erfassen" button with clickOnRecordAdditionalPaintComplaintsButton() method)
  async clickOnLackkalkulationZuDieserBeanstandung(page, BAID = "") {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    if (BAID == "") {
      const locator = await page.frameLocator(this.mainIframe)
        .frameLocator(this.contentIFrame)
        .frameLocator(this.infomediaIframe)
        .locator(this.lackkalkulationZuDieserBeanstandungSelector)
      await locator.waitFor({ state: "attached", timeout: 10000 });
      await locator.waitFor({ state: "visible", timeout: 10000 });
      await locator.click({ timeout: 5000 })
    }
    else {
      const locator = await page.frameLocator(this.mainIframe)
        .frameLocator(this.contentIFrame)
        .frameLocator(this.infomediaIframe)
        .locator(`xpath=//*[contains(text(),"(BA-ID: ${BAID})")]/../../..`)
        .locator(this.lackkalkulationZuDieserBeanstandungSelector)
      await locator.waitFor({ state: "attached", timeout: 10000 });
      await locator.waitFor({ state: "visible", timeout: 10000 });
      await locator.click({ timeout: 5000 })
    }
  }


  async fillKDNummer(page, number) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator('#TxtKDNumber')
      .fill(number)
  }

  // Fill in Schadensart
  async fillSchadensart(page, number) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.schadensartInLackkalkulationZurKundencodierungTextFieldSelector)
      .fill(number)
  }

  // Fill in Schadensort
  async fillSchadensort(page, number) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.schadensortInLackkalkulationZurKundencodierungTextFieldSelector)
      .fill(number)
  }

  // Select "Ja" or "Nein" in 'Fremdlackierung enthalten?'
  async selectJaOrNeinInFremdlackierungEnthalten(page, button) {
    let radioButtonSelector;

    switch (button) {
      case 'ja':
        radioButtonSelector = 'input[value="J"]'
        break;
      case 'nein':
        radioButtonSelector = 'input[value="N"]'
        break;
    }

    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(radioButtonSelector)
      .click({ timeout: 5000 })
  }

  // Fill in Arbeitsposition
  async fillArbeitsposition(page, number) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.arbeitspositionInLackkalkulationZurKundencodierung)
      .fill(number)
  }

  // Fill in ET-Nummer
  async fillETNummer(page, number) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.ETNummerInLackkalkulationZurKundencodierung)
      .fill(number)
  }

  // Fill in Anzahl
  async fillAnzahl(page, number) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.anzahlInLackkalkulationZurKundencodierung)
      .last()
      .fill(number)
  }

  // fill in ZE
  async fillZE(page, number) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.ZEInLackkalkulationZurKundencodierung)
      .last()
      .fill(number)
  }

  // Click on Speichern in 'Lackkalkulation zur Kundencodierung' Popup
  async clickSpeichernInLackkalkulationZurKundencodierung(page) {
    const buttonLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .getByRole('button', { name: 'Speichern' })
    await page.waitForLoadState("load")
    await buttonLocator.waitFor({ state: "visible", timeout: 10000 });
    await buttonLocator.click()
    await buttonLocator.waitFor({ state: "hidden", timeout: 10000 });
    await page.waitForLoadState("load")
  }

  // Click on Plausibilitätsprüfung in 'Lackkalkulation zur Kundencodierung' Popup
  async clickPlausibilitätsprüfungInLackkalkulationZurKundencodierung(page) {
    const buttonLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.PlausibilitätsprüfungBtnInLackkalkulationZurKundencodierung)

    await buttonLocator.waitFor({ state: "visible", timeout: 10000 });
    await buttonLocator.click()
    await expect(buttonLocator).toBeEnabled({ timeout: 10000 })
    await buttonLocator.waitFor({ state: "visible", timeout: 10000 });
    await page.waitForLoadState("load")
  }

  // the method checks on the error messages inside the error text box in 'Lackkalkulation zur Kundencodierung' Popup
  async checkErrorTextAndColorInLackkalkulationZurKundencodierung(page, arrayOfTexts) {
    // Static wait for 3 seconds (3000 milliseconds)
    await page.waitForTimeout(4000);
    // Navigate through the iframe structure to reach the target iframe
    const iframe = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe);

    // Use locator to select the error message box within the nested iframe
    const errMsgSpan = iframe.locator('#ErrBar_ErrMsg');

    // Check if the error message span is visible
    if (!(await errMsgSpan.isVisible())) {
      throw new Error("Error message span not found or not visible!");
    }

    // Get the text content of the error message box
    const errMsgText = await errMsgSpan.innerText();

    // Check for presence of each text in the array
    for (const text of arrayOfTexts) {
      if (!errMsgText.includes(text)) {
        throw new Error(`Text not found in error message: "${text}"`);
      }
    }
    //verify text color is Red
    await expect(errMsgSpan).toHaveCSS("color", "rgb(255, 0, 0)");
  }
  // this function checks all the checkboxes for all the ET Nummer entries in 'Lackkalkulation zur Kundencodierung' Popup
  // record number is the record number you want to delete start from 1
  async checkCheckboxeForETNummer(page, recordNum) {
    // Resolve the iframe hierarchy
    const iframe = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe);

    // Locate all checkboxes matching the specified selector
    const checkboxes = await iframe.locator(this.ETNummerCheckBoxInLackkalkulationZurKundencodierung).all();

    if (!(await checkboxes[recordNum - 1].isChecked())) {
      await checkboxes[recordNum - 1].check(); // Check the checkbox
    }
    await expect(checkboxes[recordNum - 1]).toBeChecked({ timeout: 10000 });
  }

  // Click on Gewählte Einträge löschen/Delete selected entries in 'Lackkalkulation zur Kundencodierung' Popup
  async clickLöschenInLackkalkulationZurKundencodierung(page) {
    const buttonLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.ETNummerLöchenBtnInLackkalkulationZurKundencodierung)

    await buttonLocator.waitFor({ state: "visible", timeout: 10000 });
    await buttonLocator.click()
    await expect(buttonLocator).toBeEnabled({ timeout: 10000 })
    await buttonLocator.waitFor({ state: "visible", timeout: 10000 });
    await page.waitForLoadState("load")
  }

  // This method checks the text inside the status tab
  async checkLackkalkulationStatus(page, text, BAID = "") {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    let actualStatusText = ""
    if (BAID == "") {
      const statusTextLocator = await page.frameLocator(this.mainIframe)
        .frameLocator(this.contentIFrame)
        .frameLocator(this.infomediaIframe)
        .locator(this.lackKalkulationsStatus)

      await statusTextLocator.waitFor({ state: "visible", timeout: 10000 });
      actualStatusText = await statusTextLocator.innerText()
      await expect(actualStatusText).toBe(text);
    }
    else {
      const statusTextLocator = await page.frameLocator(this.mainIframe)
        .frameLocator(this.contentIFrame)
        .frameLocator(this.infomediaIframe)
        .locator(`xpath=//*[contains(text(),"(BA-ID: ${BAID})")]/../../..`)
        .locator(this.lackKalkulationsStatus)

      await statusTextLocator.waitFor({ state: "visible", timeout: 10000 });
      actualStatusText = await statusTextLocator.innerText()
      await expect(actualStatusText).toBe(text);
    }
  }

  // Validate newly generated BA-ID
  async verifyGeneratedBaId(page) {
    await page.waitForLoadState("load");
    // Locate the parent element or section where BA-ID is generated
    const parentElement = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('table[class="TabEntry"]');
    // Verify that the the selected BA ID is the newly generated one
    await expect(await parentElement.locator('td[class="ActiveTab"]')).toBeVisible();
    await expect(await parentElement.locator('td[class="RightOutActive"]')).toBeVisible();
  }

  // Verify any field inside for BAID inside order after click on list of complaint symbol
  // BAID is the BAID need to check field value for
  async verifyFieldInComplaintRowInsideOrder(page, BAID, fieldLabel, expectedText) {
    const actualFieldValue = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.fieldValueForBAIDInsideOrder.replace("BAID", BAID).replace("fieldLabel", fieldLabel));
    // Ensure the field contains the expected text
    await expect(actualFieldValue).toHaveText(expectedText, { timeout: 5000 }); // Timeout can be adjusted as needed
    console.log(`Field ${fieldLabel} is verified`);
  }

  // this method click on transaction number link in Suspicion of repeat repair/Verdacht auf Wiederholreparatur window
  // date is the date of the order (Auftragsdatum)
  // transactionNumber is the transaction Number/Vorgangs-Nr.on the window
  async cliclOnTransactionNumberLinkInSuspectedRepeatRepair(page, date, transactionNumber) {
    const transactionNumberLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.verdachtAufWiederholreparaturIframe)
      .locator('#GridWHRList td')
      .filter({ hasText: date })
      .locator(`~ td a[onclick]:text-is('${transactionNumber}')`)
      .first()

    await transactionNumberLocator.waitFor({ state: "attached", timeout: 10000 });
    await transactionNumberLocator.waitFor({ state: "visible", timeout: 10000 });
    await transactionNumberLocator.click({ delay: 2 });
  }

  // get value of attribute from Auftragsdaten Table when the Zusammenfassung 
  // or Auftragsdaten Table while Beanstandungs-Erfassung (First tab after click on "Neuen Auftrag Anlegen" button)tab is active
  // attribute is the row attribut label (i.e. Auftragsnummer, Auftragsdatum, .... etc.)
  async getValueFromAuftragsdatenTable(page, attribute) {
    await page.waitForLoadState("networkidle")
    let allRowsLabels = await []
    let allRowsValues = await []
    const frame = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe);

    const rowsLabelsElements = await frame.locator(this.auftragsdatenTableLabels).all()
    const rowsValuesElements = await frame.locator(this.auftragsdatenTableValues).all()

    for (let i = 0; i < rowsLabelsElements.length; i++) {
      await allRowsLabels.push((await rowsLabelsElements[i].textContent()).trim())
    }

    for (let i = 0; i < rowsValuesElements.length; i++) {
      await allRowsValues.push((await rowsValuesElements[i].textContent()).trim())
    }
    const returnValue = await allRowsValues[allRowsLabels.indexOf(attribute)]
    return returnValue.replace(/\u00A0/g, " ").trim()
  }

  //enter text in Anmerkung zum Diagnoseergebnis:/Diagnostic Result Note: text area
  async enterDiagnoseergebnis(page, text) {
    const diagnoseergebnisTextArea = await page.frameLocator(this.mainIframe)
      .frameLocator('iframe[name="dissProcess"]')
      .frameLocator(this.infomediaIframe)
      .locator(this.diagnoseergebnisTextArea)

    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });

    await diagnoseergebnisTextArea.waitFor({ state: "visible", timeout: 10000 });
    await diagnoseergebnisTextArea.fill(text, { timeout: 10000 })
  }

  // select the tab option
  async selectTabOption(page, tabName) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator('iframe[name="dissProcess"]')
      .frameLocator(this.infomediaIframe)
      .locator("#BeaTabs_div>a")
      .filter({ hasText: tabName })
      .click({ force: true })
  }

  // click on "Bearbeiten" button this is on Meldepflicht lt HST page 
  async clickBearbeitenButtonOnMeldepflichtPage(page) {
    await page.frameLocator(this.mainIframe)
      .frameLocator('iframe[name="dissProcess"]')
      .frameLocator(this.infomediaIframe)
      .locator('#R_IbTWCode')
      .click({ force: true });
    console.log(`✅ clicked "Bearbeiten" button`)
  }


  //click on send/Senden button
  async clickOnSendBtn(page) {
    const SendBtn = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.sendenButton)

    await page.waitForLoadState('load')
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });

    await SendBtn.waitFor({ state: "visible", timeout: 10000 });
    await SendBtn.click()

    // verify that modal icon is visible
    await this.verifyModalVisibility(page, true)
    // verify that modal icon is invisible
    await this.verifyModalVisibility(page, false)
  }

  async verifyMessageAfterClickSendBtn(page, text, color) {
    await page.waitForLoadState("networkidle")
    const messageLocator = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.hintMessage)

    await messageLocator.waitFor({ state: "visible", timeout: 10000 });
    //verify text 
    await expect(messageLocator).toHaveText(text, { timeout: 10000 });
    //verify text color is Red
    await expect(messageLocator).toHaveCSS("color", color);
  }

  // click "Edit this complaint"\"Diese Beanstandung bearbeiten" button in complaints list
  async clickEditThisComplaintButton(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const editThisComplaintButtonLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.editThisComplaintButton)

    await editThisComplaintButtonLocator.waitFor({ state: "attached", timeout: 10000 });
    await editThisComplaintButtonLocator.waitFor({ state: "visible", timeout: 10000 });
    await editThisComplaintButtonLocator.click({ force: true });
  }

  // click "Edit this complaint"\"Diese Beanstandung bearbeiten" button in complaints list
  async clickEditThisComplaintButtonForBAID(page, BAID) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const editThisComplaintButtonLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.editIconForSpecificBAID.replace("BAID", BAID));

    await editThisComplaintButtonLocator.waitFor({ state: "visible" });
    await editThisComplaintButtonLocator.click();
    await editThisComplaintButtonLocator.waitFor({ state: "hidden", timeout: 10000 });
    console.log(`✅ Clicked on the list of complaints for BAID ${BAID}`);
  }

  // verify Warning Icon beside HST (book) Icon
  async verifyWarningIcon(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const warningIconLocator = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.warningIcon);
    await warningIconLocator.waitFor({ state: "attached", timeout: 10000 });
    await warningIconLocator.waitFor({ state: "visible", timeout: 10000 });


    await expect(warningIconLocator).toHaveAttribute(
      'title',
      'Zu dieser Beanstandung ist bereits eine Reparatur zur übernommenen TPI erfolgt.'
    );
  }

  // Click on System Anzeigen Icon
  async clickOnSystemAnzeigen(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infoFrame)
      .locator(this.systemAnzeigenSelector).click({ force: true })
    console.log(`✅ Clicked on the System Anzeigen`);
  }

  // Click on System Verbergen Icon
  async clickOnSystemeVerbergen(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.systemLinksIframe)
      .frameLocator(this.systemInfoIframe)
      .locator(this.systemeVerbergenSelector).click({ force: true })
    console.log(`✅ Clicked on the System Verbergen`);
  }

  // click on DISS/DISS-M
  async clickOnLinkInSystemsLinks(page, link) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    switch (link) {
      case "DISS":
        const dissLinkLocator = await page.frameLocator(this.mainIframe).frameLocator(this.systemLinksIframe).frameLocator(this.systemLinksIDIframe).locator(this.dissLinkSelector)
        await dissLinkLocator.waitFor({ state: "visible", timeout: 10000 });
        await dissLinkLocator.click({ force: true });
        console.log("Clicked on DISS link from System links");
        break;

      case "DISS-M":
        const dissmLinkLocatorawait = page.frameLocator(this.mainIframe).frameLocator(this.systemLinksIframe).frameLocator(this.systemLinksIDIframe).locator(this.dissMLinkSelector)
        await dissmLinkLocatorawait.waitFor({ state: "visible", timeout: 10000 });
        await dissmLinkLocatorawait.click({ force: true });
        console.log("Clicked on DISS-M link from System links");
        break;
    }
  }

  // this method clicks on "Record additional paint complaints"/"Zusätzliche Lackbeanstandung erfassen" button
  async clickOnRecordAdditionalPaintComplaintsButton(page) {
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const recordAdditionalPaintComplaintsBtn = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.recordAdditionalPaintComplaintsButton)
    await recordAdditionalPaintComplaintsBtn.waitFor({ state: "visible", timeout: 10000 });
    await recordAdditionalPaintComplaintsBtn.click();
    // this is because the page is auto refresh after click on the button
    await page.waitForTimeout(1000);
    await this.verifySaveButtonIsEnabled(page)
  }
  // select radio check box from Since when has the complaint occurred? //Seit wann tritt die Beanstandung auf? question 
  // options are 
  // 1 for von Anfang an
  // 1 for seit der letzten Reparatur
  // 3 for seit
  async selectWhenComplaintOccurredRadioBtn(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`input[id="T_RblAuftriBeg_${btn}"]`).click()
  }

  // select radio check box from Has a comparison vehicle been tested? // Wurde ein Vergleichsfahrzeug geprüft? question 
  // options are 
  // 0 for ja, gleiche Symptome
  // 1 for ja, keine Symptome
  // 2 for  nein
  async selectHasVehicleTestedRadioBtn(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`input[id="T_RblVerglFzg_${btn}"]`).click()
  }

  // select radio check box from Is the vehicle currently available for telediagnosis? // Steht das Fahrzeug derzeit zur Telediagnose zur Verfügung? question
  // options are 
  //0 for ja,
  //1 for  nein
  async selectIsVehicleAvailableForTelediagnosisRadioBtn(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`input[id="T_RblTelediagnose_${btn}"]`).click()
  }


  // select radio check box from Have you done the "Guided Troubleshooting"? //   Haben Sie die "Geführte Fehlersuche" durchgeführt? question
  // options are 
  // 0 for ja,
  // 1 for  nein
  async selectGuidedTroubleshootingRadioBtn(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`input[id="T_RblFehlersuche_${btn}"]`).click()
  }

  // select radio check box from Is the emission warning light on? //  Ist die Abgaswarnleuchte an? question
  // options are 
  // 0 for ja,
  // 1 for  nein
  async selectEmissionWarningLightRadioBtn(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`input[id="T_RblWarnleuchte_${btn}"]`).click()
  }

  // select radio check box from Does the complaint relate to an original accessory (VWN: bodies and conversions)? // Bezieht sich die Beanstandung auf ein Originalzubehör (VWN: Auf- und Ausbauten)? question
  // options are 
  // 0 for ja,
  // 1 for  nein
  async selectComplaintRelateToOriginalAccessoryRadioBtn(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`input[id="T_RblOriginalZubehoer_${btn}"]`).click()
  }

  // select radio check box from  Does the vehicle correspond to the series version?  // Entspricht das Fahrzeug dem Serienstand? question
  // options are 
  // 0 for ja,
  // 1 for  nein
  async selectVehicleCorrespondToSeriesStandardRadioBtn(page, btn) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(`input[id="T_RblSerienstand_${btn}"]`).click()
  }

  //eneter text "text" in  What work has the workshop carried out and what do you need support with?  // Welche Arbeiten hat die Werkstatt durchgeführt und wobei benötigen Sie Unterstützung?
  async enterTextInWerkstattDurchgeführt(page, text) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator('textarea[id="T_TbWFeststellung"]').fill(text)
  }

  // click on link given in Anfrage-Art: section 
  async clickOnAnfrageArtLink(page) {
    const link = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator('table[class="ListContent"]>tbody>tr>td>a')
    await link.click();
  }

  // verify Gesendet an:	 text 
  async verifyGesendetAnText(page, expectedText) {
    const locator = page.locator('table[id="H_TableHistorie"]> tbody > tr:nth-child(2) > td:nth-child(3)')
    await expect(locator).toHaveText(expectedText);
  }

  // verify Nachricht text 
  async verifyNachrichtText(page, expectedText) {
    const locator = page.locator('table[id="H_TableHistorie"] > tbody >  tr:nth-child(2)  > td:nth-child(5)');
    await expect(locator).toHaveText(expectedText);
  }

  //eneter text "text" in  Wenn nein, welche Änderungen wurden durchgeführt? /If not, what changes have been made?   
  async enterTextInWennNein(page, text) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator('textarea[id="T_TbAenderung"]').fill(text)
  }

  async clickDiagnoseProtkollIcon(page) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.diagnoseProtokollIcon).click({ timeout: 10000 });
    console.log('Diagnoseprotokoll Icon clicked.');
  }

  //click ElsaPro Auftragsdaten btn inside Lackkalkulation zur Kundencodierung
  async clickonElsaProAuftragsdatenInLackkalkulation(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const lackkalkulationElsaProAuftragsdatenBtnLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.lackkalkulationElsaProAuftragsdatenBtn)
    await lackkalkulationElsaProAuftragsdatenBtnLocator.waitFor({ state: "visible", timeout: 10000 });
    await lackkalkulationElsaProAuftragsdatenBtnLocator.click();
  }
  // click on sub tab inside ElsaPro Auftragsdaten (after clicks on ElsaPro Auftragsdaten and the ElsaPro Auftragsdaten popup opens )
  async clickOnTabInElsaProAuftragsdaten(page, tab) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const elsaProAuftragsdatenTabLocator = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .frameLocator(this.elsaProAuftragsdatenIframe)
      .locator(this.elsaProAuftragsdatenTab.replace("stringText", tab))
    await elsaProAuftragsdatenTabLocator.waitFor({ state: "visible", timeout: 10000 });
    await elsaProAuftragsdatenTabLocator.click();
  }

  // click Checkbox For ET-Nummer - Arbeitsposition/work position inside ElsaPro Auftragsdaten (after clicks on ElsaPro Auftragsdaten and the ElsaPro Auftragsdaten popup opens )
  async clickOnCheckboxForInElsaProAuftragsdaten(page, eTNummer) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const elsaProAuftragsdatenETNummerCheckBoxLocator = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .frameLocator(this.elsaProAuftragsdatenIframe)
      .locator(this.elsaProAuftragsdatenETNummerCheckBox.replace("ET-Nummer", eTNummer))
    await elsaProAuftragsdatenETNummerCheckBoxLocator.waitFor({ state: "visible", timeout: 10000 });
    if (!(await elsaProAuftragsdatenETNummerCheckBoxLocator.isChecked())) {
      await elsaProAuftragsdatenETNummerCheckBoxLocator.check(); // Check the checkbox
    }
    await expect(elsaProAuftragsdatenETNummerCheckBoxLocator).toBeChecked({ timeout: 10000 });
  }

  // click Ubernehmen inside ElsaPro Auftragsdaten (after clicks on ElsaPro Auftragsdaten and the ElsaPro Auftragsdaten popup opens )
  async clickOnUbernehmenInElsaProAuftragsdaten(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const UbernehmenBtnLocator = await page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .frameLocator(this.elsaProAuftragsdatenIframe)
      .locator(this.elsaProAuftragsdatenUbernehmen)
    await UbernehmenBtnLocator.waitFor({ state: "visible", timeout: 10000 });
    await UbernehmenBtnLocator.click();
  }

  // verify Apos Arbeitsposition/work position inside Lackkalkulation zur Kundencodierung
  // expectedAposTableArbeitsposition is array containing expected Arbeitspositions
  async verifyAposArbeitspositionInLackkalkulation(page, expectedAposTableArbeitsposition) {
    let actualAposTableArbeitsposition = []
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const aposTableArbeitspositionLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.aposTableArbeitsposition)
      .all()
    await aposTableArbeitspositionLocator[0].waitFor({ state: "attached", timeout: 10000 });
    await aposTableArbeitspositionLocator[0].waitFor({ state: "visible", timeout: 10000 });

    // get all Apos Arbeitsposition
    for (let i = 0; i < aposTableArbeitspositionLocator.length; i++) {
      await actualAposTableArbeitsposition.push((await aposTableArbeitspositionLocator[i].textContent()).trim())
    }
    await expect(actualAposTableArbeitsposition).toEqual(expectedAposTableArbeitsposition)
  }

  // verify Teile ET-Nummer inside Lackkalkulation zur Kundencodierung
  // expectedTeileTableETNummer is array containing expected Arbeitspositions
  async verifyTeileETNummerInLackkalkulation(page, expectedTeileTableETNummer) {
    let actualTeileTableETNummer = []
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const teileTableETNummerLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.lackkalkulationZurKundencodierungPopUpIframe)
      .locator(this.teileTableETNummer)
      .all()
    await teileTableETNummerLocator[0].waitFor({ state: "attached", timeout: 10000 });
    await teileTableETNummerLocator[0].waitFor({ state: "visible", timeout: 10000 });

    // get all Teile ET-Nummer
    for (let i = 0; i < teileTableETNummerLocator.length; i++) {
      await actualTeileTableETNummer.push((await teileTableETNummerLocator[i].textContent()).trim())
    }
    await expect(actualTeileTableETNummer).toEqual(expectedTeileTableETNummer)
  }

  // click on Opens the attachment management view for this complaint / Öffnet die Ansicht zur Verwaltung von Dateianhängen zu dieser Beanstandung
  async clickOnAttachmentManagement(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const attachmentManagementBtnLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.attachmentManagementBtn)
    await attachmentManagementBtnLocator.waitFor({ state: "visible", timeout: 10000 });
    await attachmentManagementBtnLocator.click()
  }

  //click on "PDF-Ansichtskopie mit Anlagen (Grafik- und PDF-Dateien) zur Beanstandung öffnen"/Open PDF view copy with attachments (graphic and PDF files) for complaint
  async clickOnOpenPDFViewCopyWithAttachments(page) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.openPDFViewCopyWithAttachmentsBtn)
      .click({ modifiers: ['Control'] })
  }

  //check value from Beanstandungsdaten Table
  // label is the field lable inside table
  async verifyValueFromBeanstandungsdatenTable(page, label, expectedValue) {
    const actualValue = await this.getValueFromBeanstandungsdatenTable(page, label);
    console.log(actualValue);
    expect(actualValue).toEqual(expectedValue);
  }

  //check if tab is not visible
  async verifyTabnotvisible(page, tab) {
    await page.waitForLoadState("networkidle")
    let tabText = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.tabText)
      .filter({ hasText: tab });
    await expect(tabText).toBeHidden({ timeout: 9000 });
  }
  //check if tab is  visible
  async verifyTabvisible(page, tab) {
    await page.waitForLoadState("networkidle")
    let tabText = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.tabText)
      .filter({ hasText: tab });
    await expect(tabText).toBeVisible({ timeout: 9000 });
  }

  //check that Achtung: Wiederholreparatur is displayed
  async verifyAchtungWiederholreparaturdisplayed(page) {
    const loc = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe).locator(this.achtungWiederholreparatur);

    await expect(loc).toBeVisible();
    await expect(loc).toHaveAttribute('src', "img/whr.gif");
  }

  // this method returns value for field label from Kundenbeanstandung table after click on next while creating new complaint (Werkstattfeststellung Tab)
  // fieldLabel is the field label you want the value from
  async getValueFromKundenbeanstandungTable(page, fieldLabel) {
    const valueLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.valueInKundenbeanstandungTable.replace("label", fieldLabel))

    await valueLocator.waitFor({ state: "attached", timeout: 10000 });
    await valueLocator.waitFor({ state: "visible", timeout: 10000 });
    await valueLocator.scrollIntoViewIfNeeded()

    return await (await valueLocator.textContent()).trim()
  }

  // this method returns all BAID count in case of multible BAID(s) (i.e. after click on the add workshop button with clickOnWeitereWorkshopErgebnisseButton() method)
  async getAllBAIDsCount(page) {
    const BAIDLocators = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.allAvailableBAIDs)
      .all()

    await BAIDLocators[0].waitFor({ state: "attached", timeout: 10000 });
    await BAIDLocators[0].waitFor({ state: "visible", timeout: 10000 });

    return await BAIDLocators.length
  }

  // this method returns all BAID (list) in case of multible BAID(s) (i.e. after click on the add workshop button with clickOnWeitereWorkshopErgebnisseButton() method)
  async getAllBAIDs(page) {
    let allAvailableBAIDsText = []
    const BAIDLocators = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.allAvailableBAIDs)
      .all()

    await BAIDLocators[0].waitFor({ state: "attached", timeout: 10000 });
    await BAIDLocators[0].waitFor({ state: "visible", timeout: 10000 });
    for (let i = 0; i < BAIDLocators.length; i++) {
      await allAvailableBAIDsText.push(await (await BAIDLocators[i].textContent()).trim())
    }
    return allAvailableBAIDsText
  }

  // this method returns active BAID in case of multible BAID(s) (i.e. after click on the add workshop button with clickOnWeitereWorkshopErgebnisseButton() method)
  async getActiveBAID(page) {
    const activeBAID = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.currentActiveBAID)

    await activeBAID.waitFor({ state: "attached", timeout: 10000 });
    await activeBAID.waitFor({ state: "visible", timeout: 10000 });
    await activeBAID.scrollIntoViewIfNeeded()

    return await (await activeBAID.textContent()).trim()
  }

  // this method verify active BAID in case of multible BAID(s) (i.e. after click on the add workshop button with clickOnWeitereWorkshopErgebnisseButton() method)
  async verifyActiveBAID(page, expectedActiveBAID) {
    const actualActiveBAID = await this.getActiveBAID(page)
    await expect(expectedActiveBAID).toEqual(actualActiveBAID)
  }

  // this method verify count of all available BAID in case of multible BAID(s) ..
  // (i.e. after click on the add workshop button with clickOnWeitereWorkshopErgebnisseButton() method)
  async verifyCountOfBAIDs(page, expectedCount) {
    const actualCount = await this.getAllBAIDsCount(page)
    await expect(expectedCount).toEqual(actualCount)
  }

  // this method switch to BAID from all available BAID in case of multible BAID(s) ..
  // (i.e. after click on the add workshop button with clickOnWeitereWorkshopErgebnisseButton() method)
  async switchToBAID(page, BAID) {
    const requiredBAIDLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.BAIDTab.replace("BAID", BAID))
    const requiredBAIDAfterSelection = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.activeBAID.replace("BAID", BAID))

    await requiredBAIDLocator.waitFor({ state: "attached", timeout: 10000 });
    await requiredBAIDLocator.waitFor({ state: "visible", timeout: 10000 });
    await requiredBAIDLocator.scrollIntoViewIfNeeded()

    await requiredBAIDLocator.click()
    for (let i = 0; i < 20; i++) {
      if (await this.getActiveBAID == BAID) { break }
      page.waitForTimeout(50)
    }
    await requiredBAIDAfterSelection.waitFor({ state: "attached", timeout: 10000 });
    await requiredBAIDAfterSelection.waitFor({ state: "visible", timeout: 10000 });
  }

  // verify "HST aufrufen:" Number Field Is Empty
  async verifyHSTAufrufenNumberFieldIsEmpty(page) {
    await page.waitForLoadState("networkidle");

    const textBox = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.HSTAufrufenNumber);

    const value = await textBox.getAttribute('value');
    expect(value === '' || value === null).toBe(true);
  }

  // verify "HST aufrufen:" Title Field Is Empty
  async verifyHSTAufrufenTitleFieldIsEmpty(page) {
    await page.waitForLoadState("networkidle");

    const textBox = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.HSTAufrufenTitle);

    const value = await textBox.getAttribute('value');
    expect(value === '' || value === null).toBe(true);
  }

  // this method verify BAID tab status in case of multible BAID(s) (i.e. after click on the add workshop button with clickOnWeitereWorkshopErgebnisseButton() method)
  async verifyStatusOfBAIDTab(page, BAID, expectedStatus) {
    const requiredBAIDLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.BAIDTab.replace("BAID", BAID))
    await requiredBAIDLocator.waitFor({ state: "attached", timeout: 10000 });
    await requiredBAIDLocator.waitFor({ state: "visible", timeout: 10000 });
    const actualStatus = await requiredBAIDLocator.getAttribute('class')
    await expect(expectedStatus).toEqual(actualStatus)
  }

  // the method below select (Yes) or (No) radio button in 	"Is the vehicle accident-damaged, or is there any previous damage?"/"Ist das Fahrzeug unfallbeschädigt, bzw. sind Vorschäden vorhanden?" ..
  // In "Freigabe Lackanfrage mit Kalkulation"/"Release of paint request with calculation" Tab
  // btn option should be 1 , 2.
  // 0 for "yes" 
  // 1 for "no"
  async selectRadioBtnInAccidentPreviousDamage(page, btn) {
    const radioBtnLocator = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(`input[id="R_RblDamage_${btn}"]`)

    await radioBtnLocator.waitFor({ state: "attached", timeout: 10000 });
    await radioBtnLocator.waitFor({ state: "visible", timeout: 10000 });
    await radioBtnLocator.click()
  }

  // check value from Auftragsdaten Table
  // label is the field lable inside table
  async verifyValueFromAuftragsdatenTable(page, label, expectedValue) {
    const actualValue = await this.getValueFromAuftragsdatenTable(page, label);
    console.log(actualValue);
    expect(actualValue).toEqual(expectedValue);
  }

  // click on "System- und Benutzerinformationen"/"System & User Information" button (person icon upper right)
  async clickOnSystemAndUserInformationButton(page) {
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.systemAndUserInformation)
      .click();
    console.log(`✅ clicked "SystemAndUserInformation" button`)
  };

  // verify value In System And User Information Page
  // label is the field lable inside page
  async verifyValueInSystemAndUserInformationPage(page, fieldLabel, expectedValue) {
    const valueLocator = await page.locator(this.fieldsInSystemAndUserInformation.replace("field_label", fieldLabel))
    const actualValue = await (await valueLocator.textContent()).trim()
    console.log(actualValue);
    expect(actualValue).toEqual(expectedValue);
  }

  // This method types order date in respective fields and verifies this date
  // date should be in this format yyyy-mm-dd (2025-12-25)
  async typeOrderDate(page, date) {
    await page.waitForLoadState('networkidle');

    const inputFields = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.dateFieldSelector);

    // Clear and type the values into the input fields
    await inputFields.nth(0).fill((date.split("-")[0]));
    await inputFields.nth(1).fill((date.split("-")[1]));
    await inputFields.nth(2).fill((date.split("-")[2]));

    // Verify the values
    const yearValue = await inputFields.nth(0).inputValue();
    const monthValue = await inputFields.nth(1).inputValue();
    const dayValue = await inputFields.nth(2).inputValue();

    // Assertion to check if the values are set correctly
    if (yearValue !== ((date.split("-")[0])) || monthValue !== ((date.split("-")[1])) || dayValue !== ((date.split("-")[2]))) {
      throw new Error('Input values do not match expected values.');
    }
  }

  // click on Edit Order Data / Daten des Auftrags bearbeiten
  async clickEditOrderData(page) {
    const editOrderDataLocator = page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.editOrderDataSelector)

    await editOrderDataLocator.waitFor({ state: "attached", timeout: 10000 });
    await editOrderDataLocator.waitFor({ state: "visible", timeout: 10000 });
    await editOrderDataLocator.click()
    await editOrderDataLocator.waitFor({ state: "hidden", timeout: 10000 });
  }

  //verify the mileage in mileage feild
  async verifyMileage(page, expectedMileage) {
    await page.waitForLoadState('load')
    const actualMileage = ((await this.getValueFromAuftragsdatenTable(page, "Laufleistung:")).toString().split("\n"))[0]
    // Assert that the text area contains the expected text
    await expect(actualMileage.trim()).toEqual(expectedMileage.trim())
  }

  // This method verify order date in respective fields and verifies this date
  // date should be in this format yyyy-mm-dd (2025-12-25)
  async verifyOrderDate(page, expectedDate) {
    await page.waitForLoadState('load');
    const actualDate = await this.getValueFromAuftragsdatenTable(page, "Auftragsdatum:")
    // Assert that the text area contains the expected text
    await expect(actualDate.trim()).toEqual(expectedDate.trim())
  }

  // get any field value inside for BAID inside order after click on list of complaint symbol
  // BAID is the BAID need to check field value for
  async getFieldValueInComplaintRowInsideOrder(page, BAID, fieldLabel) {
    const actualFieldValue = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.fieldValueForBAIDInsideOrder.replace("BAID", BAID).replace("fieldLabel", fieldLabel));
    await actualFieldValue.waitFor({ state: "attached", timeout: 10000 });
    await actualFieldValue.waitFor({ state: "visible", timeout: 10000 });
    const actualFieldValueText = await actualFieldValue.textContent()
    return await actualFieldValueText.trim()
  }

  // click on open event list / Ruft eine Liste mit Prozessinformationen zu dieser Beanstandung auf "(ℹ️) icon"
  async clickOnOpenEventList(page) {
    const eventListIconLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.eventListIcon)
    await eventListIconLocator.waitFor({ state: "attached", timeout: 10000 });
    await eventListIconLocator.waitFor({ state: "visible", timeout: 10000 });
    await eventListIconLocator.click()
  }

  // get value from event list table
  // column is the column header name
  // rowIndex is the row index start from (1) not (0)
  async getValueInEventList(page, column, rowIndex) {
    const eventListValueLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.eventTableIframe)
      .locator(this.eventTableValue.replace("rowIndex", rowIndex).replace("columnHeaderName", column))
    await eventListValueLocator.waitFor({ state: "attached", timeout: 10000 });
    await eventListValueLocator.waitFor({ state: "visible", timeout: 10000 });
    const eventListValueLocatorText = await eventListValueLocator.textContent()
    return await eventListValueLocatorText.trim()
  }


  // verify that the timestamp format is according to DISS timestamp format (2025-03-17 00:50:55)
  async verifyTimeStampFormat(timestamp) {
    let regex = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/;
    return regex.test(timestamp);
  }

  // Verify "Complaints For Order" Table is visible
  async verifyComplaintsForOrderTableIsVisible(page) {
    const tableLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentIFrame)
      .frameLocator(this.infomediaIframe)
      .locator(this.complaintsForOrderTable);
    await tableLocator.waitFor({ state: "attached", timeout: 5000 });
    await tableLocator.waitFor({ state: "visible", timeout: 5000 });
    await expect(await tableLocator).toBeVisible({ timeout: 10000 })
  }

  // Verify text in complain table entry
  // index is the index of the row starts from Zero (0,1,2, .... etc.)
  async verifyComplainEntryText(page, text, index) {
    const infomediaFrame = page.frameLocator(this.mainIframe).frameLocator(this.contentIFrame).frameLocator(this.infomediaIframe);

    await infomediaFrame.locator(this.headersList + ' > tr[class="RowOdd"]').waitFor({ timeout: 10000 }); // 10 seconds timeout
    const content = await infomediaFrame.locator(this.headersList + ' > tr[class^="Row"]').nth(index).innerText(); // Get the inner text

    if (!content.includes(text)) {
      throw new Error(`Text "${text}" not found in the complain entry.`);
    }
  }
}

export const direktInformationssystemService = new direktInformationssystemServicePage();