const { test, expect, chromium } = require('@playwright/test');

class volkswagenFileUploaderPage {
    mediaHubTermsOfUse = '[class="media-hub-uploader-terms-of-use-checkbox"] [id="checkbox"]'
    uploadFileBtn = '.media-hub-uploader-upload-area-container'
    nextUploadBtn = '[data-test-id="media-hub-uploader-start-button"]'
    finalizeUploadBtn = '[data-test-id="media-hub-uploader-finalize-button"]'

    // check Read And Accept MediaHub Terms Of Use CheckBox
    async selectReadAndAcceptMediaHubTermsOfUseCheckBox(page) {
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        const mediaHubTermsOfUseCheckBoxLocator = await page.locator(this.mediaHubTermsOfUse)
        await mediaHubTermsOfUseCheckBoxLocator.waitFor({ state: "visible", timeout: 10000 });
        await mediaHubTermsOfUseCheckBoxLocator.click(); // Check the checkbox
        await expect(mediaHubTermsOfUseCheckBoxLocator.locator("groupui-icon-static")).toHaveAttribute('id', `checked`, { timeout: 10000 })
    }

    // click on Zum Hochladen Dateien bitte hier ablegen oder klicken / To upload files please drop here or click
    async clickOnUploadFile(page) {
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        const uploadFileBtnLocator = await page.locator(this.uploadFileBtn)
        await uploadFileBtnLocator.waitFor({ state: "visible", timeout: 10000 });
        await uploadFileBtnLocator.click()
    }

    // click on Weiter/Next
    async clickNextUpload(page) {
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        const nextUploadBtnLocator = await page.locator(this.nextUploadBtn)
        await nextUploadBtnLocator.waitFor({ state: "visible", timeout: 10000 });
        await nextUploadBtnLocator.click()
    }

    // click on Finalisieren/Finalize
    async clickFinalizeUpload(page) {
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        const finalizeUploadBtnLocator = await page.locator(this.finalizeUploadBtn)
        await finalizeUploadBtnLocator.waitFor({ state: "visible", timeout: 15000 });
        await finalizeUploadBtnLocator.click()
    }
}
export const volkswagenFileUploader = new volkswagenFileUploaderPage();