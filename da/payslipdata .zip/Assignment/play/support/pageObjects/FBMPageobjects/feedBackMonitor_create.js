const { test, expect, chromium } = require('@playwright/test');

class feedBackMonitor_create {
    descriptionslector = '[id="description"]'
    sendbtn = 'button[type="submit"]'
    createdid = 'p > b:nth-child(2)'
    closebtn = '[id="closeButton"]'
    documentpathTextBoxSelector = "#document"


    //enter the description test in error description box 
    async enterErrorDescripition(page, text) {
        await page.locator(this.descriptionslector).fill(text)
    }

    //Click on send Button 
    async clickonSendBtn(page) {
        await page.locator(this.sendbtn).click({ force: true })
    }

    async GettheCreatedID(page) {
        return await page.locator(this.createdid).textContent()
    }
    //click on close btn 
    async clickonCloseButton(page) {
        await page.locator(this.closebtn).click({ force: true })
    }

    // verify the documnet path
    // giventext is string list
    async verifyDocumnetPathTextField(page, givenText) {
        const text = await page.locator(this.documentpathTextBoxSelector).inputValue();
        console.log(`Document Path: ${text}`);
        for (let i = 0; i < givenText.length; i++) {
            expect(text).toContain(givenText[i]);
        }

    }
}

export const FeedBackMonitor_create = new feedBackMonitor_create();