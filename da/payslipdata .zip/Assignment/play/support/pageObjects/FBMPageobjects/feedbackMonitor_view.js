const { test, expect, chromium } = require('@playwright/test');

class feedBackMonitor_view {
    enterfeedbackid = '[class="row-item row-item-right"] input[type="number"]'
    updatebtn = 'button[class="btn--primary button-style"]'
    historybtn = '[class="icon i-attention-2 hand-cursor"]'


    //enter the description test in error description box 
    async enterfeedbackidinputbox(page, text) {
        await page.waitForLoadState('networkidle')
        await page.locator(this.enterfeedbackid).fill(text)
    }
    //click on update btn 
    async clickonUpdatebtn(page) {
        await page.waitForLoadState('networkidle')
        await page.locator(this.updatebtn).click({ force: true })
    }
    //click on history icon
    async clickonHistoryIcon(page) {
        await page.waitForLoadState('networkidle')
        await page.locator(this.historybtn).click({ force: true })
    }

    //

}

export const FeedBackMonitor_view = new feedBackMonitor_view();