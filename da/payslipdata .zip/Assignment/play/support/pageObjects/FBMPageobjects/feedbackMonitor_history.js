const { test, expect, chromium } = require('@playwright/test');

class feedbackMonitor_history {
    errordescriptionbox = '[class="textarea-container"] textarea[class="history-textarea"]'
    documentpathLabelSelector = 'label:text-is("Dokumentenpfad")'

    // Verify the description text in the error description box
    async verifyErrorDescription(page, expectedText) {
        // Wait for the page to be stable before proceeding
        await page.waitForLoadState('networkidle');

        // Locate the specific text area and get its value
        const textAreaValue = await page.locator(this.errordescriptionbox).nth(2).evaluate(el => el.value);

        // Assert that the text area contains the expected text
        if (textAreaValue !== expectedText) {
            throw new Error(`Error: Expected text '${expectedText}', but found '${textAreaValue}'.`);
        }

        // Log success message
        console.log(`Success: Textarea value matches '${expectedText}'.`);
    }

    // Verify the description text in the document path box
    // givenText is string list
    async getDocumentPathTextBox(page, givenText) {
        // Locate the textbox dynamically based on the associated label text
        const text = await page.locator(this.documentpathLabelSelector).locator('xpath=..').locator('textarea').inputValue();
        console.log(`Document Path: ${text}`);
        for (let i = 0; i < givenText.length; i++) {
            expect(text).toContain(givenText[i]);
        }
    }


}

export const FeedBackMonitor_history = new feedbackMonitor_history();

