const { test, expect, chromium } = require('@playwright/test');
const { headers } = require('../elsaPageObjects/headers');
const { spracheÄndern } = require('../elsaPageObjects/SpacheAndern');

class homePage {
    mainIframe = "#mainFs";
    footerIframe = "#footerFs";
    htmlDocument = "document";
    footerTable = "body > table";
    finTextfield = 'input[name="vin"]';
    suchenBtn = 'button[id="vaws.vehsearch.btn.search"]';
    schließenBtn = 'button[id="message.box.button1"]';
    messageBoxText = 'td[colspan="2"]';
    boxText = 'td[class="boxText"]';
    messageBox = "#messageBoxDiv";
    vorgangsNrTextfield = 'input[id="jobDetailsJobId"]';
    fahrzeugIdentNrTextfield = 'input[name="job.vehicle.vin"]';
    speichernButton = 'button[id="vaws.button.save.job"]';
    druckenVorgangsdatenButton = 'button[id="vaws.cstsearch.btn.print"]';
    messageBoxJaButton = 'button[id="message.box.button1"]';
    messageBoxNeinButton = 'button[id="message.box.button2"]';
    systemsTable = 'table[class="systems-table"]';
    symbolleistebar = "table.buttonBarTable";
    statusLeisteBar = "div#SKPBarDiv";
    OKButton = "#btnOk";
    modell = '[name="job.vehicle.salesModel.salesModelDescription"]';
    modelljahrInFahrzeugdaten = 'input[type="text"][maxlength="4"]';
    TMA_field = 'input[type="text"][maxlength="6"]';
    MKB_field = 'input[type="text"][maxlength="5"]';
    GKB_field = 'input[maxlength="3"]';
    laufleistungTextfield = 'input[name="job.vehicle.mileage"]';
    vorgangsDatenTitel = 'legend[title="Vorgangsdaten"]';
    vorgangsDatenTitelInEnglish = 'legend[title="Transaction data"]';
    footerLinkImpressum = 'a[id="vaws.footer.lbl.imprint"]';
    footerLinkDatenschutz = 'a[id="vaws.footer.lbl.dataprotection"]';
    footerLinkNutzung = 'a[id="vaws.footer.lbl.termsofuse"]';
    statusBar = 'div[id="statusBarDiv"]';
    terminvorbereitungButton = 'button[id="vaws.button.conclude.skp1"]';
    vorgangsDatenStatus = 'input[id="transaction.status.id"]';
    systemLinkTable = "table.systems-table";
    sucheBtnInKundenSuche = "#vaws.cstsearch.btn.search-med";
    kundenDatenFieldset = "#fieldsetCustomer";
    updateBtn = '[id="vaws.button.refresh.job"]';
    bearbeitenBtn = '[id="vaws.button.edit.job"]';
    infoIconOfKundenAussage = '[id="customer.statement.info.state"]';
    buttonsBelowSystemLink = "#vawsMainFieldSet > form > table > tbody > tr > td:nth-child(2) > div";
    fahrzeugDatenTable = 'fieldset[id="fieldsetVehicle"]';
    serviceAdvisorDropDownList = 'select[id="elp.jobDetailsJob.input.serviceAdvisor"]';
    serviceAdvisorTextField = 'input[id="elp.jobDetailsJob.input.serviceAdvisor"]';
    AuftragsNrTextfield = 'input[id="dms.order.id"]'
    ÜbertragungderOBFCMcheckboxinVorgangsdaten = '[name="job.obfcmDataTransfer"]'
    ÜbertragungderOBFCMcheckbox = '[id="elp.jobDetailsJob.image.obfcmFlag"]'
    AbbrechenBtn = '[id="vaws.button.cancel.editing"]'
    sendtodmsbtnselector = 'button[id="vaws.button.send.dms"]'
    dissLinkSelector = 'a[id="vaws.sys.diss"]'
    dissMLinkSelector = 'a[id="vaws.sys.diss.monitor"]'
    privacyPolicyNoticeCLass = '[class="MsoNormalTable"]'
    privacyPolicyNoticeOkBtn = '#btnOk'
    privacyPolicyNoticeParagraphs = 'p[style]'
    fahrzeughistorieSelector = 'a[id="vaws.sys.reserve"]'
    vorgangSchliessenButton = 'button[id="vaws.button.close.job"]'
    partsColumnInResultsTable = '//td[contains(@onclick,"showSpareparts")]'
    allPartsInResultsTable = '(//table[@id="ElsaDataGrid_data"]//tr)//td[5]'
    dissmSystemAndUserInformation = "#N_IbInfo"


    // verify ELP homepage 
    async verifyELPHomePage(page) {
        await page.waitForLoadState("networkidle")
        // check if Privacy Policy Notice Appears
        if (await this.checkIfPrivacyPolicyNoticeAppears(page, await page.frameLocator(this.mainIframe).locator(this.fahrzeugDatenTable))) {
            await this.cilckOKInPrivacyPolicyNotice(page)
        }
        await expect(page.frameLocator(this.mainIframe).locator(this.fahrzeugDatenTable)).toBeVisible({ timeout: 60000 });
    }

    // verify DISSM homepage 
    async verifyDISSMHomePage(page) {
        await page.waitForLoadState("load")
        // check if Privacy Policy Notice Appears
        if (await this.checkIfPrivacyPolicyNoticeAppears(page, await page.locator(this.dissmSystemAndUserInformation))) {
            await this.cilckOKInPrivacyPolicyNotice(page)
        }
        await page.locator(this.dissmSystemAndUserInformation).waitFor({ state: "visible", timeout: 60000 });
    }

    // enter vin and search in Fahrzeugsuche  
    async writeFahrzeugsIdentifikationsNummerAndclickSuchenButton(page, VIN) {
        await page.frameLocator(this.mainIframe).locator(this.finTextfield).fill(VIN);
        await page.frameLocator(this.mainIframe).locator(this.suchenBtn).click()
    }

    // verifying the message Box text
    // input is a string
    // text should be the text within the messagebox
    async verifyMessageBoxText(page, text) {
        await page.waitForLoadState("networkidle")
        await expect(page.frameLocator(this.mainIframe).locator(this.boxText)).toContainText(text, { timeout: 30000 })
    }

    // click on "Schließen" Button in message box
    async clickMessageBoxSchließenButton(page) {
        const schließenBtnLocator = await page.frameLocator(this.mainIframe).locator(this.schließenBtn)
        const isVisible = await schließenBtnLocator.isVisible({ timeout: 5000 });
        if (isVisible) {
            schließenBtnLocator.click()
            console.log('Element was clicked.');
        }
    }

    // click on Link In Systems Links
    async clickOnLinkInSystemsLinks(page, link) {
        switch (link) {
            case "DISS":
                await page.frameLocator(this.mainIframe).locator(this.dissLinkSelector).waitFor({ state: "attached", timeout: 10000 });
                await page.frameLocator(this.mainIframe).locator(this.dissLinkSelector).waitFor({ state: "visible", timeout: 10000 });
                await expect(page.frameLocator(this.mainIframe).locator(this.dissLinkSelector)).toBeEnabled();
                await page.frameLocator(this.mainIframe).locator(this.dissLinkSelector).click();
                console.log("Clicked on DISS link from Systems links");
                break;

            case "DISS-M":
                await page.frameLocator(this.mainIframe).locator(this.dissMLinkSelector).waitFor({ state: "attached", timeout: 10000 });
                await page.frameLocator(this.mainIframe).locator(this.dissMLinkSelector).waitFor({ state: "visible", timeout: 10000 });
                await expect(page.frameLocator(this.mainIframe).locator(this.dissMLinkSelector)).toBeEnabled();
                await page.frameLocator(this.mainIframe).locator(this.dissMLinkSelector).click();
                console.log("Clicked on DISS-M link from Systems links");
                break;

            case "Fahrzeughistorie":
                // be aware that this page is taking too much time to load so take this in consideration
                await page.frameLocator(this.mainIframe).locator(this.fahrzeughistorieSelector).waitFor({ state: "attached", timeout: 10000 });
                await page.frameLocator(this.mainIframe).locator(this.fahrzeughistorieSelector).waitFor({ state: "visible", timeout: 10000 });
                await expect(page.frameLocator(this.mainIframe).locator(this.fahrzeughistorieSelector)).toBeEnabled();
                await page.frameLocator(this.mainIframe).locator(this.fahrzeughistorieSelector).click();
                console.log("Clicked on Fahrzeughistorie link from Systems links");
                break;
        }
    }

    // check if the Privacy Policy Notice Appears
    // locatorToCheck is the locator to check in case of policy notice didn't apper
    // retrun true if Privacy Policy Notice Appears
    // return false if homepage element appears
    // it's dynamic so no useless wait is happening
    async checkIfPrivacyPolicyNoticeAppears(page, locatorToCheck, timeout = 60000) {
        const privacyPolicyNoticeLocator = page.frameLocator('iframe').nth(0).locator(this.privacyPolicyNoticeCLass)
        const interval = 100
        const loopCondition = timeout / interval
        for (let i = 0; i < loopCondition; i++) {
            if (await privacyPolicyNoticeLocator.isVisible()) {
                await privacyPolicyNoticeLocator.waitFor({ state: "visible", timeout: 10000 })
                return true;
            }
            else if (await locatorToCheck.isVisible()) {
                return false
            }
            await page.waitForTimeout(interval);
        }
        // return await privacyPolicyNoticeLocator.isVisible();
        return false
    }

    // click 'Ok' in Privacy Policy Notice screen
    async cilckOKInPrivacyPolicyNotice(page) {
        const privacyPolicyNoticeOkBtnLocator = page.locator(this.privacyPolicyNoticeOkBtn)
        const lastLineInPolicyNoticeLocator = page.frameLocator('iframe').locator(this.privacyPolicyNoticeParagraphs).last()
        await lastLineInPolicyNoticeLocator.scrollIntoViewIfNeeded({ timeout: 60000 });
        await privacyPolicyNoticeOkBtnLocator.scrollIntoViewIfNeeded({ timeout: 60000 });
        await privacyPolicyNoticeOkBtnLocator.waitFor({ state: "visible", timeout: 60000 })
        await privacyPolicyNoticeOkBtnLocator.click({ clickCount: 3, delay: 2 })
    }

    // this method clicks on the "Vorgang schliessen" button
    async clickOnVorgangSchliessenButton(page) {
        const vorgangSchliessenButtonLocator = await page.frameLocator(this.mainIframe).locator(this.vorgangSchliessenButton)
        await vorgangSchliessenButtonLocator.waitFor({ state: "attached", timeout: 10000 });
        await vorgangSchliessenButtonLocator.waitFor({ state: "visible", timeout: 10000 });
        await vorgangSchliessenButtonLocator.click()
    }

    // change ELP Interface Language
    async changeELPInterfaceLanguage(page, language) {
        if
            ((((await page.locator(`//div[@id="SettingsSubMenu"]/../a`).textContent()) === "Einstellungen") && (language === "de-DE (German)"))
            ||
            (((await page.locator(`//div[@id="SettingsSubMenu"]/../a`).textContent()) === "Settings") && (language === "en-GB (UKEnglish)"))
        ) {
            await console.log(`🛑 Language is ${language} as needed no need to change it`)
        }
        else {
            await headers.selectHeaderMenu(page, "Einstellungen")
            const [languagePage] = await Promise.all([
                (await page.context()).waitForEvent('page'),
                await headers.selectHeaderMenuItem(page, "Sprache ändern")
            ]);
            // Select the desired language from dropdown
            await spracheÄndern.changeLanguage(languagePage, language)
            await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
            await page.waitForLoadState("load")
            await page.waitForLoadState("domcontentloaded")
        }
    }
    // click on parts/Teile column in results/Ergebnisliste table 
    async clickOnPartsColumnInResultsTable(page) {
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        const partsColumnInResultsTableLocator = await page.frameLocator(this.mainIframe).locator(this.partsColumnInResultsTable)
        await partsColumnInResultsTableLocator.waitFor({ state: "attached", timeout: 10000 });
        await partsColumnInResultsTableLocator.waitFor({ state: "visible", timeout: 10000 });
        await partsColumnInResultsTableLocator.click()
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        await page.waitForLoadState("load")
    }

    // get all parts/Teile column in results/Ergebnisliste table 
    // returns array with all parts/Teile column in results/Ergebnisliste table
    async getPartsColumnInResultsTable(page) {
        let allPartsInResultsTableText = []
        await page.waitForLoadState("load")
        await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
        const allPartsInResultsTableLocator = await page.frameLocator(this.mainIframe).locator(this.allPartsInResultsTable).all()
        await allPartsInResultsTableLocator[0].waitFor({ state: "attached", timeout: 10000 });
        await allPartsInResultsTableLocator[0].waitFor({ state: "visible", timeout: 10000 });
        // get parts/Teile column in results/Ergebnisliste table 
        for (let i = 0; i < allPartsInResultsTableLocator.length; i++) {
            await allPartsInResultsTableText.push((await allPartsInResultsTableLocator[i].textContent()).trim())
        }
        return allPartsInResultsTableText
    }

}

export const homepage = new homePage();