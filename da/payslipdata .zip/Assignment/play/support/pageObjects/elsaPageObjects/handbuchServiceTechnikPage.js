const { test, expect, chromium } = require('@playwright/test');

class handbuchServiceTechnikPage {
  mainIframe = "#mainFs";
  contentFsIframe = 'iframe[id="contentFsID"]';
  displayProcessListIframe = 'iframe[id="displayProcessListID"]';
  infoIframe = ' iframe[id="infoFrID"]';
  infomediaIframe = ' iframe[id="infomediaFrID"]';
  docDetailIframe = ' iframe[id="docDetailID"]';
  infosearchFrIDframe = 'iframe[id="infosearchFrID"]';
  navigationFsframe = 'iframe[id="navigationFsID"]';
  pageTitle = 'span[id="infomedia"]';
  exitButton = 'img[id="infomedia.TPL.close"]';
  documentLink = 'tr>td>.defaultTplDetail'
  HSTNachDISSUbernehmenButton = 'button[id="elp.docDetail.button.submit"]'
  searchDocumentInputBox = 'input[id="searchInput"]';
  searchDocumentButton = 'input[id="searchSubmit"]';
  documentLinkFromSearchResults = '.searchResult>.document>a'
  handbuchLinkTree = 'iframe[id="treeFsId"]';
  handbuchLinkTreeInneriframe = 'iframe[id="treeFrameID"]';
  treeIframe = 'iframe[id="treeFsId"]'
  secondTreeIframe = 'iframe[id="treeFrameID"]'


  //this method verifies the HST page title
  //diese Methode prüft den HST-Seitentitel
  async verifyPageTitle(page, title) {
    await page.waitForLoadState("networkidle")
    await page.waitForLoadState("load")
    const pageTitle = page
      .frameLocator(this.mainIframe)
      .frameLocator(this.contentFsIframe)
      .frameLocator(this.infoIframe)
      .locator(this.pageTitle)

    // Assert that the text area contains the expected text
    await expect(pageTitle).toContainText(title, { timeout: 60000 });
  }

  // click exit button in order to close the Handsbuchservicetechnik page
  async clickExitButton(page) {
    await page.waitForLoadState("networkidle")
    await page.waitForLoadState("load")
    const exitButtonLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentFsIframe)
      .frameLocator(this.infoIframe)
      .locator(this.exitButton);
    await exitButtonLocator.waitFor({ state: 'visible', timeout: 10000 });
    await exitButtonLocator.click();
    await exitButtonLocator.waitFor({ state: 'hidden', timeout: 10000 });
  }

  //this method click & open any document after clicking on HST without searching
  //name is the name or part of the name of the document it should be unique to open the correct one
  async openDocumentByName(page, name) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentFsIframe)
      .frameLocator(this.displayProcessListIframe)
      .locator(this.documentLink)
      .filter({ hasText: name })
      .click({ force: true, clickCount: 3, delay: 2 });
  }

  //this method click on "HST nach DISS übernehmen"/"Copy HST to DISS" (📋) button after open the document
  async clickOnHSTNachDISSUbernehmenButton(page) {
    await page.waitForLoadState("load")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentFsIframe)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.docDetailIframe)
      .locator(this.HSTNachDISSUbernehmenButton)
      .click({ force: true, clickCount: 3, delay: 2 });
  }

  //this method search document by name after clicking on HST
  //name is the name or part of the name of the document it should be unique to open the correct one
  async searchDocumentByName(page, name) {
    await page.waitForLoadState("networkidle")

    await page.frameLocator(this.mainIframe)
      .frameLocator(this.navigationFsframe)
      .frameLocator(this.infosearchFrIDframe)
      .locator(this.searchDocumentInputBox)
      .fill(name)

    await page.waitForLoadState("load")

    await page.frameLocator(this.mainIframe)
      .frameLocator(this.navigationFsframe)
      .frameLocator(this.infosearchFrIDframe)
      .locator(this.searchDocumentButton)
      .click();
  }

  //this method open document after search on document
  //name is the name or part of the name of the document it should be unique to open the correct one
  async openDocumentFromSearchResult(page, name) {
    await page.waitForLoadState("networkidle")
    await page.frameLocator(this.mainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.documentLinkFromSearchResults)
      .filter({ hasText: name })
      .click({ force: true });
  }

  // this method clicks on nodes and links
  // input is an array of strings
  // the array element should be the names of the nodes and links
  async clickNodesAndLinks(page, nameArray) {
    for (let index = 0; index < nameArray.length; index++) {
      await page.waitForLoadState("networkidle")
      await page.frameLocator(this.mainIframe)
        .frameLocator(this.navigationFsframe)
        .frameLocator(this.handbuchLinkTree)
        .frameLocator(this.handbuchLinkTreeInneriframe)
        .locator(`ul[id="folderROOT"]>li a[target="displayProcessList"]:text-is("${nameArray[index]}")`)
        .click({ force: true });
    }
  }


  // this method verifies the open tree nodes according to the array that is passed as an attribute: nodeTexts
  async verifyOpenTreeNodes(page, nodeTexts) {
    await page.waitForLoadState("networkidle")
    // Navigate through the frames
    const frameLocator = page.frameLocator(this.mainIframe)
      .frameLocator(this.navigationFsFrame)
      .frameLocator(this.treeIframe)
      .frameLocator(this.secondTreeIframe);

    for (let nodeText of nodeTexts) {
      const node = frameLocator.locator(`a:has-text("${nodeText}")`);

      const isNodeVisible = await node.isVisible();
      if (!isNodeVisible) {
        return false; // If the node is not found or not visible, return false
      }

      // Get the id attribute and handle potential null/undefined values
      const idAttribute = await node.getAttribute('id');
      if (idAttribute) {
        const imgId = `IMG${idAttribute.replace('class', '')}`; // Extracting IMG id from the link id
        const imgElement = await frameLocator.locator(`#${imgId}`);

        // Check if the image element exists and if its src ends with 'minus.gif'
        if (await imgElement.count() > 0) {
          const src = await imgElement.getAttribute('src');
          if (!src || !src.endsWith('minus.gif')) {
            return false; // Node is not open
          }
        } else {
          return false; // Image element does not exist
        }
      } else {
        // If idAttribute is null or undefined, handle accordingly
        return false; // Node does not have an ID, implying it's not valid
      }
    }
    return true; // All nodes are open
  }

  // this method verifies the text in green color
  async verifyTitleInGreenText(page, expectedTitle) {
    await page.waitForLoadState("networkidle")
    // Navigate into the nested iframes
    const titleLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentFsIframe)
      .frameLocator(this.displayProcessListIframe)
      .locator('tr:first-child td.headerclass');
    await expect(titleLocator).toContainText(expectedTitle)
  }

  // this method verifies the text in yellow or gray color
  async verifyTitleInYellowOrGrayText(page, expectedTitle) {
    await page.waitForLoadState("networkidle");
    // Navigate into the nested iframes
    const rowsLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentFsIframe)
      .frameLocator(this.displayProcessListIframe)
      .locator('tr'); // Select all tr elements

    const rowCount = await rowsLocator.count(); // Get the number of tr elements

    for (let i = 0; i < rowCount; i++) {
      const rowLocator = rowsLocator.nth(i); // Get the current tr element
      const headerLocator = rowLocator.locator('td.headerclass'); // Locate the td with class headerclass

      const headerText = await headerLocator.innerText(); // Get the text content of the header cell

      // Check if the expected title is present in the header text
      if (headerText.includes(expectedTitle)) {
        return; // If found, exit the loop early (and thus the function)
      }
    }

    // If we finish the loop without finding the title, throw an error
    throw new Error(`Expected title "${expectedTitle}" not found in any header.`);
  }

  // this method verifies all the document names in the part under the green title
  async verifyDocumentNames(page, documentNames) {
    // Retrieve all trs from the displayProcessList iframe
    const rows = await page.frameLocator(this.mainIframe)
      .frameLocator(this.contentFsIframe)
      .frameLocator(this.displayProcessListIframe)
      .locator('tr');

    const rowCount = await rows.count(); // Get the total number of rows

    // Loop over each document name to check its existence
    for (const documentName of documentNames) {
      let isFound = false; // Flag to check if a document name is found

      for (let i = 1; i < rowCount; i++) { // Start from index 1 to skip the title row
        const rowText = await rows.nth(i).textContent(); // Get the text content of the current row

        // Check if the row contains the document name
        if (rowText && rowText.includes(documentName)) {
          isFound = true; // Mark as found
          break; // Break inner loop to stop checking further rows for this document name
        }
      }

      // If not found, throw an error to fail the test
      if (!isFound) {
        throw new Error(`Document name not found: ${documentName}`);
      }
    }
  }
}
export const HandbuchServiceTechnikPage = new handbuchServiceTechnikPage()
