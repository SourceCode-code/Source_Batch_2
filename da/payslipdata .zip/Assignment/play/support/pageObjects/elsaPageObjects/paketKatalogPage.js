const { test, expect, chromium } = require('@playwright/test');

class paketKatalogPage {
  mainIframe = "#mainFs";
  contentFsIframe = 'iframe[id="contentFsID"]';
  displayProcessListIframe = 'iframe[id="displayProcessListID"]';
  infoIframe = 'iframe[id="infoFrID"]';
  infomediaIframe = 'iframe[id="infomediaFrID"]';
  packCatMainIframe = 'iframe[id="packCatMainID"]';
  categoryListElements = '#navigation nav ul li';
  expandCollapseHeaderPaketNumber = '#main-content tbody tr td:text-is("paketNumber")';
  paketNumber = '#main-content thead th:text-is("paketNumber")';
  infoPopupTitle = 'div[class^="ui-dialog-titlebar"]:not([style]) span[id]';
  addToCartBtn = 'button[class^="icon cart-gray"]';
  cartBtnInsideInfoErledigtPopup = 'button[class^="primary icon cart"]';
  savebuttonInsideCart = 'button span:text-is("Speichern")';
  overlayUI = '[class="ui-widget-overlay ui-front"]';
  closePaketKatalogFInfomediaIcon = '[id="infomedia.PACKCAT.close"]';
  allPartsDescription = '//div[@class="icon parts" or @class="icon liquid"]/ancestor::tr/td[@class="third"]';
  shoppingCartInAddedPkgConfirmDialog = '//div[contains(@class,"added-pkg-confirm")][contains(@style,"block")]//button/span[text()="Warenkorb"]';

  // this method select category from "Kategorie wählen" list
  async selectCategory(page, category) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const categoryLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.categoryListElements)
      .filter({ hasText: category })

    await categoryLocator.waitFor({ state: "attached", timeout: 10000 });
    await categoryLocator.waitFor({ state: "visible", timeout: 10000 });
    await categoryLocator.click()
    await expect(categoryLocator).toHaveAttribute('class', new RegExp('.*active.*'))
  }

  // expand header paket by paket number
  async expandHeaderPaket(page, paketNumber) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const paketNumberLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.expandCollapseHeaderPaketNumber.replace("paketNumber", paketNumber))
      .locator('xpath=..')

    let currentState = await paketNumberLocator.getAttribute('class');

    if (currentState != "expanded") {
      await paketNumberLocator.waitFor({ state: "attached", timeout: 10000 });
      await paketNumberLocator.waitFor({ state: "visible", timeout: 10000 });
      await paketNumberLocator.click()
      await expect(paketNumberLocator).toHaveAttribute('class', `expanded`)
    }
    else {
      console.log(`Paket ${paketNumber} is already expanded`)
    }
  }

  // click on info icon for paket number
  async clickOnInfoIcon(page, paketNumber) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const infoIconForPaketNumberLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.paketNumber.replace("paketNumber", paketNumber))
      .locator('xpath=..')
      .locator('a[class^="icon info"]')
    await infoIconForPaketNumberLocator.waitFor({ state: "attached", timeout: 10000 });
    await infoIconForPaketNumberLocator.waitFor({ state: "visible", timeout: 10000 });
    await infoIconForPaketNumberLocator.click()
  }

  // this method verifies Info Popup Title
  async verifyInfoPopupTitle(page, title) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const infoPopupTitleLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.infoPopupTitle)
    await infoPopupTitleLocator.waitFor({ state: "attached", timeout: 10000 });
    await infoPopupTitleLocator.waitFor({ state: "visible", timeout: 10000 });
    const infoPopupTitle = await infoPopupTitleLocator.textContent()
    await expect(infoPopupTitle).toEqual(title, { timeout: 10000 })
  }

  // click add to cart inside Info Popup
  async clickAddToCartBtn(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const addToCartBtnLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.addToCartBtn)
    await addToCartBtnLocator.waitFor({ state: "attached", timeout: 10000 });
    await addToCartBtnLocator.waitFor({ state: "visible", timeout: 10000 });
    await addToCartBtnLocator.click()
  }

  // click on cart icon inside Info Popup
  async clickOnCartInsideInfoErledigtPopup(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const cartBtnInsideInfoErledigtPopupLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.cartBtnInsideInfoErledigtPopup)
    await cartBtnInsideInfoErledigtPopupLocator.waitFor({ state: "attached", timeout: 10000 });
    await cartBtnInsideInfoErledigtPopupLocator.waitFor({ state: "visible", timeout: 10000 });
    await cartBtnInsideInfoErledigtPopupLocator.click()
  }

  // click on Save button inside cart
  async clickOnSaveBtnInsideCart(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const savebuttonInsideCartLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.savebuttonInsideCart)
    await savebuttonInsideCartLocator.waitFor({ state: "attached", timeout: 10000 });
    await savebuttonInsideCartLocator.waitFor({ state: "visible", timeout: 10000 });
    await savebuttonInsideCartLocator.click()
  }

  // wait for overlay UI icon to disappear
  async waitForOverlayToDisappear(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const overlayUILocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.overlayUI)
    await overlayUILocator.waitFor({ state: "hidden", timeout: 10000 });
  }

  //click on close paket katalog infomedia 
  async closePaketKatalogFInfomedia(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const closePaketKatalogFInfomediaLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infoIframe)
      .locator(this.closePaketKatalogFInfomediaIcon)
    await closePaketKatalogFInfomediaLocator.waitFor({ state: "attached", timeout: 10000 });
    await closePaketKatalogFInfomediaLocator.waitFor({ state: "visible", timeout: 10000 });
    await closePaketKatalogFInfomediaLocator.click()
  }

  // get all parts description after click on info tool
  // returns array with all parts description in info pop up
  async getAllPartsDescription(page) {
    let allPartsDescriptionText = []
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const allPartsDescriptionLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.allPartsDescription).all()

    await allPartsDescriptionLocator[0].waitFor({ state: "attached", timeout: 10000 });
    await allPartsDescriptionLocator[0].waitFor({ state: "visible", timeout: 10000 });

    // get all parts description
    for (let i = 0; i < allPartsDescriptionLocator.length; i++) {
      await allPartsDescriptionText.push((await allPartsDescriptionLocator[i].textContent()).trim())
    }

    return allPartsDescriptionText
  }

  // click on Paket übernehmen/Apply Package after expand paket
  // paketNumber is the corresponding paketNumber
  async clickOnApplyPackage(page, paketNumber) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const applyPackageLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.paketNumber.replace("paketNumber", paketNumber))
      .locator('xpath=..')
      .locator('a[class^="icon cart-grey"]')
    await applyPackageLocator.waitFor({ state: "attached", timeout: 10000 });
    await applyPackageLocator.waitFor({ state: "visible", timeout: 10000 });
    await applyPackageLocator.click()
  }

  // click on Warenkorb/shopping cart in Info - erledigt/Info - done after click on Paket übernehmen/Apply Package
  async clickOnShoppingCartInsideInfoDone(page) {
    await page.waitForLoadState("load")
    await page.waitForFunction(() => document.readyState === 'complete', { timeout: 10000 });
    const applyPackageLocator = await page.frameLocator(this.mainIframe)
      .frameLocator(this.packCatMainIframe)
      .frameLocator(this.infomediaIframe)
      .locator(this.shoppingCartInAddedPkgConfirmDialog)
    await applyPackageLocator.waitFor({ state: "attached", timeout: 10000 });
    await applyPackageLocator.waitFor({ state: "visible", timeout: 10000 });
    await applyPackageLocator.click()

  }
}
export const PaketKatalogPage = new paketKatalogPage()
