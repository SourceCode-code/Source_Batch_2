const { test, expect, chromium } = require('@playwright/test');

class teschnischeProduktinformationPage {

  contentFsIDIframe = 'iframe[id="contentFsID"]'
  infomediaIframe = 'iframe[id="infomediaFrID"]'
  docContentIframe = 'iframe[id="docContent0ID"]'
  infoFrame = 'iframe[id="infoFrID"]'

  

  //this method verifies the Teschnische Produktinformation  Page title
  async verifyTeschnischeProduktinformationPageTitle(page, title) {
    await page.waitForLoadState('load');
    const titleArea = await page
      .frameLocator(this.contentFsIDIframe)
      .frameLocator(this.infomediaIframe)
      .frameLocator(this.docContentIframe)
      .locator('.inst-type')
    await titleArea.waitFor({ state: "attached", timeout: 10000 });
    await titleArea.waitFor({ state: "visible", timeout: 10000 });
    // Assert that the text area contains the expected text
    await expect(titleArea).toHaveText(title, { timeout: 50000 });
  }


}
export const teschnischeProduktinformation = new teschnischeProduktinformationPage();