const { test, expect, chromium } = require('@playwright/test');

class Headers {
  navigationBar = ".nav";
  settings = ":nth-child(5) > .parentmenu";
  changeLang = 'a[id="preferencestable_language"]';
  vehicleIdentificationBtn = 'button[id="infomedia.button.vehicle.identification"]';
  reparaturLeitFadenButton = 'button[id="infomedia.button.RM"]';
  schadensnummernkatalogBtn = 'button[id="infomedia.button.DN"]';
  logoutBtn = 'button[id="toolbar.button.logout"]';
  vorgangAnlegenBtn = 'button[id="toolbar.button.service.key"'
  infobarTitle = 'span[id="infomedia"]';
  mainIframe = 'iframe[id="mainFs"]';
  searchOfMenuitem = ":nth-child(2) > .parentmenu";
  searchRefMediaOfMenuItem = "#searchtable_search";
  searchVehicleIdentNrOfMenuItem = "#searchtable_vehicle";
  karosserieInstandsetzungBtn = '[title="Karosserie-Instandsetzung [ALT+2]"]';
  vorgangAusDMSAuftragBtn = '[title="Vorgang anlegen / suchen mit ServiceKey Daten"]';
  feedbackInNavbar = "Feedback";
  printIcon = '[id="PrinterActiveDIV"]';
  druckenMenuItem = "#Printmenu";
  druckenButton = 'img[id="img.toolbar.button.print.content"]';
  druckenPopup = 'embed[type="application/x-google-chrome-pdf"]';
  feedbackMonitor = 'a[id = "feedbacktable_view"]'
  infomittelSucheBtn = '[id="toolbar.button.advanced.search"]';
  hilfeInNavbar = "Hilfe";
  aufUndUmbautenButton = 'button[id="infomedia.button.3PWI"]';
  werkstattInfoDropdown = ":nth-child(3) > .parentmenu";
  wartungstabellenBtn = 'button[id="infomedia.button.MT"]';
  arbeitspositionenLink = 'a[id="elp.toolbarVAWS.link.infomediaMenuItem_2"]';
  handbuchServiceTechnLink = 'a[id="elp.toolbarVAWS.link.infomediaMenuItem_1"]';
  stromlaufPläneLink = 'a[id="elp.toolbarVAWS.link.infomediaMenuItem_8"]'
  arbeitspositionenBtn = 'button[id="infomedia.button.LO"]';
  instandhaltungButton = 'button[id="infomedia.button.MM"]';
  paketKatalogBtn = 'button[id="infomedia.button.PACKCAT"]';
  stromlaufpläneBtn = 'button[id="infomedia.button.WD"]';
  weltkugelBtn = 'button[id="infomedia.button.INFOWWW"]';
  handbuchServiceTechnikBtn = 'button[id="infomedia.button.TPL"]';
  abgasuntersuchungBtn = 'button[id="infomedia.button.ET"]';
  workshopInfoSubmenu = 'div[id="WorkShopInfoSubMenu"]';
  bordbuchOnlineBtn = 'button[id="infomedia.button.BA"]';
  technicalAssistanceBtn = 'img[id="infomedia.TA.image.on"]'
  druckenMenuItem = "#Printmenu";
  druckenButton = 'img[id="img.toolbar.button.print.content"]';
  druckenPopup = 'embed[type="application/x-google-chrome-pdf"]';
  searchForTransactionOption = '#searchtable_searchjob'
  kunde_FzgSuchenBtn = "button[id='toolbar.button.new.job']"
  headerMenus = "ul.nav.clearfix > li > a.parentmenu"
  headerMenusItems = ".menuitems"

  async clickBtnOnHeader(page, Btn) {
    await page.waitForLoadState("networkidle")
    switch (Btn) {
      case "FahrzeugidentifikationBtn":
        await page.locator(this.vehicleIdentificationBtn).waitFor({ state: "attached", timeout: 10000 });
        await page.locator(this.vehicleIdentificationBtn).waitFor({ state: "visible", timeout: 10000 });
        await expect(page.locator(this.vehicleIdentificationBtn)).toBeEnabled();
        await page.locator(this.vehicleIdentificationBtn).click();
        console.log("Clicked Button Fahrzeugidentifikation");
        break;

      case "KarosserieInstandsetzungBtn":
        await expect(page.locator(this.karosserieInstandsetzungBtn)).toBeEnabled();
        await page.locator(this.karosserieInstandsetzungBtn).click();
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        console.log("Clicked Button Karosserie Instandsetzung");
        break;

      case "Wartungstabellen":
        await expect(page.locator(this.wartungstabellenBtn)).toBeEnabled();
        await page.locator(this.wartungstabellenBtn).click({ force: true });
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        console.log("Clicked Button Wartungstabellen");
        break;

      case "Reparaturleitfaden":
        await expect(page.locator(this.reparaturLeitFadenButton)).toBeEnabled();
        await page.locator(this.reparaturLeitFadenButton).click();
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        console.log("Clicked Button Reparaturleitfaden");
        break;

      case "Instandhaltung genau genommen":
        await expect(page.locator(this.instandhaltungButton)).toBeEnabled();
        await page.locator(this.instandhaltungButton).click();
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        console.log("Clicked Button Instandhaltung genau genommen");
        break;

      case "PaketkatalogBtn":
        await page.locator(this.paketKatalogBtn).waitFor({ state: "attached", timeout: 10000 });
        await page.locator(this.paketKatalogBtn).waitFor({ state: "visible", timeout: 10000 });
        await expect(page.locator(this.paketKatalogBtn)).toBeEnabled();
        await page.locator(this.paketKatalogBtn).click();
        console.log("Clicked Button Paketkatalog");
        break;

      case "ArbeitspositionenBtn":
        await expect(page.locator(this.arbeitspositionenBtn)).toBeEnabled();
        await page.locator(this.arbeitspositionenBtn).click();
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        console.log("Clicked Button Arbeitspositionen");
        break;

      case "StromlaufpläneBtn":
        await expect(page.locator(this.stromlaufpläneBtn)).toBeEnabled();
        await page.locator(this.stromlaufpläneBtn).click();
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        console.log("Clicked Button Stromlaufpläne");
        break;

      case "HandbuchSeriveTechnikBtn":
        await expect(page.locator(this.handbuchServiceTechnikBtn)).toBeEnabled();
        await page.locator(this.handbuchServiceTechnikBtn).click();
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        console.log("Clicked Button Handbuch Service Technik");
        break;

      case "AbgasuntersuchungBtn":
        await expect(page.locator(this.abgasuntersuchungBtn)).toBeEnabled();
        await page.locator(this.abgasuntersuchungBtn).click();
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        console.log("Clicked Button Abgasuntersuchung");
        break;

      case "SchadensnummernkatalogBtn":
        await expect(page.locator(this.schadensnummernkatalogBtn)).toBeEnabled();
        await page.locator(this.schadensnummernkatalogBtn).click();
        await page.goto(`${process.env.baseURL}${process.env.appUrl}/elsaweb/ctr/elsaFs`);
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        break;

      case "Infomittel Suche":
        await expect(page.locator(this.infomittelSucheBtn)).toBeEnabled();
        await page.locator(this.infomittelSucheBtn).click();
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        break;

      case "Bordbuch Online":
        await expect(page.locator(this.bordbuchOnlineBtn)).toBeEnabled();
        await page.locator(this.bordbuchOnlineBtn).click();
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        break;

      case "Technical Assistance":
        await page.locator(this.technicalAssistanceBtn).click();
        console.log("Clicked Button Technical Assistance");
        break;

      case "DruckenBtn":
        await expect(page.locator(this.druckenMenuItem)).toBeVisible();
        await page.locator(this.druckenMenuItem).click();
        console.log("Clicked Button Drucken");
        break;

      case "aufUndUmbautenBtn":
        await expect(page.locator(this.aufUndUmbautenButton)).toBeEnabled();
        await page.locator(this.aufUndUmbautenButton).click();
        await expect(page.frameLocator(this.mainIframe)).toBeVisible({ timeout: 5000 });
        console.log("Clicked Button Auf und Umbauten");
        break;

      case "Vorgang suchen":
        await expect(page.locator('button[id="toolbar.button.job.search"]')).toBeEnabled();
        await page.locator('button[id="toolbar.button.job.search"]').click({ force: true });
        await page.goto(`https://grp-prelive.cpn.vwg/${process.env.appUrl}/elsaweb/ctr/showJobSearch`);
        break;
      case "Kunde / Fzg suchen":
        await page.locator(this.kunde_FzgSuchenBtn).waitFor({ state: "attached", timeout: 10000 });
        await page.locator(this.kunde_FzgSuchenBtn).waitFor({ state: "visible", timeout: 10000 });
        await expect(page.locator(this.kunde_FzgSuchenBtn)).toBeEnabled();
        await page.locator(this.kunde_FzgSuchenBtn).click({ force: true });
        console.log("Clicked Button Kunde / Fzg suchen");
        break;

      default:
        throw new Error(`Button ${Btn} not defined in switch case.`);
    }
  }

  // this method logs out of the application
  async clickOnLogOutBtn(page) {
    await page.locator(this.logoutBtn).click();
    await expect(page.locator("div.logo")).toBeVisible();
    console.log("Clicked on log out button in header");
  }

  // this method select header option
  async selectHeaderMenu(page, header) {
    let headerMenuID = ""
    switch (header) {
      case 'Settings':
      case 'Einstellungen':
        headerMenuID = 'SettingsSubMenu'
        break;
    }
    // Find and click the correct header dynamically
    const headerLocator = await page.locator(`//div[@id="${headerMenuID}"]/../a`);
    await headerLocator.waitFor({ state: "attached", timeout: 10000 });
    await headerLocator.waitFor({ state: "visible", timeout: 10000 });
    if (await headerLocator.count() > 0) {
      await headerLocator.nth(0).click(); // Click the first matching header
    } else {
      console.error(`Header "${header}" not found.`);
    }
  }

  async selectHeaderMenuItem(page, menuItem) {
    let headerMenusItemsID = ""
    switch (menuItem) {
      case 'Sprache ändern':
        headerMenusItemsID = 'preferencestable_language'
        break;
    }
    const headerMenusItemLocator = await page.locator(`${this.headerMenusItems}#${headerMenusItemsID}`);
    await headerMenusItemLocator.waitFor({ state: "attached", timeout: 10000 });
    await headerMenusItemLocator.waitFor({ state: "visible", timeout: 10000 });
    if (await headerMenusItemLocator.count() > 0) {
      await headerMenusItemLocator.nth(0).click(); // Click the first matching header
    } else {
      console.error(`Header "${menuItem}" not found.`);
    }
  }



}
export const headers = new Headers();