class SpracheÄndern {

    mainIframe = "#mainFs";
    htmlDocument = "document";
    languageOuterTable = ".languageOuterTableTD";
    oberflächenSpracheDropdown = 'select[id="elp.languages.input.selGuiLang"]';
    languageMenuOkButton = 'input[name="OK Button"]';
    infomittelSpracheDropdown = 'select[name="selInfomittelLang"]';
    infomittelSpracheUpBtn = '[title ="Selection upwards"]';
    LanguageOkBtn = '#btnOk';
    LanguageCancelBtn = '#btnCancel';
    messageBoxNeinButton = 'button[id="message.box.button2"]';
    popupmessage = '#msgBody > tbody > tr > td.boxText';
    verfügbareInfomittel = 'select[id="elp.languages.input.selModule"]';
    messageboxText = 'td[class="boxText"]';
    messageboxNeinButton = 'button[id="message.box.button2"]'

    async changeLanguage(page, language) {
        await page.locator(this.oberflächenSpracheDropdown).waitFor({ state: "attached", timeout: 10000 });
        await page.locator(this.oberflächenSpracheDropdown).waitFor({ state: "visible", timeout: 10000 });
        await page.waitForTimeout(2000)
        await page.locator(this.oberflächenSpracheDropdown).selectOption(language);
        await page.locator(this.LanguageOkBtn).click();
    }


}
export const spracheÄndern = new SpracheÄndern();