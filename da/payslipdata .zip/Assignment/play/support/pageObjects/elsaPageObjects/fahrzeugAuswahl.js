const { test, expect, chromium } = require('@playwright/test');

class FahrzeugAuswahl {
  mainIframe = "#mainFs";
  htmlDocument = "document";
  finTextfield = 'input[name="vin"]';
  sendButton = 'input[id="elfi.button.vin"]';
  okButton = 'input[value="OK"]';
  fahrzeugIdentifikationBtn = '[alt="Vehicle identification"]';
  infoIframe = 'iframe[id="infoFrID"]';
  contentIframe = 'iframe[id="contentFsID"]';
  infomediaIframe = 'iframe[id="infomediaFrID"]';
  infoSearchTitle = 'span[id="_prtinfomedia"]';
  markeField = 'input[name="makeCode"]';
  verkaufstypField = 'input[name="salesModelCode"]';
  modelljahrField = 'input[name="modelYear"]';
  motorField = 'input[name="engineCode"]';
  getriebeField = 'input[name="transmissionCode"]';
  fahrzeugDatenTitel = 'legend[title="Fahrzeugdaten"]';
  modell = '[name="job.vehicle.salesModel.salesModelDescription"]';
  TMA_field = 'input[type="text"][maxlength="6"]';
  MKB_field = 'input[type="text"][maxlength="5"]';
  GKB_field = 'input[maxlength="3"]';
  jaAndNeinBtn = ".boxButton";
  messageBoxOkButton = 'button[id="message.box.button1"]';
  farbeCodeField = 'input[name="colorCode"]';
  lieferDatumField = 'input[name="deliveryDate"]';
  liefernderHändlerField = 'input[name="deliveryDealerCode"]';
  herstellungsDatumField = 'input[name="productionDate"]';
  auftragsHändlerField = 'input[name="orderingDate"]';
  leasingCodeField = 'input[name="leasingCode"]';
  zurücksetzenBtn = 'input[value="Zurücksetzen"]';
  abbrechenBtn = 'input[value="Abbrechen"]';
  achsantriebField = 'input[name="finalDriveCode"]';
  errorTextfield = '#elfi-spacing > tbody > tr:nth-child(2) > td > div';
  asteriskMarke = "span#mkeStarctrl";
  asteriskModelljahr = "span#myStarctrl";
  asteriskVerkaufstyp = "span#salesStarctrl";
  asteriskMotor = 'span[id="engineStarctrl"]';
  asteriskGetriebe = 'span[id="transmissionStarctrl"]';
  boxText = 'td[class="boxText"]';
  messageBox = 'div[id="messageBoxDiv"]';
  genericPageTitle = 'span[id="infomedia"]';

  // page.frameLocator(this.mainIframe).locator(this.fahrzeugDatenTable))

  // this method writes in FIN textfield and clicks send button
  // input is a string
  async writeFinAndClickSendButton(page, FIN) {
    await this.writeFINTextfield(page, FIN);
    await this.clickSendButton(page);
  }

  // this method writes into the "VIN" textfield
  async writeFINTextfield(page, FIN) {
    await page.waitForTimeout(2000)
    await page.frameLocator(this.mainIframe).locator(this.finTextfield).fill(FIN);
    await expect(page.frameLocator(this.mainIframe).locator(this.finTextfield)).toHaveValue(FIN)
    console.log("Have written the VIN in 'Fahrzeugauswahl'");
  }

  // this method clicks on the "Send" button
  async clickSendButton(page) {
    await page.frameLocator(this.mainIframe).locator(this.sendButton).click();
    console.log("Clicked on 'Fahrzeugauswahl' send Button");
  }

  // This method clicks on the Ok button on a messagebox
  async clickMessageBoxOkButton(page) {
    // Locate the message box OK button
    const messageBoxOkButton = await page.frameLocator(this.mainIframe).locator(this.messageBoxOkButton);
    try {
      // Check if the button exists
      await messageBoxOkButton.waitFor({ state: "attached", timeout: 10000 });
      await messageBoxOkButton.waitFor({ state: "visible", timeout: 10000 });
      await messageBoxOkButton.click(); // Click the OK button
      console.log("Clicked Ok Button on messagebox");
    }
    catch (error) {
      // console.error("Message box OK button not found", error);
      console.error("Message box OK button not found");
    }

    // if (await messageBoxOkButton.count() > 0) {
    //   await messageBoxOkButton.click(); // Click the OK button
    //   console.log("Clicked Ok Button on messagebox");
    // } else {
    //   console.error("Message box OK button not found.");
    //   throw new Error("Message box OK button does not exist.");
    // }
  }

  // this method clicks on the "Ok" button
  async clickOKButton(page) {
    await page.frameLocator(this.mainIframe).locator(this.okButton).click()
  }

}

export const fahrzeugAuswahl = new FahrzeugAuswahl();