const { test, expect, chromium } = require('@playwright/test');

class fahrzeugHistorie {

  fishfsIframe = 'iframe[name="fishfs"]'
  pageTitle = 'h1[class="page-title page-header text-overflow ng-scope"]'
  nextButton = '.next'
  activePage = '.pagination li[class="active"] a[data-dt-idx]'
  vinHistoryTableRows = 'tbody tr[ng-repeat="repair in filteredVehicleHistory"]'
  vinHistoryTableUpperRows = 'tbody tr[ng-repeat="repair in filteredVehicleHistory"] [ng-click="toggleRow(repair)"]'
  infoArrowExpanded = 'div[class^="glyphicon glyphicon-chevron-down"]'
  infoArrowCollapsed = 'div[class^="glyphicon glyphicon-chevron-right"]'
  bottonRowLabels = '[class="border_bottom"] td[class^="naming-col"]'
  bottonRowValues = '[class="border_bottom"] td[class="ng-binding"]'


  //this method verifies the Vehicale History  page title
  //this is used when you click on VIN inside diss in the popup that appears after click on Übernehmen button in Bearbeiten popup
  async verifyVINHistoryPageTitle(page, title) {
    await page.waitForLoadState('domcontentloaded');
    const pageTitle = await page
      .locator(this.pageTitle)

    // Assert that the text area contains the expected text
    await expect(pageTitle).toContainText(title, { timeout: 60000 });
  }


  //this method verifies the Vehicale History  page title
  //this is used when you click on Fahrzeughistorie from Systems Links
  async verifyVINHistoryPageTitleFromSystemsLinks(page, title) {
    await page.waitForLoadState('domcontentloaded');
    const pageTitle = await page
      .frameLocator(this.fishfsIframe).locator(this.pageTitle)
    await pageTitle.waitFor({ state: "attached", timeout: 10000 });
    await pageTitle.waitFor({ state: "visible", timeout: 10000 });
    // Assert that the text area contains the expected text
    await expect(pageTitle).toContainText(title, { timeout: 60000 });
  }

  //Search for Beanstandung for exact BA ID
  //if the BA ID not avaialble in the current page then click next and try again
  //BA_ID string represent BA-ID for the complaint
  async goToPageContainBeanstandungForBAID(page, BA_ID) {
    let activePageNumber = 0

    // check that page is loaded successfully
    await this.waitForVINHistoryPageToLoad(page)
    // wait for 1 second
    await page.waitForTimeout(1000);
    while (!await this.isBAIDBeanstandungVisible(page, BA_ID)) {
      // check that page is loaded successfully
      await this.waitForVINHistoryPageToLoad(page)

      // get active page number 
      activePageNumber = await page.frameLocator(this.fishfsIframe)
        .locator(this.activePage).textContent()

      // click on next button
      this.clickOnNextButton(page)

      // wait for 1 second
      await page.waitForTimeout(1000);

      // check that the new page is activated 
      await page.frameLocator(this.fishfsIframe).locator(this.activePage + `:text-is("${parseInt(activePageNumber.trim()) + 1}")`)
        .waitFor({ state: "visible", timeout: 10000 });
    }
  }

  //Click on next button to go to the next page
  async clickOnNextButton(page) {
    // click on next button
    await page.frameLocator(this.fishfsIframe).locator(this.nextButton)
      .waitFor({ state: "visible", timeout: 10000 });
    await page.frameLocator(this.fishfsIframe).locator(this.nextButton)
      .click()
  }

  //Expand Beanstandung Details ForBAID
  //BA_ID string represent BA-ID for the complaint
  async isBAIDBeanstandungVisible(page, BA_ID) {
    return (await page.frameLocator(this.fishfsIframe)
      .locator(this.vinHistoryTableRows)
      // .filter({ hasText: `BA-ID:${BA_ID}` })).isVisible()
      .filter({ hasText: new RegExp(`BA-ID:${BA_ID}|BA ID:${BA_ID}`) })).isVisible()
  }

  //Expand Beanstandung Details ForBAID
  //BA_ID string represent BA-ID for the complaint
  async expandBeanstandungDetailsForBAID(page, BA_ID) {
    await this.waitForVINHistoryPageToLoad(page)
    const baIDRow = await page.frameLocator(this.fishfsIframe)
      .locator(this.vinHistoryTableRows)
      .filter({ hasText: new RegExp(`BA-ID:${BA_ID}|BA ID:${BA_ID}`) })
    await baIDRow.waitFor({ state: "visible", timeout: 10000 });
    await baIDRow.locator(this.infoArrowCollapsed).waitFor({ state: "visible", timeout: 10000 });
    await baIDRow.locator(this.infoArrowCollapsed).click()
    await baIDRow.locator(this.infoArrowExpanded).waitFor({ state: "visible", timeout: 20000 });

  }

  async waitForVINHistoryPageToLoad(page) {
    await page.waitForLoadState("load")
    await page.frameLocator(this.fishfsIframe).locator(this.vinHistoryTableRows).first().waitFor({ state: "attached", timeout: 300000 });
    await page.frameLocator(this.fishfsIframe).locator(this.vinHistoryTableRows).first().waitFor({ state: "visible", timeout: 300000 });
  }


  //this method verify the Historie table values
  //BA_ID is string represent the BA ID needed to check values for
  //expectedLabelsAndValues is key value object, refer to 128117 test case as a usage referance
  async verifyHistorieTableValuesForBAID(page, BA_ID, expectedLabelsAndValues, upperRoweSplitDelimiter = " ") {
    let actualLabelsAndValues = {}
    await this.waitForVINHistoryPageToLoad(page)

    // get upper row labels and values
    const upperRowLabelsValues = ((await page.frameLocator(this.fishfsIframe)
      .locator(this.vinHistoryTableUpperRows)
      .filter({ hasText: new RegExp(`BA-ID:${BA_ID}|BA ID:${BA_ID}`) })
      .textContent())
      .replace(/(\r\n|\n|\r){2,}/g, '\n')
      .replace(/\s{2,}/g, ' ')
      .split(upperRoweSplitDelimiter))
      .filter(Boolean)
      .slice(1)
    // get all botton row labels
    const lowerRowLabelsLocators = await page.frameLocator(this.fishfsIframe)
      .locator(this.vinHistoryTableRows)
      .filter({ hasText: new RegExp(`BA-ID:${BA_ID}|BA ID:${BA_ID}`) })
      .locator(this.bottonRowLabels)
      .all()

    // get all botton row values
    const lowerRowValuessLocators = await page.frameLocator(this.fishfsIframe)
      .locator(this.vinHistoryTableRows)
      .filter({ hasText: new RegExp(`BA-ID:${BA_ID}|BA ID:${BA_ID}`) })
      .locator(this.bottonRowValues)
      .all()

    // assert that the values shoule be equal in count to labels
    await expect(lowerRowLabelsLocators.length).toEqual(lowerRowValuessLocators.length)

    // filling actualLabelsAndValues object with upper row labels and values to assert the values below
    for (let i = 0; i < upperRowLabelsValues.length; i++) {
      actualLabelsAndValues[`${upperRowLabelsValues[i].split(":")[0]}`] = await upperRowLabelsValues[i].split(":")[1]
    }

    // filling actualLabelsAndValues object with botton row labels to assert the values below
    for (let i = 0; i < lowerRowLabelsLocators.length; i++) {
      actualLabelsAndValues[`${await lowerRowLabelsLocators[i].textContent()}`] = `${await lowerRowValuessLocators[i].textContent()}`
    }

    await console.log(actualLabelsAndValues)


    // assert that the values shoule be less or equal in count
    await expect(Object.keys(expectedLabelsAndValues).length).toBeLessThanOrEqual(Object.keys(actualLabelsAndValues).length)

    // verifying the values between expected and actual objects 
    for (const [key, value] of Object.entries(expectedLabelsAndValues)) {
      await expect((expectedLabelsAndValues[key]).trim()).toEqual((actualLabelsAndValues[key]).trim())
      console.log(`Actual:: ${key}:${actualLabelsAndValues[key]} ✅`)
      console.log(`Expected:: ${key}:${actualLabelsAndValues[key]} ✅`)
    }
  }



}
export const FahrzeugHistorie = new fahrzeugHistorie();