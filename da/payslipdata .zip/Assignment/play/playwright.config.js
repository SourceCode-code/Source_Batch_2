const { defineConfig } = require('@playwright/test');
const otplib = require('otplib'); // Install via `npm install otplib --save-dev`
const fs = require('fs');
const path = require('path');
const pdf = require('pdf-parse'); // Install via `npm install pdf-parse --save-dev`

// Utility function to read a PDF
const readPdf = (pathToPdf) => {
    return new Promise((resolve) => {
        const pdfPath = path.resolve(pathToPdf);
        let dataBuffer = fs.readFileSync(pdfPath);
        pdf(dataBuffer).then(({ text }) => {
            resolve(text);
        });
    });
};

// Exporting Playwright config
module.exports = defineConfig({
    testDir: 'tests',
    reporter: [['html', { outputFile: 'test-report.html' }]],
    timeout: 100000, // Global timeout for tests (30 seconds)
    globalConfig: { environment: process.env.ENVIRONMENT },
    use: {
        headless: false, // Run in headed mode for debugging
        baseURL: 'https://grp-prelive.volkswagenag.com/',
        viewport: null, //Disable viewport to make the page content dynamic
        // Set other defaults here...
    },
    // Define a custom TOTP task
    setupGlobalEvents: async (globalConfig, workerInfo) => {
        globalConfig.otplib = {
            generateToken: (secret) => {
                return otplib.authenticator.generate(secret);
            },
        };
        globalConfig.readPdf = readPdf;
    },
});